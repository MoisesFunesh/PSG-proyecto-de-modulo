-- Creamos la base si no existe
IF DB_ID('PSG') IS NULL
BEGIN
    CREATE DATABASE PSG;
END
GO

USE PSG;
GO

-- Catálogos base
CREATE TABLE C_EstadosUsuarios
(
    IdEstado INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(40) NOT NULL,
    Descripcion VARCHAR(150) NULL,
    Activo BIT NOT NULL DEFAULT 1
);

CREATE TABLE S_PerfilesUsuarios
(
    IdPerfil INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL UNIQUE,
    Descripcion VARCHAR(200) NULL,
    Activo BIT NOT NULL DEFAULT 1
);

CREATE TABLE C_OpcionesMenu
(
    IdOpcionMenu INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(60) NOT NULL,
    Modulo VARCHAR(60) NOT NULL UNIQUE,
    Activo BIT NOT NULL DEFAULT 1
);

-- Seguridad y accesos
CREATE TABLE S_Usuarios
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(120) NOT NULL,
    Email VARCHAR(160) NOT NULL UNIQUE,
    PasswordHash VARCHAR(200) NOT NULL,
    IdPerfil INT NOT NULL,
    IdEstado INT NOT NULL,
    CONSTRAINT FK_Usuarios_Perfil FOREIGN KEY (IdPerfil) REFERENCES S_PerfilesUsuarios(IdPerfil),
    CONSTRAINT FK_Usuarios_Estado FOREIGN KEY (IdEstado) REFERENCES C_EstadosUsuarios(IdEstado)
);

CREATE TABLE D_OpcionesPerfiles
(
    IdPerfil INT NOT NULL,
    IdOpcionMenu INT NOT NULL,
    PuedeConsultar BIT NOT NULL DEFAULT 0,
    PuedeCrear BIT NOT NULL DEFAULT 0,
    PuedeEditar BIT NOT NULL DEFAULT 0,
    PuedeEliminar BIT NOT NULL DEFAULT 0,
    PRIMARY KEY (IdPerfil, IdOpcionMenu),
    CONSTRAINT FK_Permisos_Perfil FOREIGN KEY (IdPerfil) REFERENCES S_PerfilesUsuarios(IdPerfil),
    CONSTRAINT FK_Permisos_Menu FOREIGN KEY (IdOpcionMenu) REFERENCES C_OpcionesMenu(IdOpcionMenu)
);

-- Tablas del negocio
CREATE TABLE Salones
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(120) NOT NULL UNIQUE,
    Capacidad INT NOT NULL,
    Ubicacion VARCHAR(150) NULL,
    Precio DECIMAL(10,2) NOT NULL DEFAULT 0,
    Estado VARCHAR(30) NOT NULL DEFAULT 'Disponible',
    CONSTRAINT CK_Salones_Capacidad CHECK (Capacidad > 0),
    CONSTRAINT CK_Salones_Precio CHECK (Precio >= 0),
    CONSTRAINT CK_Salones_Estado CHECK (Estado IN ('Disponible','Ocupado','Mantenimiento'))
);

CREATE TABLE Servicios
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(120) NOT NULL UNIQUE,
    Categoria VARCHAR(80) NOT NULL,
    Precio DECIMAL(10,2) NOT NULL DEFAULT 0,
    Descripcion VARCHAR(250) NULL,
    Activo BIT NOT NULL DEFAULT 1,
    CONSTRAINT CK_Servicios_Precio CHECK (Precio >= 0)
);

CREATE TABLE Eventos
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(160) NOT NULL,
    Tipo VARCHAR(60) NOT NULL,
    Fecha DATE NOT NULL,
    SalonId INT NOT NULL,
    ClienteId INT NOT NULL,
    Estado VARCHAR(30) NOT NULL DEFAULT 'Pendiente',
    Monto DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT FK_Eventos_Salon FOREIGN KEY (SalonId) REFERENCES Salones(Id),
    CONSTRAINT FK_Eventos_Cliente FOREIGN KEY (ClienteId) REFERENCES S_Usuarios(Id),
    CONSTRAINT CK_Eventos_Estado CHECK (Estado IN ('Confirmado','Pendiente','Cancelado')),
    CONSTRAINT CK_Eventos_Monto CHECK (Monto >= 0)
);

CREATE TABLE Reservaciones
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ClienteId INT NOT NULL,
    EventoId INT NOT NULL,
    SalonId INT NOT NULL,
    Fecha DATE NOT NULL,
    FechaCreacion DATE NOT NULL DEFAULT GETDATE(),
    Estado VARCHAR(30) NOT NULL DEFAULT 'Pendiente',
    Total DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT FK_Reservaciones_Cliente FOREIGN KEY (ClienteId) REFERENCES S_Usuarios(Id),
    CONSTRAINT FK_Reservaciones_Evento FOREIGN KEY (EventoId) REFERENCES Eventos(Id),
    CONSTRAINT FK_Reservaciones_Salon FOREIGN KEY (SalonId) REFERENCES Salones(Id),
    CONSTRAINT CK_Reservaciones_Estado CHECK (Estado IN ('Confirmada','Pendiente','Cancelada')),
    CONSTRAINT CK_Reservaciones_Total CHECK (Total >= 0)
);

CREATE TABLE Cotizaciones
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ClienteId INT NOT NULL,
    Descripcion VARCHAR(500) NOT NULL,
    Descuento DECIMAL(10,2) NOT NULL DEFAULT 0,
    FechaEmision DATE NOT NULL,
    FechaVence DATE NOT NULL,
    Estado VARCHAR(30) NOT NULL DEFAULT 'Pendiente',
    CONSTRAINT FK_Cotizaciones_Cliente FOREIGN KEY (ClienteId) REFERENCES S_Usuarios(Id),
    CONSTRAINT CK_Cotizaciones_Estado CHECK (Estado IN ('Pendiente','Aceptada','Rechazada')),
    CONSTRAINT CK_Cotizaciones_Descuento CHECK (Descuento >= 0)
);

CREATE TABLE CotizacionItems
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    CotizacionId INT NOT NULL,
    Concepto VARCHAR(220) NOT NULL,
    Precio DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT FK_CotizacionItems_Cotizacion FOREIGN KEY (CotizacionId) REFERENCES Cotizaciones(Id) ON DELETE CASCADE,
    CONSTRAINT CK_CotizacionItems_Precio CHECK (Precio >= 0)
);

-- Bitácora para cambios
CREATE TABLE S_BitacorasSistema
(
    IdBitacora INT IDENTITY(1,1) PRIMARY KEY,
    FechaProceso DATETIME NOT NULL DEFAULT GETDATE(),
    IdUsuario INT NULL,
    TablaAfectada VARCHAR(80) NOT NULL,
    IdRegistro INT NULL,
    CONSTRAINT FK_Bitacora_Usuario FOREIGN KEY (IdUsuario) REFERENCES S_Usuarios(Id)
);
GO

-- Datos iniciales (Seed)
INSERT INTO C_EstadosUsuarios (Nombre, Descripcion) VALUES
('Activo','Puede iniciar sesion'),
('Inactivo','No puede iniciar sesion');

INSERT INTO S_PerfilesUsuarios (Nombre, Descripcion) VALUES
('Administrador','Acceso completo'),
('Organizador','Gestiona eventos y servicios'),
('Cliente','Consulta sus solicitudes');

INSERT INTO C_OpcionesMenu (Nombre, Modulo) VALUES
('Dashboard','Dashboard'),
('Eventos','Eventos'),
('Salones','Salones'),
('Servicios','Servicios'),
('Reservaciones','Reservaciones'),
('Cotizaciones','Cotizaciones'),
('Usuarios','Usuarios'),
('Alertas','Alertas');

-- Permisos de perfiles
INSERT INTO D_OpcionesPerfiles VALUES
(1,1,1,1,1,1),(1,2,1,1,1,1),(1,3,1,1,1,1),(1,4,1,1,1,1),
(1,5,1,1,1,1),(1,6,1,1,1,1),(1,7,1,1,1,1),(1,8,1,1,1,1),
(2,1,1,0,0,0),(2,2,1,1,1,0),(2,3,1,0,1,0),(2,4,1,1,1,0),
(2,5,1,1,1,0),(2,6,1,1,1,0),(2,7,0,0,0,0),(2,8,1,0,0,0),
(3,1,1,0,0,0),(3,2,0,0,0,0),(3,3,0,0,0,0),(3,4,0,0,0,0),
(3,5,1,0,0,0),(3,6,1,0,0,0),(3,7,0,0,0,0),(3,8,0,0,0,0);

INSERT INTO S_Usuarios (Nombre, Email, PasswordHash, IdPerfil, IdEstado) VALUES
('Carlos Mendoza','admin@psg.com','$2a$10$tOx2NfQ902TYb6az3sgJmeHe5wuXkuOktkctaxcVreWx7S3th0Y5e',1,1),
('Laura Torres','organizador@psg.com','$2a$10$FBN0ZBo1GeNXjiKlK4PggeNBwFA9aAf4EG0bx2MhQEFDZjWYK3rga',2,1),
('Sofia Ramirez','cliente@psg.com','$2a$10$a0DIaoNjcLIUxIh1lhlrgOl66758kqQ7G37bSWMseXjXBrxBHId0m',3,1);

INSERT INTO Salones (Nombre, Capacidad, Ubicacion, Precio) VALUES
('Salon Imperial',500,'Planta Baja',8500),
('Sala Cristal',80,'Planta Baja',2100);

INSERT INTO Servicios (Nombre, Categoria, Precio, Descripcion) VALUES
('Catering Premium','Alimentacion',450,'Menu completo por persona'),
('Sonido Profesional','Audio/Video',3500,'Equipo de sonido para eventos');

-- Datos de prueba rápidos
DECLARE @cliente INT = (SELECT Id FROM S_Usuarios WHERE Email = 'cliente@psg.com');
DECLARE @salon1 INT = (SELECT Id FROM Salones WHERE Nombre = 'Salon Imperial');
DECLARE @salon2 INT = (SELECT Id FROM Salones WHERE Nombre = 'Sala Cristal');
DECLARE @evento1 INT;
DECLARE @evento2 INT;

INSERT INTO Eventos (Nombre, Tipo, Fecha, SalonId, ClienteId, Estado, Monto)
VALUES ('Boda Familiar','Boda',DATEADD(DAY,20,GETDATE()),@salon1,@cliente,'Confirmado',8500);
SET @evento1 = SCOPE_IDENTITY();

INSERT INTO Eventos (Nombre, Tipo, Fecha, SalonId, ClienteId, Estado, Monto)
VALUES ('Graduacion 2026','Graduacion',DATEADD(DAY,45,GETDATE()),@salon2,@cliente,'Pendiente',2100);
SET @evento2 = SCOPE_IDENTITY();

INSERT INTO Reservaciones (ClienteId, EventoId, SalonId, Fecha, Estado, Total)
SELECT @cliente, Id, SalonId, Fecha, 'Confirmada', Monto FROM Eventos WHERE Id = @evento1;

INSERT INTO Reservaciones (ClienteId, EventoId, SalonId, Fecha, Estado, Total)
SELECT @cliente, Id, SalonId, Fecha, 'Pendiente', Monto FROM Eventos WHERE Id = @evento2;

DECLARE @cotizacion INT;
INSERT INTO Cotizaciones (ClienteId, Descripcion, Descuento, FechaEmision, FechaVence)
VALUES (@cliente,'Cotizacion para boda familiar',200,GETDATE(),DATEADD(DAY,15,GETDATE()));
SET @cotizacion = SCOPE_IDENTITY();

INSERT INTO CotizacionItems (CotizacionId, Concepto, Precio) VALUES
(@cotizacion,'Salon Imperial',8500),
(@cotizacion,'Catering Premium',450);
GO

-- Vistas útiles
CREATE VIEW vw_DetalleEventos AS
SELECT e.Id, e.Nombre, e.Tipo, e.Fecha, e.Estado, e.Monto, s.Nombre AS Salon, u.Nombre AS Cliente
FROM Eventos e 
INNER JOIN Salones s ON e.SalonId = s.Id 
INNER JOIN S_Usuarios u ON e.ClienteId = u.Id;
GO

CREATE VIEW vw_DetalleReservaciones AS
SELECT r.Id, r.Fecha, r.Estado, r.Total, e.Nombre AS Evento, s.Nombre AS Salon, u.Nombre AS Cliente
FROM Reservaciones r 
INNER JOIN Eventos e ON r.EventoId = e.Id
INNER JOIN Salones s ON r.SalonId = s.Id 
INNER JOIN S_Usuarios u ON r.ClienteId = u.Id;
GO

CREATE VIEW vw_AlertasPendientes AS
SELECT 'Evento' AS Tipo, e.Id, e.Nombre AS Descripcion, e.Fecha, e.Estado
FROM Eventos e
WHERE e.Estado <> 'Cancelado' 
  AND e.Fecha >= CONVERT(date, GETDATE()) 
  AND e.Fecha <= DATEADD(DAY, 30, CONVERT(date, GETDATE()))
UNION ALL
SELECT 'Reservacion', r.Id, e.Nombre, r.Fecha, r.Estado
FROM Reservaciones r 
INNER JOIN Eventos e ON r.EventoId = e.Id
WHERE r.Estado = 'Pendiente' 
  AND r.Fecha >= CONVERT(date, GETDATE());
GO

-- Procedimiento para cambiar estado a usuario
CREATE PROCEDURE sp_ActualizarEstadoUsuario
    @IdUsuario INT,
    @IdEstado INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE S_Usuarios 
    SET IdEstado = @IdEstado 
    WHERE Id = @IdUsuario;
END
GO

-- Triggers de validación de negocio
CREATE TRIGGER trg_Eventos_Validar
ON Eventos
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Checar fechas pasadas o salones en mantenimiento
    IF EXISTS
    (
        SELECT 1 FROM inserted i 
        INNER JOIN Salones s ON i.SalonId = s.Id
        WHERE i.Estado <> 'Cancelado'
          AND (i.Fecha < CONVERT(date, GETDATE()) OR s.Estado = 'Mantenimiento')
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50001, 'El evento tiene una fecha pasada o el salon esta en mantenimiento.', 1;
    END;

    -- Evitar cruce de eventos en el mismo salón y fecha
    IF EXISTS
    (
        SELECT 1 FROM inserted i 
        INNER JOIN Eventos e ON i.SalonId = e.SalonId AND i.Fecha = e.Fecha AND i.Id <> e.Id
        WHERE i.Estado <> 'Cancelado' AND e.Estado <> 'Cancelado'
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50002, 'El salon ya tiene otro evento en esa fecha.', 1;
    END;
END
GO

CREATE TRIGGER trg_Reservaciones_Validar
ON Reservaciones
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Validar que la reserva amarre bien con el evento/salón
    IF EXISTS
    (
        SELECT 1 FROM inserted i 
        INNER JOIN Eventos e ON i.EventoId = e.Id
        INNER JOIN Salones s ON i.SalonId = s.Id
        WHERE i.Estado <> 'Cancelada'
          AND (i.Fecha < CONVERT(date, GETDATE()) OR s.Estado = 'Mantenimiento'
               OR e.SalonId <> i.SalonId OR e.Fecha <> i.Fecha)
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50003, 'La reservacion no coincide con el evento o el salon.', 1;
    END;

    -- Evitar reservas duplicadas para el mismo salón el mismo día
    IF EXISTS
    (
        SELECT 1 FROM inserted i 
        INNER JOIN Reservaciones r ON i.SalonId = r.SalonId AND i.Fecha = r.Fecha AND i.Id <> r.Id
        WHERE i.Estado <> 'Cancelada' AND r.Estado <> 'Cancelada'
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50004, 'El salon ya tiene otra reservacion en esa fecha.', 1;
    END;
END
GO

CREATE TRIGGER trg_Cotizaciones_Validar
ON Cotizaciones
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    -- Que no venza antes de nacer
    IF EXISTS (SELECT 1 FROM inserted WHERE FechaVence < FechaEmision)
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50005, 'La fecha de vencimiento no puede ser anterior a la emision.', 1;
    END;
END
GO

-- Triggers de bitácora rápidos
CREATE TRIGGER trg_Usuarios_Bitacora
ON S_Usuarios
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO S_BitacorasSistema (TablaAfectada, IdRegistro)
    SELECT 'S_Usuarios', ISNULL(i.Id, d.Id)
    FROM inserted i FULL OUTER JOIN deleted d ON i.Id = d.Id;
END
GO

CREATE TRIGGER trg_Eventos_Bitacora
ON Eventos
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO S_BitacorasSistema (TablaAfectada, IdRegistro)
    SELECT 'Eventos', ISNULL(i.Id, d.Id)
    FROM inserted i FULL OUTER JOIN deleted d ON i.Id = d.Id;
END
GO

CREATE TRIGGER trg_Reservaciones_Bitacora
ON Reservaciones
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO S_BitacorasSistema (TablaAfectada, IdRegistro)
    SELECT 'Reservaciones', ISNULL(i.Id, d.Id)
    FROM inserted i FULL OUTER JOIN deleted d ON i.Id = d.Id;
END
GO

PRINT 'Base PSG lista.';
