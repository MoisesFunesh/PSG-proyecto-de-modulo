﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Salones
{
    public partial class frmSalones : Form
    {
        // todos los registros que trajo la base y los que se ven en la tabla despues de buscar
        private Salon[] todos;
        private Salon[] mostrados;

        public frmSalones()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            Estilos.EstilizarTabla(dgvDatos);
            todos = new Salon[0];
            mostrados = new Salon[0];
        }

        private void frmSalones_Load(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Salones", "consultar") == false)
            {
                Herramientas.MostrarAviso(this, "No tiene permiso para consultar salones.");
                Close();
                return;
            }
            PermisosUI.AplicarBotones("Salones", btnNuevo, btnEditar, btnEliminar);
            lblSubtitulo.Text = PermisosUI.Tiene("Salones", "editar")
                ? "Administración de salones y tarifas."
                : "Consulta de salones disponibles.";
            CargarDatos();
        }

        // vuelve a leer la base de datos y actualiza la tabla
        private void CargarDatos()
        {
            try
            {
                todos = Salon.ObtenerTodos();
                AplicarFiltro();
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Salones", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void AplicarFiltro()
        {
            mostrados = Salon.Buscar(todos, txtBuscar.Text);

            dgvDatos.Rows.Clear();
            for (int i = 0; i < mostrados.Length; i++)
            {
                Salon salon = mostrados[i];

                int fila = dgvDatos.Rows.Add(
                    salon.Id.ToString("000"),
                    salon.Nombre,
                    salon.Capacidad.ToString(),
                    salon.Ubicacion,
                    Herramientas.FormatoDinero(salon.Precio),
                    salon.Estado
                );
                dgvDatos.Rows[fila].Tag = salon;
                Estilos.ColorearEstado(dgvDatos.Rows[fila].Cells["colEstado"]);
            }

            lblConteo.Text = mostrados.Length + " registros";
        }

        // devuelve el registro que esta seleccionado en la tabla (o null si no hay)
        private Salon ObtenerSeleccionado()
        {
            if (dgvDatos.CurrentRow == null) return null;
            return dgvDatos.CurrentRow.Tag as Salon;
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            AplicarFiltro();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Salones", "crear") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para crear salones."); return; }
            frmSalonEditar editor = new frmSalonEditar();
            if (editor.ShowDialog(this) == DialogResult.OK)
            {
                CargarDatos();
            }
            editor.Dispose();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            EditarSeleccionado();
        }

        private void dgvDatos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && btnEditar.Visible)
            {
                EditarSeleccionado();
            }
        }

        private void EditarSeleccionado()
        {
            if (PermisosUI.Tiene("Salones", "editar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para editar salones."); return; }
            Salon seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un registro de la tabla.");
                return;
            }

            frmSalonEditar editor = new frmSalonEditar(seleccionado);
            if (editor.ShowDialog(this) == DialogResult.OK)
            {
                CargarDatos();
            }
            editor.Dispose();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Salones", "eliminar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para quitar salones."); return; }
            Salon seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un registro de la tabla.");
                return;
            }

            if (Herramientas.Confirmar(this, "¿Desea eliminar \"" + seleccionado.Nombre + "\"?\nEsta acción no se puede deshacer.") == false)
            {
                return;
            }

            try
            {
                if (Salon.Eliminar(seleccionado.Id))
                {
                    Herramientas.MostrarAviso(this, "El salón se eliminó o se dejó en mantenimiento correctamente.");
                    CargarDatos();
                }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Salones", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
