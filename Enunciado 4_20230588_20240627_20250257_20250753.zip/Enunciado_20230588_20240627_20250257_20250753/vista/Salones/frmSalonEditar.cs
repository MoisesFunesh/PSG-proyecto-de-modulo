﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Salones
{
    public partial class frmSalonEditar : Form
    {
        // Muestra el error junto al campo.
        private ErrorProvider errorProvider = new ErrorProvider();

        // si es null estamos agregando un salon nuevo, si no, estamos editando ese salon
        private Salon salonEditar = null;

        public frmSalonEditar()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.AcceptButton = btnGuardar;
            this.CancelButton = btnCancelar;
        }

        public frmSalonEditar(Salon salon) : this()
        {
            salonEditar = salon;
            lblTitulo.Text = "Editar salón";
            this.Text = "PSG · Editar salón";
        }

        private void frmSalonEditar_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < Catalogos.EstadosSalon.Length; i++)
            {
                cboEstado.Items.Add(Catalogos.EstadosSalon[i]);
            }

            if (salonEditar == null)
            {
                nudCapacidad.Value = 100;
                cboEstado.SelectedItem = "Disponible";
            }
            else
            {
                txtNombre.Text = salonEditar.Nombre;
                nudCapacidad.Value = salonEditar.Capacidad;
                txtUbicacion.Text = salonEditar.Ubicacion;
                nudTarifa.Value = salonEditar.Precio;
                cboEstado.SelectedItem = salonEditar.Estado;
            }
            if (cboEstado.SelectedIndex == -1) cboEstado.SelectedIndex = 0;

            if (PermisosUI.Tiene("Salones", "editar") == false)
            {
                nudTarifa.Enabled = false;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidarCampos() == false) return;
                Salon salon = new Salon();
                salon.Nombre = txtNombre.Text.Trim();
                salon.Capacidad = (int)nudCapacidad.Value;
                salon.Ubicacion = txtUbicacion.Text.Trim();
                salon.Precio = nudTarifa.Value;
                salon.Estado = cboEstado.SelectedItem.ToString();
                bool guardado;
                if (salonEditar == null) guardado = Salon.Agregar(salon);
                else
                {
                    salon.Id = salonEditar.Id;
                    guardado = Salon.Actualizar(salon);
                }
                if (guardado == false) return;
                MessageBox.Show(this, "El salón se guardó correctamente.", "Listo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Salones", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private bool ValidarCampos()
        {
            errorProvider.Clear();

            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MostrarAviso("El nombre del salón es obligatorio.", txtNombre);
                return false;
            }
            if (nudCapacidad.Value <= 0)
            {
                MostrarAviso("La capacidad debe ser mayor que cero.", nudCapacidad);
                return false;
            }

            return true;
        }

        private void MostrarAviso(string mensaje, Control control)
        {
            errorProvider.SetError(control, mensaje);
            MessageBox.Show(this, mensaje, "Datos incompletos",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
