﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Alertas
{
    public partial class frmCentroAlertas : Form
    {
        public frmCentroAlertas()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            Estilos.EstilizarTabla(dgvAlertas);
        }

        private void frmCentroAlertas_Load(object sender, EventArgs e)
        {
            CargarAlertas();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            CargarAlertas();
        }

        private void CargarAlertas()
        {
            try
            {
                Alerta[] alertas = Alerta.ObtenerTodas();

            dgvAlertas.Rows.Clear();
            for (int i = 0; i < alertas.Length; i++)
            {
                dgvAlertas.Rows.Add(alertas[i].Tipo, alertas[i].Detalle, Herramientas.FormatoFecha(alertas[i].Fecha));
            }

            if (alertas.Length == 0)
            {
                lblEstado.Text = "No hay alertas pendientes. Todo está al día.";
            }
            else if (alertas.Length == 1)
            {
                lblEstado.Text = "1 alerta encontrada.";
            }
            else
            {
                lblEstado.Text = alertas.Length + " alertas encontradas.";
            }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Alertas", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
