﻿namespace vista.Reservaciones
{
    partial class frmReservacionEditar
    {
        // <summary>
        // Variable del diseñador necesaria.
        // </summary>
        private System.ComponentModel.IContainer components = null;

        // <summary>
        // Limpiar los recursos que se estén usando.
        // </summary>
        // <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        // <summary>
        // Método necesario para admitir el Diseñador. No se puede modificar
        // el contenido de este método con el editor de código.
        // </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblEtCliente = new System.Windows.Forms.Label();
            this.cboCliente = new System.Windows.Forms.ComboBox();
            this.lblEtEvento = new System.Windows.Forms.Label();
            this.cboEvento = new System.Windows.Forms.ComboBox();
            this.lblEtSalon = new System.Windows.Forms.Label();
            this.cboSalon = new System.Windows.Forms.ComboBox();
            this.lblEtFecha = new System.Windows.Forms.Label();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.lblEtEstado = new System.Windows.Forms.Label();
            this.cboEstado = new System.Windows.Forms.ComboBox();
            this.lblEtTotal = new System.Windows.Forms.Label();
            this.nudTotal = new System.Windows.Forms.NumericUpDown();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudTotal)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblTitulo.Location = new System.Drawing.Point(24, 16);
            this.lblTitulo.Text = "Nueva reservación";
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            // 
            // lblEtCliente
            // 
            this.lblEtCliente.AutoSize = false;
            this.lblEtCliente.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtCliente.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtCliente.Location = new System.Drawing.Point(24, 66);
            this.lblEtCliente.Size = new System.Drawing.Size(412, 18);
            this.lblEtCliente.Text = "CLIENTE";
            this.lblEtCliente.Name = "lblEtCliente";
            this.lblEtCliente.TabIndex = 1;
            // 
            // cboCliente
            // 
            this.cboCliente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCliente.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboCliente.FormattingEnabled = true;
            this.cboCliente.Location = new System.Drawing.Point(24, 86);
            this.cboCliente.Size = new System.Drawing.Size(412, 25);
            this.cboCliente.Name = "cboCliente";
            this.cboCliente.TabIndex = 2;
            // 
            // lblEtEvento
            // 
            this.lblEtEvento.AutoSize = false;
            this.lblEtEvento.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtEvento.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtEvento.Location = new System.Drawing.Point(24, 130);
            this.lblEtEvento.Size = new System.Drawing.Size(412, 18);
            this.lblEtEvento.Text = "EVENTO";
            this.lblEtEvento.Name = "lblEtEvento";
            this.lblEtEvento.TabIndex = 3;
            // 
            // cboEvento
            // 
            this.cboEvento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEvento.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboEvento.FormattingEnabled = true;
            this.cboEvento.Location = new System.Drawing.Point(24, 150);
            this.cboEvento.Size = new System.Drawing.Size(412, 25);
            this.cboEvento.Name = "cboEvento";
            this.cboEvento.TabIndex = 4;
            // 
            // lblEtSalon
            // 
            this.lblEtSalon.AutoSize = false;
            this.lblEtSalon.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtSalon.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtSalon.Location = new System.Drawing.Point(24, 194);
            this.lblEtSalon.Size = new System.Drawing.Size(412, 18);
            this.lblEtSalon.Text = "SALÓN";
            this.lblEtSalon.Name = "lblEtSalon";
            this.lblEtSalon.TabIndex = 5;
            // 
            // cboSalon
            // 
            this.cboSalon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSalon.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboSalon.FormattingEnabled = true;
            this.cboSalon.Location = new System.Drawing.Point(24, 214);
            this.cboSalon.Size = new System.Drawing.Size(412, 25);
            this.cboSalon.Name = "cboSalon";
            this.cboSalon.TabIndex = 6;
            // 
            // lblEtFecha
            // 
            this.lblEtFecha.AutoSize = false;
            this.lblEtFecha.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtFecha.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtFecha.Location = new System.Drawing.Point(24, 258);
            this.lblEtFecha.Size = new System.Drawing.Size(412, 18);
            this.lblEtFecha.Text = "FECHA DEL EVENTO";
            this.lblEtFecha.Name = "lblEtFecha";
            this.lblEtFecha.TabIndex = 7;
            // 
            // dtpFecha
            // 
            this.dtpFecha.CustomFormat = "dd/MM/yyyy";
            this.dtpFecha.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFecha.Location = new System.Drawing.Point(24, 278);
            this.dtpFecha.Size = new System.Drawing.Size(412, 25);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.TabIndex = 8;
            // 
            // lblEtEstado
            // 
            this.lblEtEstado.AutoSize = false;
            this.lblEtEstado.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtEstado.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtEstado.Location = new System.Drawing.Point(24, 322);
            this.lblEtEstado.Size = new System.Drawing.Size(412, 18);
            this.lblEtEstado.Text = "ESTADO";
            this.lblEtEstado.Name = "lblEtEstado";
            this.lblEtEstado.TabIndex = 9;
            // 
            // cboEstado
            // 
            this.cboEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEstado.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboEstado.FormattingEnabled = true;
            this.cboEstado.Location = new System.Drawing.Point(24, 342);
            this.cboEstado.Size = new System.Drawing.Size(412, 25);
            this.cboEstado.Name = "cboEstado";
            this.cboEstado.TabIndex = 10;
            // 
            // lblEtTotal
            // 
            this.lblEtTotal.AutoSize = false;
            this.lblEtTotal.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtTotal.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtTotal.Location = new System.Drawing.Point(24, 386);
            this.lblEtTotal.Size = new System.Drawing.Size(412, 18);
            this.lblEtTotal.Text = "TOTAL";
            this.lblEtTotal.Name = "lblEtTotal";
            this.lblEtTotal.TabIndex = 11;
            // 
            // nudTotal
            // 
            this.nudTotal.DecimalPlaces = 2;
            this.nudTotal.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.nudTotal.Location = new System.Drawing.Point(24, 406);
            this.nudTotal.Maximum = new decimal(new int[] {1000000000, 0, 0, 0});
            this.nudTotal.Size = new System.Drawing.Size(412, 25);
            this.nudTotal.ThousandsSeparator = true;
            this.nudTotal.Name = "nudTotal";
            this.nudTotal.TabIndex = 12;
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelar.FlatAppearance.BorderSize = 1;
            this.btnCancelar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(226, 232, 240);
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.btnCancelar.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.btnCancelar.Location = new System.Drawing.Point(326, 458);
            this.btnCancelar.Size = new System.Drawing.Size(110, 36);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.TabIndex = 13;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.btnGuardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.btnGuardar.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnGuardar.Location = new System.Drawing.Point(198, 458);
            this.btnGuardar.Size = new System.Drawing.Size(120, 36);
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.TabIndex = 14;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // frmReservacionEditar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.ClientSize = new System.Drawing.Size(460, 518);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PSG · Reservación";
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblEtCliente);
            this.Controls.Add(this.cboCliente);
            this.Controls.Add(this.lblEtEvento);
            this.Controls.Add(this.cboEvento);
            this.Controls.Add(this.lblEtSalon);
            this.Controls.Add(this.cboSalon);
            this.Controls.Add(this.lblEtFecha);
            this.Controls.Add(this.dtpFecha);
            this.Controls.Add(this.lblEtEstado);
            this.Controls.Add(this.cboEstado);
            this.Controls.Add(this.lblEtTotal);
            this.Controls.Add(this.nudTotal);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnGuardar);
            this.Name = "frmReservacionEditar";
            this.Load += new System.EventHandler(this.frmReservacionEditar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudTotal)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblEtCliente;
        private System.Windows.Forms.ComboBox cboCliente;
        private System.Windows.Forms.Label lblEtEvento;
        private System.Windows.Forms.ComboBox cboEvento;
        private System.Windows.Forms.Label lblEtSalon;
        private System.Windows.Forms.ComboBox cboSalon;
        private System.Windows.Forms.Label lblEtFecha;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.Label lblEtEstado;
        private System.Windows.Forms.ComboBox cboEstado;
        private System.Windows.Forms.Label lblEtTotal;
        private System.Windows.Forms.NumericUpDown nudTotal;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGuardar;
    }
}
