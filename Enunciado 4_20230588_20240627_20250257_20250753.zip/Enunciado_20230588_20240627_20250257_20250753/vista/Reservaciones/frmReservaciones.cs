﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Reservaciones
{
    public partial class frmReservaciones : Form
    {
        // todos los registros que trajo la base y los que se ven en la tabla despues de buscar
        private Reservacion[] todos;
        private Reservacion[] mostrados;

        public frmReservaciones()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            Estilos.EstilizarTabla(dgvDatos);
            todos = new Reservacion[0];
            mostrados = new Reservacion[0];
        }

        private void frmReservaciones_Load(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Reservaciones", "consultar") == false)
            {
                Herramientas.MostrarAviso(this, "No tiene permiso para consultar reservaciones.");
                Close();
                return;
            }
            PermisosUI.AplicarBotones("Reservaciones", btnNuevo, btnEditar, btnEliminar);
            lblSubtitulo.Text = Sesion.UsuarioActual.Rol == UsuarioRol.Cliente
                ? "Estado de su evento reservado."
                : "Administración de reservaciones.";
            CargarDatos();
        }

        // vuelve a leer la base de datos y actualiza la tabla
        private void CargarDatos()
        {
            try
            {
                todos = ObtenerReservaciones();
                AplicarFiltro();
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Reservaciones", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        // el cliente solo ve las suyas; administrador y organizador ven todas
        private Reservacion[] ObtenerReservaciones()
        {
            if (Sesion.UsuarioActual.Rol == UsuarioRol.Cliente)
            {
                return Reservacion.ObtenerPorCliente(Sesion.UsuarioActual.Id);
            }
            return Reservacion.ObtenerTodas();
        }

        private void AplicarFiltro()
        {
            mostrados = Reservacion.Buscar(todos, txtBuscar.Text);

            dgvDatos.Rows.Clear();
            for (int i = 0; i < mostrados.Length; i++)
            {
                Reservacion reservacion = mostrados[i];

                int fila = dgvDatos.Rows.Add(
                    reservacion.Id.ToString("000"),
                    reservacion.ClienteNombre,
                    reservacion.EventoNombre,
                    reservacion.SalonNombre,
                    Herramientas.FormatoFecha(reservacion.Fecha),
                    Herramientas.FormatoFecha(reservacion.FechaCreacion),
                    reservacion.Estado,
                    Herramientas.FormatoDinero(reservacion.Total)
                );
                dgvDatos.Rows[fila].Tag = reservacion;
                Estilos.ColorearEstado(dgvDatos.Rows[fila].Cells["colEstado"]);
            }

            lblConteo.Text = mostrados.Length + " registros";
        }

        // devuelve el registro que esta seleccionado en la tabla (o null si no hay)
        private Reservacion ObtenerSeleccionado()
        {
            if (dgvDatos.CurrentRow == null) return null;
            return dgvDatos.CurrentRow.Tag as Reservacion;
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            AplicarFiltro();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Reservaciones", "crear") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para crear reservaciones."); return; }
            frmReservacionEditar editor = new frmReservacionEditar();
            if (editor.ShowDialog(this) == DialogResult.OK)
            {
                CargarDatos();
            }
            editor.Dispose();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            EditarSeleccionado();
        }

        private void dgvDatos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && btnEditar.Visible)
            {
                EditarSeleccionado();
            }
        }

        private void EditarSeleccionado()
        {
            if (PermisosUI.Tiene("Reservaciones", "editar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para editar reservaciones."); return; }
            Reservacion seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un registro de la tabla.");
                return;
            }

            frmReservacionEditar editor = new frmReservacionEditar(seleccionado);
            if (editor.ShowDialog(this) == DialogResult.OK)
            {
                CargarDatos();
            }
            editor.Dispose();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Reservaciones", "eliminar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para cancelar reservaciones."); return; }
            Reservacion seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un registro de la tabla.");
                return;
            }

            if (Herramientas.Confirmar(this, "¿Desea eliminar \"" + "Reservación #" + seleccionado.Id + " · " + seleccionado.EventoNombre + "\"?\nEsta acción no se puede deshacer.") == false)
            {
                return;
            }

            try
            {
                if (Reservacion.Eliminar(seleccionado.Id))
                {
                    Herramientas.MostrarAviso(this, "La reservación se canceló correctamente.");
                    CargarDatos();
                }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Reservaciones", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
