﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Reservaciones
{
    public partial class frmReservacionEditar : Form
    {
        // Muestra el error junto al campo.
        private ErrorProvider errorProvider = new ErrorProvider();

        // si es null estamos agregando una reservacion nueva, si no, estamos editando esa reservacion
        private Reservacion reservacionEditar = null;

        public frmReservacionEditar()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.AcceptButton = btnGuardar;
            this.CancelButton = btnCancelar;
        }

        public frmReservacionEditar(Reservacion reservacion) : this()
        {
            reservacionEditar = reservacion;
            lblTitulo.Text = "Editar reservación";
            this.Text = "PSG · Editar reservación";
        }

        private void frmReservacionEditar_Load(object sender, EventArgs e)
        {
            try
            {
            for (int i = 0; i < Catalogos.EstadosReserva.Length; i++)
            {
                cboEstado.Items.Add(Catalogos.EstadosReserva[i]);
            }

            cboCliente.DisplayMember = "Nombre";
            cboCliente.ValueMember = "Id";
            cboCliente.DataSource = Usuario.ObtenerClientes();

            cboEvento.DisplayMember = "Nombre";
            cboEvento.ValueMember = "Id";
            cboEvento.DataSource = Evento.ObtenerTodos();

            cboSalon.DisplayMember = "Nombre";
            cboSalon.ValueMember = "Id";
            cboSalon.DataSource = Salon.ObtenerTodos();

            if (reservacionEditar == null)
            {
                dtpFecha.Value = DateTime.Today;
                cboEstado.SelectedItem = "Pendiente";
            }
            else
            {
                cboCliente.SelectedValue = reservacionEditar.ClienteId;
                cboEvento.SelectedValue = reservacionEditar.EventoId;
                cboSalon.SelectedValue = reservacionEditar.SalonId;
                dtpFecha.Value = reservacionEditar.Fecha;
                cboEstado.SelectedItem = reservacionEditar.Estado;
                nudTotal.Value = reservacionEditar.Total;
            }
            if (cboEstado.SelectedIndex == -1) cboEstado.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Reservaciones", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult = DialogResult.Cancel;
                this.Close();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidarCampos() == false) return;
                Reservacion reservacion = new Reservacion();
                reservacion.ClienteId = Convert.ToInt32(cboCliente.SelectedValue);
                reservacion.EventoId = Convert.ToInt32(cboEvento.SelectedValue);
                reservacion.SalonId = Convert.ToInt32(cboSalon.SelectedValue);
                reservacion.Fecha = dtpFecha.Value.Date;
                reservacion.Estado = cboEstado.SelectedItem.ToString();
                reservacion.Total = nudTotal.Value;
                bool guardado;
                if (reservacionEditar == null) guardado = Reservacion.Agregar(reservacion);
                else
                {
                    reservacion.Id = reservacionEditar.Id;
                    guardado = Reservacion.Actualizar(reservacion);
                }
                if (guardado == false) return;
                MessageBox.Show(this, "La reservación se guardó correctamente.", "Listo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Reservaciones", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidarCampos()
        {
            errorProvider.Clear();

            if (cboCliente.SelectedValue == null)
            {
                MostrarAviso("Seleccione un cliente.", cboCliente);
                return false;
            }
            if (cboEvento.SelectedValue == null)
            {
                MostrarAviso("Seleccione un evento.", cboEvento);
                return false;
            }
            if (cboSalon.SelectedValue == null)
            {
                MostrarAviso("Seleccione un salón.", cboSalon);
                return false;
            }

            if (dtpFecha.Value.Date < DateTime.Today && cboEstado.SelectedItem.ToString() != "Cancelada")
            {
                MostrarAviso("La fecha de la reservación no puede ser anterior a hoy.", dtpFecha);
                return false;
            }

            int idEvento = Convert.ToInt32(cboEvento.SelectedValue);
            Evento eventoSeleccionado = Evento.ObtenerPorId(idEvento);
            int idSalon = Convert.ToInt32(cboSalon.SelectedValue);
            if (eventoSeleccionado == null)
            {
                MostrarAviso("El evento seleccionado ya no existe.", cboEvento);
                return false;
            }
            if (eventoSeleccionado.SalonId != idSalon || eventoSeleccionado.Fecha.Date != dtpFecha.Value.Date)
            {
                MostrarAviso("La reservación debe usar el mismo salón y la misma fecha del evento.", cboEvento);
                return false;
            }
            if (Salon.PuedeUsarse(idSalon) == false && cboEstado.SelectedItem.ToString() != "Cancelada")
            {
                MostrarAviso("El salón está en mantenimiento y no se puede reservar.", cboSalon);
                return false;
            }

            // no puede haber dos reservaciones activas del mismo salon en la misma fecha
            int idActual = 0;
            if (reservacionEditar != null)
            {
                idActual = reservacionEditar.Id;
            }
            if (cboEstado.SelectedItem.ToString() != "Cancelada")
            {
                if (Reservacion.FechaOcupada(idSalon, dtpFecha.Value.Date, idActual))
                {
                    MostrarAviso("Ese salón ya está reservado el " + dtpFecha.Value.ToString("dd/MM/yyyy") + ".", dtpFecha);
                    return false;
                }
            }

            return true;
        }

        private void MostrarAviso(string mensaje, Control control)
        {
            errorProvider.SetError(control, mensaje);
            MessageBox.Show(this, mensaje, "Datos incompletos",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
