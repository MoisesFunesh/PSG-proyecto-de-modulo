﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Servicios
{
    public partial class frmServicios : Form
    {
        // todos los registros que trajo la base y los que se ven en la tabla despues de buscar
        private Servicio[] todos;
        private Servicio[] mostrados;

        public frmServicios()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            Estilos.EstilizarTabla(dgvDatos);
            todos = new Servicio[0];
            mostrados = new Servicio[0];
        }

        private void frmServicios_Load(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Servicios", "consultar") == false)
            {
                Herramientas.MostrarAviso(this, "No tiene permiso para consultar servicios.");
                Close();
                return;
            }
            PermisosUI.AplicarBotones("Servicios", btnNuevo, btnEditar, btnEliminar);
            lblSubtitulo.Text = PermisosUI.Tiene("Servicios", "editar")
                ? "Catálogo de servicios y tarifas."
                : "Consulta de servicios disponibles.";
            CargarDatos();
        }

        // vuelve a leer la base de datos y actualiza la tabla
        private void CargarDatos()
        {
            try
            {
                todos = Servicio.ObtenerTodos();
                AplicarFiltro();
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Servicios", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void AplicarFiltro()
        {
            mostrados = Servicio.Buscar(todos, txtBuscar.Text);

            dgvDatos.Rows.Clear();
            for (int i = 0; i < mostrados.Length; i++)
            {
                Servicio servicio = mostrados[i];

                int fila = dgvDatos.Rows.Add(
                    servicio.Id.ToString("000"),
                    servicio.Nombre,
                    servicio.Categoria,
                    servicio.Descripcion,
                    Herramientas.FormatoDinero(servicio.Precio),
                    servicio.Estado
                );
                dgvDatos.Rows[fila].Tag = servicio;
                Estilos.ColorearEstado(dgvDatos.Rows[fila].Cells["colEstado"]);
            }

            lblConteo.Text = mostrados.Length + " registros";
        }

        // devuelve el registro que esta seleccionado en la tabla (o null si no hay)
        private Servicio ObtenerSeleccionado()
        {
            if (dgvDatos.CurrentRow == null) return null;
            return dgvDatos.CurrentRow.Tag as Servicio;
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            AplicarFiltro();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Servicios", "crear") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para crear servicios."); return; }
            frmServicioEditar editor = new frmServicioEditar();
            if (editor.ShowDialog(this) == DialogResult.OK)
            {
                CargarDatos();
            }
            editor.Dispose();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            EditarSeleccionado();
        }

        private void dgvDatos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && btnEditar.Visible)
            {
                EditarSeleccionado();
            }
        }

        private void EditarSeleccionado()
        {
            if (PermisosUI.Tiene("Servicios", "editar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para editar servicios."); return; }
            Servicio seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un registro de la tabla.");
                return;
            }

            frmServicioEditar editor = new frmServicioEditar(seleccionado);
            if (editor.ShowDialog(this) == DialogResult.OK)
            {
                CargarDatos();
            }
            editor.Dispose();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Servicios", "eliminar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para desactivar servicios."); return; }
            Servicio seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un registro de la tabla.");
                return;
            }

            if (Herramientas.Confirmar(this, "¿Desea eliminar \"" + seleccionado.Nombre + "\"?\nEsta acción no se puede deshacer.") == false)
            {
                return;
            }

            try
            {
                if (Servicio.Eliminar(seleccionado.Id))
                {
                    Herramientas.MostrarAviso(this, "El servicio se desactivó correctamente.");
                    CargarDatos();
                }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Servicios", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
