﻿namespace vista.Servicios
{
    partial class frmServicioEditar
    {
        // <summary>
        // Variable del diseñador necesaria.
        // </summary>
        private System.ComponentModel.IContainer components = null;

        // <summary>
        // Limpiar los recursos que se estén usando.
        // </summary>
        // <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        // <summary>
        // Método necesario para admitir el Diseñador. No se puede modificar
        // el contenido de este método con el editor de código.
        // </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblEtNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lblEtCategoria = new System.Windows.Forms.Label();
            this.cboCategoria = new System.Windows.Forms.ComboBox();
            this.lblEtDescripcion = new System.Windows.Forms.Label();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.lblEtTarifa = new System.Windows.Forms.Label();
            this.nudTarifa = new System.Windows.Forms.NumericUpDown();
            this.lblEtEstado = new System.Windows.Forms.Label();
            this.cboEstado = new System.Windows.Forms.ComboBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudTarifa)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblTitulo.Location = new System.Drawing.Point(24, 16);
            this.lblTitulo.Text = "Nuevo servicio";
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            // 
            // lblEtNombre
            // 
            this.lblEtNombre.AutoSize = false;
            this.lblEtNombre.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtNombre.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtNombre.Location = new System.Drawing.Point(24, 66);
            this.lblEtNombre.Size = new System.Drawing.Size(412, 18);
            this.lblEtNombre.Text = "NOMBRE";
            this.lblEtNombre.Name = "lblEtNombre";
            this.lblEtNombre.TabIndex = 1;
            // 
            // txtNombre
            // 
            this.txtNombre.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtNombre.Location = new System.Drawing.Point(24, 86);
            this.txtNombre.Size = new System.Drawing.Size(412, 27);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.TabIndex = 2;
            // 
            // lblEtCategoria
            // 
            this.lblEtCategoria.AutoSize = false;
            this.lblEtCategoria.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtCategoria.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtCategoria.Location = new System.Drawing.Point(24, 130);
            this.lblEtCategoria.Size = new System.Drawing.Size(412, 18);
            this.lblEtCategoria.Text = "CATEGORÍA";
            this.lblEtCategoria.Name = "lblEtCategoria";
            this.lblEtCategoria.TabIndex = 3;
            // 
            // cboCategoria
            // 
            this.cboCategoria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCategoria.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboCategoria.FormattingEnabled = true;
            this.cboCategoria.Location = new System.Drawing.Point(24, 150);
            this.cboCategoria.Size = new System.Drawing.Size(412, 25);
            this.cboCategoria.Name = "cboCategoria";
            this.cboCategoria.TabIndex = 4;
            // 
            // lblEtDescripcion
            // 
            this.lblEtDescripcion.AutoSize = false;
            this.lblEtDescripcion.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtDescripcion.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtDescripcion.Location = new System.Drawing.Point(24, 194);
            this.lblEtDescripcion.Size = new System.Drawing.Size(412, 18);
            this.lblEtDescripcion.Text = "DESCRIPCIÓN";
            this.lblEtDescripcion.Name = "lblEtDescripcion";
            this.lblEtDescripcion.TabIndex = 5;
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtDescripcion.Location = new System.Drawing.Point(24, 214);
            this.txtDescripcion.Size = new System.Drawing.Size(412, 27);
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.TabIndex = 6;
            // 
            // lblEtTarifa
            // 
            this.lblEtTarifa.AutoSize = false;
            this.lblEtTarifa.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtTarifa.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtTarifa.Location = new System.Drawing.Point(24, 258);
            this.lblEtTarifa.Size = new System.Drawing.Size(412, 18);
            this.lblEtTarifa.Text = "TARIFA";
            this.lblEtTarifa.Name = "lblEtTarifa";
            this.lblEtTarifa.TabIndex = 7;
            // 
            // nudTarifa
            // 
            this.nudTarifa.DecimalPlaces = 2;
            this.nudTarifa.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.nudTarifa.Location = new System.Drawing.Point(24, 278);
            this.nudTarifa.Maximum = new decimal(new int[] {1000000000, 0, 0, 0});
            this.nudTarifa.Size = new System.Drawing.Size(412, 25);
            this.nudTarifa.ThousandsSeparator = true;
            this.nudTarifa.Name = "nudTarifa";
            this.nudTarifa.TabIndex = 8;
            // 
            // lblEtEstado
            // 
            this.lblEtEstado.AutoSize = false;
            this.lblEtEstado.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtEstado.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtEstado.Location = new System.Drawing.Point(24, 322);
            this.lblEtEstado.Size = new System.Drawing.Size(412, 18);
            this.lblEtEstado.Text = "ESTADO";
            this.lblEtEstado.Name = "lblEtEstado";
            this.lblEtEstado.TabIndex = 9;
            // 
            // cboEstado
            // 
            this.cboEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEstado.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboEstado.FormattingEnabled = true;
            this.cboEstado.Location = new System.Drawing.Point(24, 342);
            this.cboEstado.Size = new System.Drawing.Size(412, 25);
            this.cboEstado.Name = "cboEstado";
            this.cboEstado.TabIndex = 10;
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelar.FlatAppearance.BorderSize = 1;
            this.btnCancelar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(226, 232, 240);
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.btnCancelar.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.btnCancelar.Location = new System.Drawing.Point(326, 394);
            this.btnCancelar.Size = new System.Drawing.Size(110, 36);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.TabIndex = 11;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.btnGuardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.btnGuardar.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnGuardar.Location = new System.Drawing.Point(198, 394);
            this.btnGuardar.Size = new System.Drawing.Size(120, 36);
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.TabIndex = 12;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // frmServicioEditar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.ClientSize = new System.Drawing.Size(460, 454);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PSG · Servicio";
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblEtNombre);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lblEtCategoria);
            this.Controls.Add(this.cboCategoria);
            this.Controls.Add(this.lblEtDescripcion);
            this.Controls.Add(this.txtDescripcion);
            this.Controls.Add(this.lblEtTarifa);
            this.Controls.Add(this.nudTarifa);
            this.Controls.Add(this.lblEtEstado);
            this.Controls.Add(this.cboEstado);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnGuardar);
            this.Name = "frmServicioEditar";
            this.Load += new System.EventHandler(this.frmServicioEditar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudTarifa)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblEtNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblEtCategoria;
        private System.Windows.Forms.ComboBox cboCategoria;
        private System.Windows.Forms.Label lblEtDescripcion;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Label lblEtTarifa;
        private System.Windows.Forms.NumericUpDown nudTarifa;
        private System.Windows.Forms.Label lblEtEstado;
        private System.Windows.Forms.ComboBox cboEstado;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGuardar;
    }
}
