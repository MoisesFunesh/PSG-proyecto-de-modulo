﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Servicios
{
    public partial class frmServicioEditar : Form
    {
        // Muestra el error junto al campo.
        private ErrorProvider errorProvider = new ErrorProvider();

        // si es null estamos agregando un servicio nuevo, si no, estamos editando ese servicio
        private Servicio servicioEditar = null;

        public frmServicioEditar()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.AcceptButton = btnGuardar;
            this.CancelButton = btnCancelar;
        }

        public frmServicioEditar(Servicio servicio) : this()
        {
            servicioEditar = servicio;
            lblTitulo.Text = "Editar servicio";
            this.Text = "PSG · Editar servicio";
        }

        private void frmServicioEditar_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < Catalogos.CategoriasServicio.Length; i++)
            {
                cboCategoria.Items.Add(Catalogos.CategoriasServicio[i]);
            }
            for (int i = 0; i < Catalogos.EstadosServicio.Length; i++)
            {
                cboEstado.Items.Add(Catalogos.EstadosServicio[i]);
            }

            if (servicioEditar == null)
            {
                cboEstado.SelectedItem = "Activo";
            }
            else
            {
                txtNombre.Text = servicioEditar.Nombre;
                cboCategoria.SelectedItem = servicioEditar.Categoria;
                txtDescripcion.Text = servicioEditar.Descripcion;
                nudTarifa.Value = servicioEditar.Precio;
                cboEstado.SelectedItem = servicioEditar.Estado;
            }
            if (cboCategoria.SelectedIndex == -1) cboCategoria.SelectedIndex = 0;
            if (cboEstado.SelectedIndex == -1) cboEstado.SelectedIndex = 0;

            if (PermisosUI.Tiene("Servicios", "editar") == false)
            {
                nudTarifa.Enabled = false;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidarCampos() == false) return;
                Servicio servicio = new Servicio();
                servicio.Nombre = txtNombre.Text.Trim();
                servicio.Categoria = cboCategoria.SelectedItem.ToString();
                servicio.Descripcion = txtDescripcion.Text.Trim();
                servicio.Precio = nudTarifa.Value;
                servicio.Activo = cboEstado.SelectedItem.ToString() == "Activo";
                bool guardado;
                if (servicioEditar == null) guardado = Servicio.Agregar(servicio);
                else
                {
                    servicio.Id = servicioEditar.Id;
                    guardado = Servicio.Actualizar(servicio);
                }
                if (guardado == false) return;
                MessageBox.Show(this, "El servicio se guardó correctamente.", "Listo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Servicios", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private bool ValidarCampos()
        {
            errorProvider.Clear();

            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MostrarAviso("El nombre del servicio es obligatorio.", txtNombre);
                return false;
            }

            return true;
        }

        private void MostrarAviso(string mensaje, Control control)
        {
            errorProvider.SetError(control, mensaje);
            MessageBox.Show(this, mensaje, "Datos incompletos",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
