﻿using System;
using System.Windows.Forms;
using Modelos;
using Modelos.Conexion_DB;
using vista.Helpers;
using vista.Login;

namespace vista
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // La base se prepara antes de mostrar el login.
            try
            {
                if (Conexion.PrepararBaseDatos() == false) return;
            }
            catch (Exception ex)
            {
                MessageBox.Show(Ayuda.ObtenerMensajeAmigable(ex), "Base de datos",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                if (Usuario.ExisteAlguno() == false)
                {
                    using (frmConfiguracionInicial formulario = new frmConfiguracionInicial())
                    {
                        if (formulario.ShowDialog() != DialogResult.OK) return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Ayuda.ObtenerMensajeAmigable(ex), "Configuración inicial",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.Run(new LoginForm());
        }
    }
}
