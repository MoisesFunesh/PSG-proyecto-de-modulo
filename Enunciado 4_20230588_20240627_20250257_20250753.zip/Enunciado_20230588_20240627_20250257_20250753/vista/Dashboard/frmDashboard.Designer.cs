﻿namespace vista.Dashboard
{
    partial class frmDashboard
    {
        // <summary>
        // Variable del diseñador necesaria.
        // </summary>
        private System.ComponentModel.IContainer components = null;

        // <summary>
        // Limpiar los recursos que se estén usando.
        // </summary>
        // <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        // <summary>
        // Método necesario para admitir el Diseñador. No se puede modificar
        // el contenido de este método con el editor de código.
        // </summary>
        private void InitializeComponent()
        {
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.pnlContenido = new System.Windows.Forms.Panel();
            this.pnlTablas = new System.Windows.Forms.Panel();
            this.pnlAgenda = new System.Windows.Forms.Panel();
            this.dgvEventos = new System.Windows.Forms.DataGridView();
            this.colEvNombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEvTipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEvFecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEvEstado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblAgendaTitulo = new System.Windows.Forms.Label();
            this.pnlMisReservaciones = new System.Windows.Forms.Panel();
            this.dgvMisReservaciones = new System.Windows.Forms.DataGridView();
            this.colMrEvento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMrSalon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMrFecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMrEstado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMrTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblMisReservacionesTitulo = new System.Windows.Forms.Label();
            this.pnlDerecha = new System.Windows.Forms.Panel();
            this.pnlSalones = new System.Windows.Forms.Panel();
            this.dgvSalones = new System.Windows.Forms.DataGridView();
            this.colSalNombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSalCapacidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSalEstado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSalonesTitulo = new System.Windows.Forms.Label();
            this.pnlSeparador = new System.Windows.Forms.Panel();
            this.pnlEstados = new System.Windows.Forms.Panel();
            this.tblEstados = new System.Windows.Forms.TableLayoutPanel();
            this.lblEstadoConfirmado = new System.Windows.Forms.Label();
            this.lblEstadoPendiente = new System.Windows.Forms.Label();
            this.lblEstadoCancelado = new System.Windows.Forms.Label();
            this.lblEstadosTitulo = new System.Windows.Forms.Label();
            this.tblTarjetas = new System.Windows.Forms.TableLayoutPanel();
            this.pnlTarjeta1 = new System.Windows.Forms.Panel();
            this.lblT1Etiqueta = new System.Windows.Forms.Label();
            this.lblT1Valor = new System.Windows.Forms.Label();
            this.lblT1Detalle = new System.Windows.Forms.Label();
            this.pnlTarjeta2 = new System.Windows.Forms.Panel();
            this.lblT2Etiqueta = new System.Windows.Forms.Label();
            this.lblT2Valor = new System.Windows.Forms.Label();
            this.lblT2Detalle = new System.Windows.Forms.Label();
            this.pnlTarjeta3 = new System.Windows.Forms.Panel();
            this.lblT3Etiqueta = new System.Windows.Forms.Label();
            this.lblT3Valor = new System.Windows.Forms.Label();
            this.lblT3Detalle = new System.Windows.Forms.Label();
            this.pnlTarjeta4 = new System.Windows.Forms.Panel();
            this.lblT4Etiqueta = new System.Windows.Forms.Label();
            this.lblT4Valor = new System.Windows.Forms.Label();
            this.lblT4Detalle = new System.Windows.Forms.Label();
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.lblBienvenida = new System.Windows.Forms.Label();
            this.lblResumen = new System.Windows.Forms.Label();
            this.pnlEncabezado = new System.Windows.Forms.Panel();
            this.lblMigas = new System.Windows.Forms.Label();
            this.lblUsuarioEncabezado = new System.Windows.Forms.Label();
            this.pnlLineaEncabezado = new System.Windows.Forms.Panel();
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.pnlBotones = new System.Windows.Forms.FlowLayoutPanel();
            this.lblSeccionPrincipal = new System.Windows.Forms.Label();
            this.btnInicio = new System.Windows.Forms.Button();
            this.btnReservaciones = new System.Windows.Forms.Button();
            this.btnCotizaciones = new System.Windows.Forms.Button();
            this.lblSeccionGestion = new System.Windows.Forms.Label();
            this.btnAlertas = new System.Windows.Forms.Button();
            this.btnEventos = new System.Windows.Forms.Button();
            this.btnSalones = new System.Windows.Forms.Button();
            this.btnServicios = new System.Windows.Forms.Button();
            this.lblSeccionAdmin = new System.Windows.Forms.Label();
            this.btnUsuarios = new System.Windows.Forms.Button();
            this.pnlUsuario = new System.Windows.Forms.Panel();
            this.lblIniciales = new System.Windows.Forms.Label();
            this.lblNombreMenu = new System.Windows.Forms.Label();
            this.lblRolMenu = new System.Windows.Forms.Label();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.lblLogoLetra = new System.Windows.Forms.Label();
            this.lblLogoTitulo = new System.Windows.Forms.Label();
            this.lblLogoSubtitulo = new System.Windows.Forms.Label();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.lblEstadoConexion = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblEstadoBase = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblEspacio = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblEstadoUsuario = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblEstadoRol = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEventos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMisReservaciones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSalones)).BeginInit();
            this.pnlPrincipal.SuspendLayout();
            this.pnlContenido.SuspendLayout();
            this.pnlTablas.SuspendLayout();
            this.pnlAgenda.SuspendLayout();
            this.pnlMisReservaciones.SuspendLayout();
            this.pnlDerecha.SuspendLayout();
            this.pnlSalones.SuspendLayout();
            this.pnlSeparador.SuspendLayout();
            this.pnlEstados.SuspendLayout();
            this.tblEstados.SuspendLayout();
            this.tblTarjetas.SuspendLayout();
            this.pnlTarjeta1.SuspendLayout();
            this.pnlTarjeta2.SuspendLayout();
            this.pnlTarjeta3.SuspendLayout();
            this.pnlTarjeta4.SuspendLayout();
            this.pnlTitulo.SuspendLayout();
            this.pnlEncabezado.SuspendLayout();
            this.pnlLineaEncabezado.SuspendLayout();
            this.pnlMenu.SuspendLayout();
            this.pnlBotones.SuspendLayout();
            this.pnlUsuario.SuspendLayout();
            this.pnlLogo.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.Controls.Add(this.pnlContenido);
            this.pnlPrincipal.Controls.Add(this.pnlEncabezado);
            this.pnlPrincipal.BackColor = System.Drawing.Color.FromArgb(232, 237, 243);
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Size = new System.Drawing.Size(1040, 720);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.TabIndex = 0;
            // 
            // pnlContenido
            // 
            this.pnlContenido.Controls.Add(this.pnlTablas);
            this.pnlContenido.Controls.Add(this.tblTarjetas);
            this.pnlContenido.Controls.Add(this.pnlTitulo);
            this.pnlContenido.BackColor = System.Drawing.Color.FromArgb(232, 237, 243);
            this.pnlContenido.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContenido.Padding = new System.Windows.Forms.Padding(20, 20, 20, 20);
            this.pnlContenido.Size = new System.Drawing.Size(1040, 672);
            this.pnlContenido.Name = "pnlContenido";
            this.pnlContenido.TabIndex = 0;
            // 
            // pnlTablas
            // 
            this.pnlTablas.Controls.Add(this.pnlAgenda);
            this.pnlTablas.Controls.Add(this.pnlMisReservaciones);
            this.pnlTablas.Controls.Add(this.pnlDerecha);
            this.pnlTablas.BackColor = System.Drawing.Color.FromArgb(232, 237, 243);
            this.pnlTablas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTablas.Size = new System.Drawing.Size(1000, 400);
            this.pnlTablas.Name = "pnlTablas";
            this.pnlTablas.TabIndex = 0;
            // 
            // pnlAgenda
            // 
            this.pnlAgenda.Controls.Add(this.dgvEventos);
            this.pnlAgenda.Controls.Add(this.lblAgendaTitulo);
            this.pnlAgenda.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlAgenda.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAgenda.Size = new System.Drawing.Size(560, 400);
            this.pnlAgenda.Name = "pnlAgenda";
            this.pnlAgenda.TabIndex = 0;
            // 
            // dgvEventos
            // 
            this.dgvEventos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colEvNombre,
            this.colEvTipo,
            this.colEvFecha,
            this.colEvEstado});
            this.dgvEventos.AllowUserToAddRows = false;
            this.dgvEventos.AllowUserToDeleteRows = false;
            this.dgvEventos.AllowUserToResizeRows = false;
            this.dgvEventos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEventos.BackgroundColor = System.Drawing.Color.White;
            this.dgvEventos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvEventos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEventos.MultiSelect = false;
            this.dgvEventos.ReadOnly = true;
            this.dgvEventos.RowHeadersVisible = false;
            this.dgvEventos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEventos.Size = new System.Drawing.Size(300, 200);
            this.dgvEventos.Name = "dgvEventos";
            this.dgvEventos.TabIndex = 0;
            // 
            // colEvNombre
            // 
            this.colEvNombre.FillWeight = 120F;
            this.colEvNombre.HeaderText = "Evento";
            this.colEvNombre.MinimumWidth = 6;
            this.colEvNombre.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEvNombre.Name = "colEvNombre";
            // 
            // colEvTipo
            // 
            this.colEvTipo.FillWeight = 70F;
            this.colEvTipo.HeaderText = "Tipo";
            this.colEvTipo.MinimumWidth = 6;
            this.colEvTipo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEvTipo.Name = "colEvTipo";
            // 
            // colEvFecha
            // 
            this.colEvFecha.FillWeight = 70F;
            this.colEvFecha.HeaderText = "Fecha";
            this.colEvFecha.MinimumWidth = 6;
            this.colEvFecha.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEvFecha.Name = "colEvFecha";
            // 
            // colEvEstado
            // 
            this.colEvEstado.FillWeight = 70F;
            this.colEvEstado.HeaderText = "Estado";
            this.colEvEstado.MinimumWidth = 6;
            this.colEvEstado.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEvEstado.Name = "colEvEstado";
            // 
            // lblAgendaTitulo
            // 
            this.lblAgendaTitulo.AutoSize = false;
            this.lblAgendaTitulo.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblAgendaTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblAgendaTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblAgendaTitulo.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblAgendaTitulo.Size = new System.Drawing.Size(10, 42);
            this.lblAgendaTitulo.Padding = new System.Windows.Forms.Padding(16, 0, 0, 0);
            this.lblAgendaTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAgendaTitulo.Text = "Agenda de eventos";
            this.lblAgendaTitulo.Name = "lblAgendaTitulo";
            this.lblAgendaTitulo.TabIndex = 1;
            // 
            // pnlMisReservaciones
            // 
            this.pnlMisReservaciones.Controls.Add(this.dgvMisReservaciones);
            this.pnlMisReservaciones.Controls.Add(this.lblMisReservacionesTitulo);
            this.pnlMisReservaciones.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlMisReservaciones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMisReservaciones.Size = new System.Drawing.Size(560, 400);
            this.pnlMisReservaciones.Name = "pnlMisReservaciones";
            this.pnlMisReservaciones.TabIndex = 1;
            // 
            // dgvMisReservaciones
            // 
            this.dgvMisReservaciones.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMrEvento,
            this.colMrSalon,
            this.colMrFecha,
            this.colMrEstado,
            this.colMrTotal});
            this.dgvMisReservaciones.AllowUserToAddRows = false;
            this.dgvMisReservaciones.AllowUserToDeleteRows = false;
            this.dgvMisReservaciones.AllowUserToResizeRows = false;
            this.dgvMisReservaciones.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMisReservaciones.BackgroundColor = System.Drawing.Color.White;
            this.dgvMisReservaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvMisReservaciones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMisReservaciones.MultiSelect = false;
            this.dgvMisReservaciones.ReadOnly = true;
            this.dgvMisReservaciones.RowHeadersVisible = false;
            this.dgvMisReservaciones.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMisReservaciones.Size = new System.Drawing.Size(300, 200);
            this.dgvMisReservaciones.Name = "dgvMisReservaciones";
            this.dgvMisReservaciones.TabIndex = 0;
            // 
            // colMrEvento
            // 
            this.colMrEvento.FillWeight = 120F;
            this.colMrEvento.HeaderText = "Evento";
            this.colMrEvento.MinimumWidth = 6;
            this.colMrEvento.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colMrEvento.Name = "colMrEvento";
            // 
            // colMrSalon
            // 
            this.colMrSalon.FillWeight = 100F;
            this.colMrSalon.HeaderText = "Salón";
            this.colMrSalon.MinimumWidth = 6;
            this.colMrSalon.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colMrSalon.Name = "colMrSalon";
            // 
            // colMrFecha
            // 
            this.colMrFecha.FillWeight = 70F;
            this.colMrFecha.HeaderText = "Fecha";
            this.colMrFecha.MinimumWidth = 6;
            this.colMrFecha.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colMrFecha.Name = "colMrFecha";
            // 
            // colMrEstado
            // 
            this.colMrEstado.FillWeight = 70F;
            this.colMrEstado.HeaderText = "Estado";
            this.colMrEstado.MinimumWidth = 6;
            this.colMrEstado.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colMrEstado.Name = "colMrEstado";
            // 
            // colMrTotal
            // 
            this.colMrTotal.FillWeight = 70F;
            this.colMrTotal.HeaderText = "Total";
            this.colMrTotal.MinimumWidth = 6;
            this.colMrTotal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colMrTotal.Name = "colMrTotal";
            // 
            // lblMisReservacionesTitulo
            // 
            this.lblMisReservacionesTitulo.AutoSize = false;
            this.lblMisReservacionesTitulo.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblMisReservacionesTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblMisReservacionesTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblMisReservacionesTitulo.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblMisReservacionesTitulo.Size = new System.Drawing.Size(10, 42);
            this.lblMisReservacionesTitulo.Padding = new System.Windows.Forms.Padding(16, 0, 0, 0);
            this.lblMisReservacionesTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblMisReservacionesTitulo.Text = "Mis reservaciones";
            this.lblMisReservacionesTitulo.Name = "lblMisReservacionesTitulo";
            this.lblMisReservacionesTitulo.TabIndex = 1;
            // 
            // pnlDerecha
            // 
            this.pnlDerecha.Controls.Add(this.pnlSalones);
            this.pnlDerecha.Controls.Add(this.pnlSeparador);
            this.pnlDerecha.Controls.Add(this.pnlEstados);
            this.pnlDerecha.BackColor = System.Drawing.Color.FromArgb(232, 237, 243);
            this.pnlDerecha.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlDerecha.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.pnlDerecha.Size = new System.Drawing.Size(430, 400);
            this.pnlDerecha.Name = "pnlDerecha";
            this.pnlDerecha.TabIndex = 2;
            // 
            // pnlSalones
            // 
            this.pnlSalones.Controls.Add(this.dgvSalones);
            this.pnlSalones.Controls.Add(this.lblSalonesTitulo);
            this.pnlSalones.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlSalones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSalones.Size = new System.Drawing.Size(418, 300);
            this.pnlSalones.Name = "pnlSalones";
            this.pnlSalones.TabIndex = 0;
            // 
            // dgvSalones
            // 
            this.dgvSalones.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSalNombre,
            this.colSalCapacidad,
            this.colSalEstado});
            this.dgvSalones.AllowUserToAddRows = false;
            this.dgvSalones.AllowUserToDeleteRows = false;
            this.dgvSalones.AllowUserToResizeRows = false;
            this.dgvSalones.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSalones.BackgroundColor = System.Drawing.Color.White;
            this.dgvSalones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvSalones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSalones.MultiSelect = false;
            this.dgvSalones.ReadOnly = true;
            this.dgvSalones.RowHeadersVisible = false;
            this.dgvSalones.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSalones.Size = new System.Drawing.Size(300, 200);
            this.dgvSalones.Name = "dgvSalones";
            this.dgvSalones.TabIndex = 0;
            // 
            // colSalNombre
            // 
            this.colSalNombre.FillWeight = 100F;
            this.colSalNombre.HeaderText = "Salón";
            this.colSalNombre.MinimumWidth = 6;
            this.colSalNombre.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colSalNombre.Name = "colSalNombre";
            // 
            // colSalCapacidad
            // 
            this.colSalCapacidad.FillWeight = 40F;
            this.colSalCapacidad.HeaderText = "Cap.";
            this.colSalCapacidad.MinimumWidth = 6;
            this.colSalCapacidad.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colSalCapacidad.Name = "colSalCapacidad";
            // 
            // colSalEstado
            // 
            this.colSalEstado.FillWeight = 70F;
            this.colSalEstado.HeaderText = "Estado";
            this.colSalEstado.MinimumWidth = 6;
            this.colSalEstado.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colSalEstado.Name = "colSalEstado";
            // 
            // lblSalonesTitulo
            // 
            this.lblSalonesTitulo.AutoSize = false;
            this.lblSalonesTitulo.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblSalonesTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblSalonesTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblSalonesTitulo.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblSalonesTitulo.Size = new System.Drawing.Size(10, 42);
            this.lblSalonesTitulo.Padding = new System.Windows.Forms.Padding(16, 0, 0, 0);
            this.lblSalonesTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSalonesTitulo.Text = "Disponibilidad de salones";
            this.lblSalonesTitulo.Name = "lblSalonesTitulo";
            this.lblSalonesTitulo.TabIndex = 1;
            // 
            // pnlSeparador
            // 
            this.pnlSeparador.BackColor = System.Drawing.Color.FromArgb(232, 237, 243);
            this.pnlSeparador.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSeparador.Size = new System.Drawing.Size(418, 12);
            this.pnlSeparador.Name = "pnlSeparador";
            this.pnlSeparador.TabIndex = 1;
            // 
            // pnlEstados
            // 
            this.pnlEstados.Controls.Add(this.tblEstados);
            this.pnlEstados.Controls.Add(this.lblEstadosTitulo);
            this.pnlEstados.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlEstados.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlEstados.Size = new System.Drawing.Size(418, 130);
            this.pnlEstados.Name = "pnlEstados";
            this.pnlEstados.TabIndex = 2;
            // 
            // tblEstados
            // 
            this.tblEstados.Controls.Add(this.lblEstadoConfirmado, 0, 0);
            this.tblEstados.Controls.Add(this.lblEstadoPendiente, 1, 0);
            this.tblEstados.Controls.Add(this.lblEstadoCancelado, 2, 0);
            this.tblEstados.ColumnCount = 3;
            this.tblEstados.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33F));
            this.tblEstados.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33F));
            this.tblEstados.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.34F));
            this.tblEstados.RowCount = 1;
            this.tblEstados.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblEstados.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.tblEstados.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblEstados.Size = new System.Drawing.Size(418, 88);
            this.tblEstados.Name = "tblEstados";
            this.tblEstados.TabIndex = 0;
            // 
            // lblEstadoConfirmado
            // 
            this.lblEstadoConfirmado.AutoSize = false;
            this.lblEstadoConfirmado.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblEstadoConfirmado.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEstadoConfirmado.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblEstadoConfirmado.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblEstadoConfirmado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblEstadoConfirmado.Text = "";
            this.lblEstadoConfirmado.Name = "lblEstadoConfirmado";
            this.lblEstadoConfirmado.TabIndex = 0;
            // 
            // lblEstadoPendiente
            // 
            this.lblEstadoPendiente.AutoSize = false;
            this.lblEstadoPendiente.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblEstadoPendiente.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEstadoPendiente.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblEstadoPendiente.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblEstadoPendiente.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblEstadoPendiente.Text = "";
            this.lblEstadoPendiente.Name = "lblEstadoPendiente";
            this.lblEstadoPendiente.TabIndex = 1;
            // 
            // lblEstadoCancelado
            // 
            this.lblEstadoCancelado.AutoSize = false;
            this.lblEstadoCancelado.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblEstadoCancelado.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEstadoCancelado.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblEstadoCancelado.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblEstadoCancelado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblEstadoCancelado.Text = "";
            this.lblEstadoCancelado.Name = "lblEstadoCancelado";
            this.lblEstadoCancelado.TabIndex = 2;
            // 
            // lblEstadosTitulo
            // 
            this.lblEstadosTitulo.AutoSize = false;
            this.lblEstadosTitulo.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblEstadosTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblEstadosTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblEstadosTitulo.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblEstadosTitulo.Size = new System.Drawing.Size(10, 42);
            this.lblEstadosTitulo.Padding = new System.Windows.Forms.Padding(16, 0, 0, 0);
            this.lblEstadosTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblEstadosTitulo.Text = "Estado de eventos";
            this.lblEstadosTitulo.Name = "lblEstadosTitulo";
            this.lblEstadosTitulo.TabIndex = 1;
            // 
            // tblTarjetas
            // 
            this.tblTarjetas.Controls.Add(this.pnlTarjeta1, 0, 0);
            this.tblTarjetas.Controls.Add(this.pnlTarjeta2, 1, 0);
            this.tblTarjetas.Controls.Add(this.pnlTarjeta3, 2, 0);
            this.tblTarjetas.Controls.Add(this.pnlTarjeta4, 3, 0);
            this.tblTarjetas.ColumnCount = 4;
            this.tblTarjetas.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblTarjetas.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblTarjetas.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblTarjetas.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblTarjetas.RowCount = 1;
            this.tblTarjetas.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblTarjetas.BackColor = System.Drawing.Color.FromArgb(232, 237, 243);
            this.tblTarjetas.Dock = System.Windows.Forms.DockStyle.Top;
            this.tblTarjetas.Size = new System.Drawing.Size(1000, 126);
            this.tblTarjetas.Name = "tblTarjetas";
            this.tblTarjetas.TabIndex = 1;
            // 
            // pnlTarjeta1
            // 
            this.pnlTarjeta1.Controls.Add(this.lblT1Etiqueta);
            this.pnlTarjeta1.Controls.Add(this.lblT1Valor);
            this.pnlTarjeta1.Controls.Add(this.lblT1Detalle);
            this.pnlTarjeta1.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlTarjeta1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTarjeta1.Size = new System.Drawing.Size(200, 114);
            this.pnlTarjeta1.Margin = new System.Windows.Forms.Padding(0, 0, 12, 12);
            this.pnlTarjeta1.Name = "pnlTarjeta1";
            this.pnlTarjeta1.TabIndex = 0;
            // 
            // lblT1Etiqueta
            // 
            this.lblT1Etiqueta.AutoSize = true;
            this.lblT1Etiqueta.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT1Etiqueta.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblT1Etiqueta.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblT1Etiqueta.Location = new System.Drawing.Point(16, 14);
            this.lblT1Etiqueta.Text = "";
            this.lblT1Etiqueta.Name = "lblT1Etiqueta";
            this.lblT1Etiqueta.TabIndex = 0;
            // 
            // lblT1Valor
            // 
            this.lblT1Valor.AutoSize = true;
            this.lblT1Valor.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT1Valor.Font = new System.Drawing.Font("Segoe UI Semibold", 22F);
            this.lblT1Valor.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblT1Valor.Location = new System.Drawing.Point(14, 38);
            this.lblT1Valor.Text = "0";
            this.lblT1Valor.Name = "lblT1Valor";
            this.lblT1Valor.TabIndex = 1;
            // 
            // lblT1Detalle
            // 
            this.lblT1Detalle.AutoSize = true;
            this.lblT1Detalle.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT1Detalle.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblT1Detalle.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.lblT1Detalle.Location = new System.Drawing.Point(16, 90);
            this.lblT1Detalle.Text = "";
            this.lblT1Detalle.Name = "lblT1Detalle";
            this.lblT1Detalle.TabIndex = 2;
            // 
            // pnlTarjeta2
            // 
            this.pnlTarjeta2.Controls.Add(this.lblT2Etiqueta);
            this.pnlTarjeta2.Controls.Add(this.lblT2Valor);
            this.pnlTarjeta2.Controls.Add(this.lblT2Detalle);
            this.pnlTarjeta2.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlTarjeta2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTarjeta2.Size = new System.Drawing.Size(200, 114);
            this.pnlTarjeta2.Margin = new System.Windows.Forms.Padding(0, 0, 12, 12);
            this.pnlTarjeta2.Name = "pnlTarjeta2";
            this.pnlTarjeta2.TabIndex = 1;
            // 
            // lblT2Etiqueta
            // 
            this.lblT2Etiqueta.AutoSize = true;
            this.lblT2Etiqueta.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT2Etiqueta.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblT2Etiqueta.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblT2Etiqueta.Location = new System.Drawing.Point(16, 14);
            this.lblT2Etiqueta.Text = "";
            this.lblT2Etiqueta.Name = "lblT2Etiqueta";
            this.lblT2Etiqueta.TabIndex = 0;
            // 
            // lblT2Valor
            // 
            this.lblT2Valor.AutoSize = true;
            this.lblT2Valor.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT2Valor.Font = new System.Drawing.Font("Segoe UI Semibold", 22F);
            this.lblT2Valor.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblT2Valor.Location = new System.Drawing.Point(14, 38);
            this.lblT2Valor.Text = "0";
            this.lblT2Valor.Name = "lblT2Valor";
            this.lblT2Valor.TabIndex = 1;
            // 
            // lblT2Detalle
            // 
            this.lblT2Detalle.AutoSize = true;
            this.lblT2Detalle.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT2Detalle.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblT2Detalle.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.lblT2Detalle.Location = new System.Drawing.Point(16, 90);
            this.lblT2Detalle.Text = "";
            this.lblT2Detalle.Name = "lblT2Detalle";
            this.lblT2Detalle.TabIndex = 2;
            // 
            // pnlTarjeta3
            // 
            this.pnlTarjeta3.Controls.Add(this.lblT3Etiqueta);
            this.pnlTarjeta3.Controls.Add(this.lblT3Valor);
            this.pnlTarjeta3.Controls.Add(this.lblT3Detalle);
            this.pnlTarjeta3.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlTarjeta3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTarjeta3.Size = new System.Drawing.Size(200, 114);
            this.pnlTarjeta3.Margin = new System.Windows.Forms.Padding(0, 0, 12, 12);
            this.pnlTarjeta3.Name = "pnlTarjeta3";
            this.pnlTarjeta3.TabIndex = 2;
            // 
            // lblT3Etiqueta
            // 
            this.lblT3Etiqueta.AutoSize = true;
            this.lblT3Etiqueta.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT3Etiqueta.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblT3Etiqueta.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblT3Etiqueta.Location = new System.Drawing.Point(16, 14);
            this.lblT3Etiqueta.Text = "";
            this.lblT3Etiqueta.Name = "lblT3Etiqueta";
            this.lblT3Etiqueta.TabIndex = 0;
            // 
            // lblT3Valor
            // 
            this.lblT3Valor.AutoSize = true;
            this.lblT3Valor.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT3Valor.Font = new System.Drawing.Font("Segoe UI Semibold", 22F);
            this.lblT3Valor.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblT3Valor.Location = new System.Drawing.Point(14, 38);
            this.lblT3Valor.Text = "0";
            this.lblT3Valor.Name = "lblT3Valor";
            this.lblT3Valor.TabIndex = 1;
            // 
            // lblT3Detalle
            // 
            this.lblT3Detalle.AutoSize = true;
            this.lblT3Detalle.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT3Detalle.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblT3Detalle.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.lblT3Detalle.Location = new System.Drawing.Point(16, 90);
            this.lblT3Detalle.Text = "";
            this.lblT3Detalle.Name = "lblT3Detalle";
            this.lblT3Detalle.TabIndex = 2;
            // 
            // pnlTarjeta4
            // 
            this.pnlTarjeta4.Controls.Add(this.lblT4Etiqueta);
            this.pnlTarjeta4.Controls.Add(this.lblT4Valor);
            this.pnlTarjeta4.Controls.Add(this.lblT4Detalle);
            this.pnlTarjeta4.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlTarjeta4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTarjeta4.Size = new System.Drawing.Size(200, 114);
            this.pnlTarjeta4.Margin = new System.Windows.Forms.Padding(0, 0, 12, 12);
            this.pnlTarjeta4.Name = "pnlTarjeta4";
            this.pnlTarjeta4.TabIndex = 3;
            // 
            // lblT4Etiqueta
            // 
            this.lblT4Etiqueta.AutoSize = true;
            this.lblT4Etiqueta.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT4Etiqueta.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblT4Etiqueta.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblT4Etiqueta.Location = new System.Drawing.Point(16, 14);
            this.lblT4Etiqueta.Text = "";
            this.lblT4Etiqueta.Name = "lblT4Etiqueta";
            this.lblT4Etiqueta.TabIndex = 0;
            // 
            // lblT4Valor
            // 
            this.lblT4Valor.AutoSize = true;
            this.lblT4Valor.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT4Valor.Font = new System.Drawing.Font("Segoe UI Semibold", 22F);
            this.lblT4Valor.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblT4Valor.Location = new System.Drawing.Point(14, 38);
            this.lblT4Valor.Text = "0";
            this.lblT4Valor.Name = "lblT4Valor";
            this.lblT4Valor.TabIndex = 1;
            // 
            // lblT4Detalle
            // 
            this.lblT4Detalle.AutoSize = true;
            this.lblT4Detalle.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblT4Detalle.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblT4Detalle.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.lblT4Detalle.Location = new System.Drawing.Point(16, 90);
            this.lblT4Detalle.Text = "";
            this.lblT4Detalle.Name = "lblT4Detalle";
            this.lblT4Detalle.TabIndex = 2;
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.Controls.Add(this.lblBienvenida);
            this.pnlTitulo.Controls.Add(this.lblResumen);
            this.pnlTitulo.BackColor = System.Drawing.Color.FromArgb(232, 237, 243);
            this.pnlTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTitulo.Size = new System.Drawing.Size(1000, 66);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.TabIndex = 2;
            // 
            // lblBienvenida
            // 
            this.lblBienvenida.AutoSize = true;
            this.lblBienvenida.BackColor = System.Drawing.Color.FromArgb(232, 237, 243);
            this.lblBienvenida.Font = new System.Drawing.Font("Segoe UI Semibold", 18F);
            this.lblBienvenida.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblBienvenida.Location = new System.Drawing.Point(0, 0);
            this.lblBienvenida.Text = "";
            this.lblBienvenida.Name = "lblBienvenida";
            this.lblBienvenida.TabIndex = 0;
            // 
            // lblResumen
            // 
            this.lblResumen.AutoSize = true;
            this.lblResumen.BackColor = System.Drawing.Color.FromArgb(232, 237, 243);
            this.lblResumen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblResumen.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblResumen.Location = new System.Drawing.Point(2, 40);
            this.lblResumen.Text = "";
            this.lblResumen.Name = "lblResumen";
            this.lblResumen.TabIndex = 1;
            // 
            // pnlEncabezado
            // 
            this.pnlEncabezado.Controls.Add(this.lblMigas);
            this.pnlEncabezado.Controls.Add(this.lblUsuarioEncabezado);
            this.pnlEncabezado.Controls.Add(this.pnlLineaEncabezado);
            this.pnlEncabezado.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlEncabezado.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlEncabezado.Size = new System.Drawing.Size(1040, 48);
            this.pnlEncabezado.Name = "pnlEncabezado";
            this.pnlEncabezado.TabIndex = 1;
            // 
            // lblMigas
            // 
            this.lblMigas.AutoSize = true;
            this.lblMigas.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblMigas.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblMigas.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblMigas.Location = new System.Drawing.Point(20, 14);
            this.lblMigas.Text = "Inicio   ›   Dashboard";
            this.lblMigas.Name = "lblMigas";
            this.lblMigas.TabIndex = 0;
            // 
            // lblUsuarioEncabezado
            // 
            this.lblUsuarioEncabezado.AutoSize = false;
            this.lblUsuarioEncabezado.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblUsuarioEncabezado.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblUsuarioEncabezado.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblUsuarioEncabezado.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblUsuarioEncabezado.Size = new System.Drawing.Size(340, 47);
            this.lblUsuarioEncabezado.Padding = new System.Windows.Forms.Padding(0, 0, 18, 0);
            this.lblUsuarioEncabezado.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblUsuarioEncabezado.Text = "";
            this.lblUsuarioEncabezado.Name = "lblUsuarioEncabezado";
            this.lblUsuarioEncabezado.TabIndex = 1;
            // 
            // pnlLineaEncabezado
            // 
            this.pnlLineaEncabezado.BackColor = System.Drawing.Color.FromArgb(226, 232, 240);
            this.pnlLineaEncabezado.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlLineaEncabezado.Size = new System.Drawing.Size(1040, 1);
            this.pnlLineaEncabezado.Name = "pnlLineaEncabezado";
            this.pnlLineaEncabezado.TabIndex = 2;
            // 
            // pnlMenu
            // 
            this.pnlMenu.Controls.Add(this.pnlBotones);
            this.pnlMenu.Controls.Add(this.pnlUsuario);
            this.pnlMenu.Controls.Add(this.pnlLogo);
            this.pnlMenu.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenu.Size = new System.Drawing.Size(240, 720);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.TabIndex = 1;
            // 
            // pnlBotones
            // 
            this.pnlBotones.Controls.Add(this.lblSeccionPrincipal);
            this.pnlBotones.Controls.Add(this.btnInicio);
            this.pnlBotones.Controls.Add(this.btnReservaciones);
            this.pnlBotones.Controls.Add(this.btnCotizaciones);
            this.pnlBotones.Controls.Add(this.lblSeccionGestion);
            this.pnlBotones.Controls.Add(this.btnAlertas);
            this.pnlBotones.Controls.Add(this.btnEventos);
            this.pnlBotones.Controls.Add(this.btnSalones);
            this.pnlBotones.Controls.Add(this.btnServicios);
            this.pnlBotones.Controls.Add(this.lblSeccionAdmin);
            this.pnlBotones.Controls.Add(this.btnUsuarios);
            this.pnlBotones.AutoScroll = true;
            this.pnlBotones.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.pnlBotones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBotones.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.pnlBotones.Padding = new System.Windows.Forms.Padding(12, 8, 0, 0);
            this.pnlBotones.Size = new System.Drawing.Size(240, 540);
            this.pnlBotones.WrapContents = false;
            this.pnlBotones.Name = "pnlBotones";
            this.pnlBotones.TabIndex = 0;
            // 
            // lblSeccionPrincipal
            // 
            this.lblSeccionPrincipal.AutoSize = false;
            this.lblSeccionPrincipal.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.lblSeccionPrincipal.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblSeccionPrincipal.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.lblSeccionPrincipal.Location = new System.Drawing.Point(0, 0);
            this.lblSeccionPrincipal.Size = new System.Drawing.Size(216, 30);
            this.lblSeccionPrincipal.Padding = new System.Windows.Forms.Padding(8, 0, 0, 4);
            this.lblSeccionPrincipal.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblSeccionPrincipal.Text = "PRINCIPAL";
            this.lblSeccionPrincipal.Name = "lblSeccionPrincipal";
            this.lblSeccionPrincipal.TabIndex = 0;
            // 
            // btnInicio
            // 
            this.btnInicio.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.btnInicio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInicio.FlatAppearance.BorderSize = 0;
            this.btnInicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(22, 33, 58);
            this.btnInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInicio.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnInicio.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnInicio.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.btnInicio.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnInicio.Size = new System.Drawing.Size(216, 42);
            this.btnInicio.TabStop = false;
            this.btnInicio.Text = "📊   Dashboard";
            this.btnInicio.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInicio.UseVisualStyleBackColor = false;
            this.btnInicio.Name = "btnInicio";
            this.btnInicio.TabIndex = 1;
            this.btnInicio.Click += new System.EventHandler(this.btnInicio_Click);
            // 
            // btnReservaciones
            // 
            this.btnReservaciones.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.btnReservaciones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReservaciones.FlatAppearance.BorderSize = 0;
            this.btnReservaciones.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(22, 33, 58);
            this.btnReservaciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReservaciones.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnReservaciones.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnReservaciones.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.btnReservaciones.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnReservaciones.Size = new System.Drawing.Size(216, 42);
            this.btnReservaciones.TabStop = false;
            this.btnReservaciones.Text = "📋   Reservaciones";
            this.btnReservaciones.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReservaciones.UseVisualStyleBackColor = false;
            this.btnReservaciones.Name = "btnReservaciones";
            this.btnReservaciones.TabIndex = 2;
            this.btnReservaciones.Click += new System.EventHandler(this.btnReservaciones_Click);
            // 
            // btnCotizaciones
            // 
            this.btnCotizaciones.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.btnCotizaciones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCotizaciones.FlatAppearance.BorderSize = 0;
            this.btnCotizaciones.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(22, 33, 58);
            this.btnCotizaciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCotizaciones.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnCotizaciones.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnCotizaciones.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.btnCotizaciones.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnCotizaciones.Size = new System.Drawing.Size(216, 42);
            this.btnCotizaciones.TabStop = false;
            this.btnCotizaciones.Text = "💲   Cotizaciones";
            this.btnCotizaciones.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCotizaciones.UseVisualStyleBackColor = false;
            this.btnCotizaciones.Name = "btnCotizaciones";
            this.btnCotizaciones.TabIndex = 3;
            this.btnCotizaciones.Click += new System.EventHandler(this.btnCotizaciones_Click);
            // 
            // lblSeccionGestion
            // 
            this.lblSeccionGestion.AutoSize = false;
            this.lblSeccionGestion.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.lblSeccionGestion.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblSeccionGestion.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.lblSeccionGestion.Location = new System.Drawing.Point(0, 0);
            this.lblSeccionGestion.Size = new System.Drawing.Size(216, 30);
            this.lblSeccionGestion.Padding = new System.Windows.Forms.Padding(8, 0, 0, 4);
            this.lblSeccionGestion.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblSeccionGestion.Text = "GESTIÓN";
            this.lblSeccionGestion.Name = "lblSeccionGestion";
            this.lblSeccionGestion.TabIndex = 4;
            // 
            // btnAlertas
            // 
            this.btnAlertas.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.btnAlertas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlertas.FlatAppearance.BorderSize = 0;
            this.btnAlertas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(22, 33, 58);
            this.btnAlertas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlertas.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnAlertas.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnAlertas.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.btnAlertas.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnAlertas.Size = new System.Drawing.Size(216, 42);
            this.btnAlertas.TabStop = false;
            this.btnAlertas.Text = "🔔   Alertas";
            this.btnAlertas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAlertas.UseVisualStyleBackColor = false;
            this.btnAlertas.Name = "btnAlertas";
            this.btnAlertas.TabIndex = 5;
            this.btnAlertas.Click += new System.EventHandler(this.btnAlertas_Click);
            // 
            // btnEventos
            // 
            this.btnEventos.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.btnEventos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEventos.FlatAppearance.BorderSize = 0;
            this.btnEventos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(22, 33, 58);
            this.btnEventos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEventos.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnEventos.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnEventos.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.btnEventos.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnEventos.Size = new System.Drawing.Size(216, 42);
            this.btnEventos.TabStop = false;
            this.btnEventos.Text = "📅   Eventos";
            this.btnEventos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEventos.UseVisualStyleBackColor = false;
            this.btnEventos.Name = "btnEventos";
            this.btnEventos.TabIndex = 6;
            this.btnEventos.Click += new System.EventHandler(this.btnEventos_Click);
            // 
            // btnSalones
            // 
            this.btnSalones.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.btnSalones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalones.FlatAppearance.BorderSize = 0;
            this.btnSalones.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(22, 33, 58);
            this.btnSalones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalones.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnSalones.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnSalones.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.btnSalones.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSalones.Size = new System.Drawing.Size(216, 42);
            this.btnSalones.TabStop = false;
            this.btnSalones.Text = "🏛   Salones";
            this.btnSalones.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalones.UseVisualStyleBackColor = false;
            this.btnSalones.Name = "btnSalones";
            this.btnSalones.TabIndex = 7;
            this.btnSalones.Click += new System.EventHandler(this.btnSalones_Click);
            // 
            // btnServicios
            // 
            this.btnServicios.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.btnServicios.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnServicios.FlatAppearance.BorderSize = 0;
            this.btnServicios.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(22, 33, 58);
            this.btnServicios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnServicios.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnServicios.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnServicios.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.btnServicios.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnServicios.Size = new System.Drawing.Size(216, 42);
            this.btnServicios.TabStop = false;
            this.btnServicios.Text = "⭐   Servicios";
            this.btnServicios.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnServicios.UseVisualStyleBackColor = false;
            this.btnServicios.Name = "btnServicios";
            this.btnServicios.TabIndex = 8;
            this.btnServicios.Click += new System.EventHandler(this.btnServicios_Click);
            // 
            // lblSeccionAdmin
            // 
            this.lblSeccionAdmin.AutoSize = false;
            this.lblSeccionAdmin.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.lblSeccionAdmin.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblSeccionAdmin.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.lblSeccionAdmin.Location = new System.Drawing.Point(0, 0);
            this.lblSeccionAdmin.Size = new System.Drawing.Size(216, 30);
            this.lblSeccionAdmin.Padding = new System.Windows.Forms.Padding(8, 0, 0, 4);
            this.lblSeccionAdmin.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblSeccionAdmin.Text = "ADMINISTRACIÓN";
            this.lblSeccionAdmin.Name = "lblSeccionAdmin";
            this.lblSeccionAdmin.TabIndex = 9;
            // 
            // btnUsuarios
            // 
            this.btnUsuarios.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.btnUsuarios.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUsuarios.FlatAppearance.BorderSize = 0;
            this.btnUsuarios.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(22, 33, 58);
            this.btnUsuarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUsuarios.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnUsuarios.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnUsuarios.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.btnUsuarios.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnUsuarios.Size = new System.Drawing.Size(216, 42);
            this.btnUsuarios.TabStop = false;
            this.btnUsuarios.Text = "👥   Usuarios";
            this.btnUsuarios.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUsuarios.UseVisualStyleBackColor = false;
            this.btnUsuarios.Name = "btnUsuarios";
            this.btnUsuarios.TabIndex = 10;
            this.btnUsuarios.Click += new System.EventHandler(this.btnUsuarios_Click);
            // 
            // pnlUsuario
            // 
            this.pnlUsuario.Controls.Add(this.lblIniciales);
            this.pnlUsuario.Controls.Add(this.lblNombreMenu);
            this.pnlUsuario.Controls.Add(this.lblRolMenu);
            this.pnlUsuario.Controls.Add(this.btnCerrarSesion);
            this.pnlUsuario.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.pnlUsuario.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlUsuario.Size = new System.Drawing.Size(240, 116);
            this.pnlUsuario.Name = "pnlUsuario";
            this.pnlUsuario.TabIndex = 1;
            // 
            // lblIniciales
            // 
            this.lblIniciales.AutoSize = false;
            this.lblIniciales.BackColor = System.Drawing.Color.FromArgb(99, 102, 241);
            this.lblIniciales.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblIniciales.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblIniciales.Location = new System.Drawing.Point(20, 12);
            this.lblIniciales.Size = new System.Drawing.Size(36, 36);
            this.lblIniciales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIniciales.Text = "";
            this.lblIniciales.Name = "lblIniciales";
            this.lblIniciales.TabIndex = 0;
            // 
            // lblNombreMenu
            // 
            this.lblNombreMenu.AutoSize = false;
            this.lblNombreMenu.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.lblNombreMenu.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblNombreMenu.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblNombreMenu.Location = new System.Drawing.Point(64, 11);
            this.lblNombreMenu.Size = new System.Drawing.Size(168, 20);
            this.lblNombreMenu.Text = "";
            this.lblNombreMenu.Name = "lblNombreMenu";
            this.lblNombreMenu.TabIndex = 1;
            // 
            // lblRolMenu
            // 
            this.lblRolMenu.AutoSize = false;
            this.lblRolMenu.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.lblRolMenu.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblRolMenu.ForeColor = System.Drawing.Color.FromArgb(147, 197, 253);
            this.lblRolMenu.Location = new System.Drawing.Point(64, 31);
            this.lblRolMenu.Size = new System.Drawing.Size(168, 18);
            this.lblRolMenu.Text = "";
            this.lblRolMenu.Name = "lblRolMenu";
            this.lblRolMenu.TabIndex = 2;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.btnCerrarSesion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrarSesion.FlatAppearance.BorderSize = 0;
            this.btnCerrarSesion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(59, 22, 32);
            this.btnCerrarSesion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarSesion.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnCerrarSesion.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnCerrarSesion.Location = new System.Drawing.Point(12, 62);
            this.btnCerrarSesion.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnCerrarSesion.Size = new System.Drawing.Size(216, 38);
            this.btnCerrarSesion.Text = "⏻   Cerrar sesión";
            this.btnCerrarSesion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCerrarSesion.UseVisualStyleBackColor = false;
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.TabIndex = 3;
            this.btnCerrarSesion.Click += new System.EventHandler(this.btnCerrarSesion_Click);
            // 
            // pnlLogo
            // 
            this.pnlLogo.Controls.Add(this.lblLogoLetra);
            this.pnlLogo.Controls.Add(this.lblLogoTitulo);
            this.pnlLogo.Controls.Add(this.lblLogoSubtitulo);
            this.pnlLogo.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Size = new System.Drawing.Size(240, 64);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.TabIndex = 2;
            // 
            // lblLogoLetra
            // 
            this.lblLogoLetra.AutoSize = false;
            this.lblLogoLetra.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.lblLogoLetra.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblLogoLetra.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblLogoLetra.Location = new System.Drawing.Point(20, 15);
            this.lblLogoLetra.Size = new System.Drawing.Size(34, 34);
            this.lblLogoLetra.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblLogoLetra.Text = "P";
            this.lblLogoLetra.Name = "lblLogoLetra";
            this.lblLogoLetra.TabIndex = 0;
            // 
            // lblLogoTitulo
            // 
            this.lblLogoTitulo.AutoSize = true;
            this.lblLogoTitulo.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.lblLogoTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblLogoTitulo.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblLogoTitulo.Location = new System.Drawing.Point(64, 12);
            this.lblLogoTitulo.Text = "PSG";
            this.lblLogoTitulo.Name = "lblLogoTitulo";
            this.lblLogoTitulo.TabIndex = 1;
            // 
            // lblLogoSubtitulo
            // 
            this.lblLogoSubtitulo.AutoSize = true;
            this.lblLogoSubtitulo.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.lblLogoSubtitulo.Font = new System.Drawing.Font("Segoe UI", 7.5F);
            this.lblLogoSubtitulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblLogoSubtitulo.Location = new System.Drawing.Point(64, 34);
            this.lblLogoSubtitulo.Text = "Planificador de Servicios y Galas";
            this.lblLogoSubtitulo.Name = "lblLogoSubtitulo";
            this.lblLogoSubtitulo.TabIndex = 2;
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblEstadoConexion,
            this.lblEstadoBase,
            this.lblEspacio,
            this.lblEstadoUsuario,
            this.lblEstadoRol});
            this.statusStrip.BackColor = System.Drawing.Color.FromArgb(241, 245, 249);
            this.statusStrip.Location = new System.Drawing.Point(0, 738);
            this.statusStrip.Size = new System.Drawing.Size(1280, 22);
            this.statusStrip.SizingGrip = false;
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.TabIndex = 2;
            // 
            // lblEstadoConexion
            // 
            this.lblEstadoConexion.ForeColor = System.Drawing.Color.FromArgb(4, 120, 87);
            this.lblEstadoConexion.Text = "● Conectado";
            this.lblEstadoConexion.Name = "lblEstadoConexion";
            // 
            // lblEstadoBase
            // 
            this.lblEstadoBase.Text = "SQL Server · PSG";
            this.lblEstadoBase.Name = "lblEstadoBase";
            // 
            // lblEspacio
            // 
            this.lblEspacio.Spring = true;
            this.lblEspacio.Name = "lblEspacio";
            // 
            // lblEstadoUsuario
            // 
            this.lblEstadoUsuario.Text = "Usuario:";
            this.lblEstadoUsuario.Name = "lblEstadoUsuario";
            // 
            // lblEstadoRol
            // 
            this.lblEstadoRol.Text = "Rol:";
            this.lblEstadoRol.Name = "lblEstadoRol";
            // 
            // frmDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(232, 237, 243);
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MinimumSize = new System.Drawing.Size(1100, 650);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PSG · Planificador de Servicios y Galas";
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.pnlMenu);
            this.Controls.Add(this.statusStrip);
            this.Name = "frmDashboard";
            this.Load += new System.EventHandler(this.frmDashboard_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmDashboard_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSalones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMisReservaciones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEventos)).EndInit();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            this.pnlUsuario.ResumeLayout(false);
            this.pnlUsuario.PerformLayout();
            this.pnlBotones.ResumeLayout(false);
            this.pnlBotones.PerformLayout();
            this.pnlMenu.ResumeLayout(false);
            this.pnlMenu.PerformLayout();
            this.pnlLineaEncabezado.ResumeLayout(false);
            this.pnlLineaEncabezado.PerformLayout();
            this.pnlEncabezado.ResumeLayout(false);
            this.pnlEncabezado.PerformLayout();
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.pnlTarjeta4.ResumeLayout(false);
            this.pnlTarjeta4.PerformLayout();
            this.pnlTarjeta3.ResumeLayout(false);
            this.pnlTarjeta3.PerformLayout();
            this.pnlTarjeta2.ResumeLayout(false);
            this.pnlTarjeta2.PerformLayout();
            this.pnlTarjeta1.ResumeLayout(false);
            this.pnlTarjeta1.PerformLayout();
            this.tblTarjetas.ResumeLayout(false);
            this.tblTarjetas.PerformLayout();
            this.tblEstados.ResumeLayout(false);
            this.tblEstados.PerformLayout();
            this.pnlEstados.ResumeLayout(false);
            this.pnlEstados.PerformLayout();
            this.pnlSeparador.ResumeLayout(false);
            this.pnlSeparador.PerformLayout();
            this.pnlSalones.ResumeLayout(false);
            this.pnlSalones.PerformLayout();
            this.pnlDerecha.ResumeLayout(false);
            this.pnlDerecha.PerformLayout();
            this.pnlMisReservaciones.ResumeLayout(false);
            this.pnlMisReservaciones.PerformLayout();
            this.pnlAgenda.ResumeLayout(false);
            this.pnlAgenda.PerformLayout();
            this.pnlTablas.ResumeLayout(false);
            this.pnlTablas.PerformLayout();
            this.pnlContenido.ResumeLayout(false);
            this.pnlContenido.PerformLayout();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.Panel pnlContenido;
        private System.Windows.Forms.Panel pnlTablas;
        private System.Windows.Forms.Panel pnlAgenda;
        private System.Windows.Forms.DataGridView dgvEventos;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEvNombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEvTipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEvFecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEvEstado;
        private System.Windows.Forms.Label lblAgendaTitulo;
        private System.Windows.Forms.Panel pnlMisReservaciones;
        private System.Windows.Forms.DataGridView dgvMisReservaciones;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMrEvento;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMrSalon;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMrFecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMrEstado;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMrTotal;
        private System.Windows.Forms.Label lblMisReservacionesTitulo;
        private System.Windows.Forms.Panel pnlDerecha;
        private System.Windows.Forms.Panel pnlSalones;
        private System.Windows.Forms.DataGridView dgvSalones;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSalNombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSalCapacidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSalEstado;
        private System.Windows.Forms.Label lblSalonesTitulo;
        private System.Windows.Forms.Panel pnlSeparador;
        private System.Windows.Forms.Panel pnlEstados;
        private System.Windows.Forms.TableLayoutPanel tblEstados;
        private System.Windows.Forms.Label lblEstadoConfirmado;
        private System.Windows.Forms.Label lblEstadoPendiente;
        private System.Windows.Forms.Label lblEstadoCancelado;
        private System.Windows.Forms.Label lblEstadosTitulo;
        private System.Windows.Forms.TableLayoutPanel tblTarjetas;
        private System.Windows.Forms.Panel pnlTarjeta1;
        private System.Windows.Forms.Label lblT1Etiqueta;
        private System.Windows.Forms.Label lblT1Valor;
        private System.Windows.Forms.Label lblT1Detalle;
        private System.Windows.Forms.Panel pnlTarjeta2;
        private System.Windows.Forms.Label lblT2Etiqueta;
        private System.Windows.Forms.Label lblT2Valor;
        private System.Windows.Forms.Label lblT2Detalle;
        private System.Windows.Forms.Panel pnlTarjeta3;
        private System.Windows.Forms.Label lblT3Etiqueta;
        private System.Windows.Forms.Label lblT3Valor;
        private System.Windows.Forms.Label lblT3Detalle;
        private System.Windows.Forms.Panel pnlTarjeta4;
        private System.Windows.Forms.Label lblT4Etiqueta;
        private System.Windows.Forms.Label lblT4Valor;
        private System.Windows.Forms.Label lblT4Detalle;
        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Label lblBienvenida;
        private System.Windows.Forms.Label lblResumen;
        private System.Windows.Forms.Panel pnlEncabezado;
        private System.Windows.Forms.Label lblMigas;
        private System.Windows.Forms.Label lblUsuarioEncabezado;
        private System.Windows.Forms.Panel pnlLineaEncabezado;
        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.FlowLayoutPanel pnlBotones;
        private System.Windows.Forms.Label lblSeccionPrincipal;
        private System.Windows.Forms.Button btnInicio;
        private System.Windows.Forms.Button btnReservaciones;
        private System.Windows.Forms.Button btnCotizaciones;
        private System.Windows.Forms.Label lblSeccionGestion;
        private System.Windows.Forms.Button btnAlertas;
        private System.Windows.Forms.Button btnEventos;
        private System.Windows.Forms.Button btnSalones;
        private System.Windows.Forms.Button btnServicios;
        private System.Windows.Forms.Label lblSeccionAdmin;
        private System.Windows.Forms.Button btnUsuarios;
        private System.Windows.Forms.Panel pnlUsuario;
        private System.Windows.Forms.Label lblIniciales;
        private System.Windows.Forms.Label lblNombreMenu;
        private System.Windows.Forms.Label lblRolMenu;
        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.Label lblLogoLetra;
        private System.Windows.Forms.Label lblLogoTitulo;
        private System.Windows.Forms.Label lblLogoSubtitulo;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel lblEstadoConexion;
        private System.Windows.Forms.ToolStripStatusLabel lblEstadoBase;
        private System.Windows.Forms.ToolStripStatusLabel lblEspacio;
        private System.Windows.Forms.ToolStripStatusLabel lblEstadoUsuario;
        private System.Windows.Forms.ToolStripStatusLabel lblEstadoRol;
    }
}
