﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Alertas;
using vista.Cotizaciones;
using vista.Eventos;
using vista.Helpers;
using vista.Reservaciones;
using vista.Salones;
using vista.Servicios;
using vista.Usuarios;

namespace vista.Dashboard
{
    public partial class frmDashboard : Form
    {
        private Usuario usuarioActual;

        // true cuando el usuario pulso "Cerrar sesion", para no preguntar dos veces al cerrar la ventana
        private bool cierrePorSesion;

        public frmDashboard()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            Estilos.EstilizarTabla(dgvEventos);
            Estilos.EstilizarTabla(dgvSalones);
            Estilos.EstilizarTabla(dgvMisReservaciones);

            usuarioActual = Sesion.UsuarioActual;
            cierrePorSesion = false;

            this.WindowState = FormWindowState.Maximized;
            MostrarDatosDelUsuario();
            AplicarPermisosPorRol();
        }

        private void frmDashboard_Load(object sender, EventArgs e)
        {
            try
            {
                CargarDashboard();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Panel principal",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MostrarDatosDelUsuario()
        {
            lblIniciales.Text = Herramientas.Iniciales(usuarioActual.Nombre);
            lblNombreMenu.Text = usuarioActual.Nombre;
            lblRolMenu.Text = usuarioActual.Rol.ToString();
            lblUsuarioEncabezado.Text = usuarioActual.Nombre + "  ·  " + usuarioActual.Rol.ToString();
            lblEstadoUsuario.Text = "Usuario: " + usuarioActual.Nombre;
            lblEstadoRol.Text = "Rol: " + usuarioActual.Rol.ToString();
        }

        // muestra u oculta las opciones segun los permisos guardados en la base
        private void AplicarPermisosPorRol()
        {
            try
            {
                btnEventos.Visible = Permiso.TienePermiso(usuarioActual.IdPerfil, "Eventos", "consultar");
                btnSalones.Visible = Permiso.TienePermiso(usuarioActual.IdPerfil, "Salones", "consultar");
                btnServicios.Visible = Permiso.TienePermiso(usuarioActual.IdPerfil, "Servicios", "consultar");
                btnReservaciones.Visible = Permiso.TienePermiso(usuarioActual.IdPerfil, "Reservaciones", "consultar");
                btnCotizaciones.Visible = Permiso.TienePermiso(usuarioActual.IdPerfil, "Cotizaciones", "consultar");
                btnAlertas.Visible = Permiso.TienePermiso(usuarioActual.IdPerfil, "Alertas", "consultar");
                btnUsuarios.Visible = Permiso.TienePermiso(usuarioActual.IdPerfil, "Usuarios", "consultar");
            }
            catch
            {
                AplicarPermisosDeRespaldo();
            }

            if (usuarioActual.Rol == UsuarioRol.Cliente)
            {
                lblSeccionGestion.Visible = false;
                lblSeccionAdmin.Visible = false;
                pnlAgenda.Visible = false;
                pnlDerecha.Visible = false;
                pnlMisReservaciones.Visible = true;
                pnlTarjeta3.Visible = false;
                pnlTarjeta4.Visible = false;
                tblTarjetas.ColumnStyles[0].Width = 50;
                tblTarjetas.ColumnStyles[1].Width = 50;
                tblTarjetas.ColumnStyles[2].Width = 0;
                tblTarjetas.ColumnStyles[3].Width = 0;
            }
            else pnlMisReservaciones.Visible = false;
        }

        private void AplicarPermisosDeRespaldo()
        {
            UsuarioRol rol = usuarioActual.Rol;
            if (rol == UsuarioRol.Organizador)
            {
                btnUsuarios.Visible = false;
                btnAlertas.Visible = false;
            }
            if (rol == UsuarioRol.Cliente)
            {
                btnEventos.Visible = false;
                btnSalones.Visible = false;
                btnServicios.Visible = false;
                btnAlertas.Visible = false;
                btnUsuarios.Visible = false;
            }
        }

        // lee la base de datos y llena las tarjetas y las tablas segun el rol
        private void CargarDashboard()
        {
            if (usuarioActual.Rol == UsuarioRol.Cliente)
            {
                CargarPanelCliente();
            }
            else
            {
                CargarPanelPersonal();
            }
        }

        private void PonerTarjeta(int numero, string etiqueta, string valor, string detalle)
        {
            if (numero == 1)
            {
                lblT1Etiqueta.Text = etiqueta;
                lblT1Valor.Text = valor;
                lblT1Detalle.Text = detalle;
            }
            else if (numero == 2)
            {
                lblT2Etiqueta.Text = etiqueta;
                lblT2Valor.Text = valor;
                lblT2Detalle.Text = detalle;
            }
            else if (numero == 3)
            {
                lblT3Etiqueta.Text = etiqueta;
                lblT3Valor.Text = valor;
                lblT3Detalle.Text = detalle;
            }
            else
            {
                lblT4Etiqueta.Text = etiqueta;
                lblT4Valor.Text = valor;
                lblT4Detalle.Text = detalle;
            }
        }

        private void CargarPanelCliente()
        {
            lblBienvenida.Text = "Mi Panel";
            lblResumen.Text = "Resumen de su evento y reservación";

            Reservacion[] misReservaciones = Reservacion.ObtenerPorCliente(usuarioActual.Id);
            Cotizacion[] misCotizaciones = Cotizacion.ObtenerPorCliente(usuarioActual.Id);

            PonerTarjeta(1, "Reservaciones activas", Reservacion.ContarActivas(misReservaciones).ToString(),
                "Consulte su estado abajo");
            PonerTarjeta(2, "Cotizaciones pendientes", Cotizacion.ContarPendientes(misCotizaciones).ToString(),
                "Revíselas en el menú Cotizaciones");

            dgvMisReservaciones.Rows.Clear();
            for (int i = 0; i < misReservaciones.Length; i++)
            {
                Reservacion reservacion = misReservaciones[i];
                int fila = dgvMisReservaciones.Rows.Add(
                    reservacion.EventoNombre,
                    reservacion.SalonNombre,
                    Herramientas.FormatoFecha(reservacion.Fecha),
                    reservacion.Estado,
                    Herramientas.FormatoDinero(reservacion.Total)
                );
                Estilos.ColorearEstado(dgvMisReservaciones.Rows[fila].Cells["colMrEstado"]);
            }
        }

        private void CargarPanelPersonal()
        {
            string primerNombre = usuarioActual.Nombre.Split(' ')[0];
            lblBienvenida.Text = "Bienvenido, " + primerNombre;
            lblResumen.Text = "Resumen operativo del sistema";

            Evento[] eventos = Evento.ObtenerTodos();
            Salon[] salones = Salon.ObtenerTodos();

            if (usuarioActual.Rol == UsuarioRol.Administrador)
            {
                Usuario[] usuarios = Usuario.ObtenerTodos();

                PonerTarjeta(1, "Eventos totales", eventos.Length.ToString(),
                    Evento.ContarPorEstado(eventos, "Confirmado") + " confirmados");
                PonerTarjeta(2, "Salones disponibles",
                    Salon.ContarPorEstado(salones, "Disponible") + "/" + salones.Length,
                    Salon.ContarPorEstado(salones, "Ocupado") + " en uso actualmente");
                PonerTarjeta(3, "Ingresos confirmados", Herramientas.FormatoDinero(Evento.SumarMontoConfirmado(eventos)),
                    "Suma de eventos confirmados");
                PonerTarjeta(4, "Usuarios", Usuario.ContarTotal(usuarios).ToString(),
                    Usuario.ContarPorRol(usuarios, UsuarioRol.Administrador) + " admin · " +
                    Usuario.ContarPorRol(usuarios, UsuarioRol.Organizador) + " org · " +
                    Usuario.ContarPorRol(usuarios, UsuarioRol.Cliente) + " clientes");
            }
            else
            {
                Reservacion[] reservaciones = Reservacion.ObtenerTodas();
                Servicio[] servicios = Servicio.ObtenerTodos();
                int serviciosActivos = Servicio.ContarActivos(servicios);

                PonerTarjeta(1, "Eventos activos", Evento.ContarActivos(eventos).ToString(),
                    Evento.ContarPorEstado(eventos, "Pendiente") + " pendientes");
                PonerTarjeta(2, "Reservas pendientes", Reservacion.ContarPorEstado(reservaciones, "Pendiente").ToString(),
                    "Requieren confirmación");
                PonerTarjeta(3, "Salones en uso", Salon.ContarPorEstado(salones, "Ocupado").ToString(),
                    "De " + salones.Length + " salones");
                PonerTarjeta(4, "Servicios activos", serviciosActivos.ToString(),
                    (servicios.Length - serviciosActivos) + " inactivos");
            }

            // agenda: los primeros 8 eventos (ya vienen ordenados por fecha)
            dgvEventos.Rows.Clear();
            for (int i = 0; i < eventos.Length && i < 8; i++)
            {
                int fila = dgvEventos.Rows.Add(
                    eventos[i].Nombre,
                    eventos[i].Tipo,
                    Herramientas.FormatoFecha(eventos[i].Fecha),
                    eventos[i].Estado
                );
                Estilos.ColorearEstado(dgvEventos.Rows[fila].Cells["colEvEstado"]);
            }

            dgvSalones.Rows.Clear();
            for (int i = 0; i < salones.Length; i++)
            {
                int fila = dgvSalones.Rows.Add(
                    salones[i].Nombre,
                    salones[i].Capacidad.ToString(),
                    salones[i].Estado
                );
                Estilos.ColorearEstado(dgvSalones.Rows[fila].Cells["colSalEstado"]);
            }

            // cuantos eventos hay en cada estado
            MostrarConteoEstado(lblEstadoConfirmado, eventos, "Confirmado");
            MostrarConteoEstado(lblEstadoPendiente, eventos, "Pendiente");
            MostrarConteoEstado(lblEstadoCancelado, eventos, "Cancelado");
        }

        private void MostrarConteoEstado(Label etiqueta, Evento[] eventos, string estado)
        {
            etiqueta.Text = Evento.ContarPorEstado(eventos, estado) + "\n" + estado;
            etiqueta.ForeColor = Estilos.ObtenerColorEstado(estado);
        }

        // abre una pantalla del sistema y, al cerrarla, refresca los numeros del dashboard
        private void AbrirPantalla(Form pantalla)
        {
            pantalla.ShowDialog(this);
            pantalla.Dispose();
            CargarDashboard();
        }

        private void btnInicio_Click(object sender, EventArgs e)
        {
            CargarDashboard();
        }

        private void btnReservaciones_Click(object sender, EventArgs e)
        {
            AbrirPantalla(new frmReservaciones());
        }

        private void btnCotizaciones_Click(object sender, EventArgs e)
        {
            if (usuarioActual.Rol == UsuarioRol.Cliente) AbrirPantalla(new frmCotizaciones());
            else AbrirPantalla(new frmGestionCotizaciones());
        }

        private void btnAlertas_Click(object sender, EventArgs e)
        {
            AbrirPantalla(new frmCentroAlertas());
        }

        private void btnEventos_Click(object sender, EventArgs e)
        {
            AbrirPantalla(new frmEventos());
        }

        private void btnSalones_Click(object sender, EventArgs e)
        {
            AbrirPantalla(new frmSalones());
        }

        private void btnServicios_Click(object sender, EventArgs e)
        {
            AbrirPantalla(new frmServicios());
        }

        private void btnUsuarios_Click(object sender, EventArgs e)
        {
            AbrirPantalla(new frmGestionUsuarios());
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            if (Herramientas.Confirmar(this, "¿Desea cerrar la sesión?"))
            {
                // el login revisa Sesion.UsuarioActual en su evento FormClosed
                // para decidir si vuelve a mostrarse o si cierra el programa
                Sesion.UsuarioActual = null;
                cierrePorSesion = true;
                this.Close();
            }
        }

        private void frmDashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing && cierrePorSesion == false)
            {
                if (Herramientas.Confirmar(this, "¿Desea salir del sistema?") == false)
                {
                    e.Cancel = true;
                }
            }
        }
    }
}
