﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Eventos
{
    public partial class frmEventoEditar : Form
    {
        // Muestra el error junto al campo.
        private ErrorProvider errorProvider = new ErrorProvider();

        // si es null estamos agregando un evento nuevo, si no, estamos editando ese evento
        private Evento eventoEditar = null;

        public frmEventoEditar()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.AcceptButton = btnGuardar;
            this.CancelButton = btnCancelar;
        }

        public frmEventoEditar(Evento evento) : this()
        {
            eventoEditar = evento;
            lblTitulo.Text = "Editar evento";
            this.Text = "PSG · Editar evento";
        }

        private void frmEventoEditar_Load(object sender, EventArgs e)
        {
            try
            {
            for (int i = 0; i < Catalogos.TiposEvento.Length; i++)
            {
                cboTipo.Items.Add(Catalogos.TiposEvento[i]);
            }
            for (int i = 0; i < Catalogos.EstadosEvento.Length; i++)
            {
                cboEstado.Items.Add(Catalogos.EstadosEvento[i]);
            }

            cboSalon.DisplayMember = "Nombre";
            cboSalon.ValueMember = "Id";
            cboSalon.DataSource = Salon.ObtenerTodos();

            cboCliente.DisplayMember = "Nombre";
            cboCliente.ValueMember = "Id";
            cboCliente.DataSource = Usuario.ObtenerClientes();

            if (eventoEditar == null)
            {
                cboTipo.SelectedIndex = 0;
                cboEstado.SelectedItem = "Pendiente";
                dtpFecha.Value = DateTime.Today;
            }
            else
            {
                txtNombre.Text = eventoEditar.Nombre;
                cboTipo.SelectedItem = eventoEditar.Tipo;
                dtpFecha.Value = eventoEditar.Fecha;
                cboSalon.SelectedValue = eventoEditar.SalonId;
                cboCliente.SelectedValue = eventoEditar.ClienteId;
                cboEstado.SelectedItem = eventoEditar.Estado;
                nudMonto.Value = eventoEditar.Monto;
            }

            if (cboTipo.SelectedIndex == -1) cboTipo.SelectedIndex = 0;
            if (cboEstado.SelectedIndex == -1) cboEstado.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Eventos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult = DialogResult.Cancel;
                this.Close();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidarCampos() == false) return;
                Evento evento = new Evento();
                evento.Nombre = txtNombre.Text.Trim();
                evento.Tipo = cboTipo.SelectedItem.ToString();
                evento.Fecha = dtpFecha.Value.Date;
                evento.SalonId = Convert.ToInt32(cboSalon.SelectedValue);
                evento.ClienteId = Convert.ToInt32(cboCliente.SelectedValue);
                evento.Estado = cboEstado.SelectedItem.ToString();
                evento.Monto = nudMonto.Value;
                bool guardado;
                if (eventoEditar == null) guardado = Evento.Agregar(evento);
                else
                {
                    evento.Id = eventoEditar.Id;
                    guardado = Evento.Actualizar(evento);
                }
                if (guardado == false) return;
                MessageBox.Show(this, "El evento se guardó correctamente.", "Listo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Eventos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidarCampos()
        {
            errorProvider.Clear();

            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MostrarAviso("El nombre del evento es obligatorio.", txtNombre);
                return false;
            }
            if (cboSalon.SelectedValue == null)
            {
                MostrarAviso("Seleccione un salón.", cboSalon);
                return false;
            }
            if (cboCliente.SelectedValue == null)
            {
                MostrarAviso("Seleccione un cliente.", cboCliente);
                return false;
            }

            if (dtpFecha.Value.Date < DateTime.Today)
            {
                MostrarAviso("La fecha del evento no puede ser anterior a hoy.", dtpFecha);
                return false;
            }

            int idSalonSeleccionado = Convert.ToInt32(cboSalon.SelectedValue);
            if (Salon.PuedeUsarse(idSalonSeleccionado) == false && cboEstado.SelectedItem.ToString() != "Cancelado")
            {
                MostrarAviso("El salón está en mantenimiento y no se puede reservar.", cboSalon);
                return false;
            }

            // regla principal: un salon no puede tener dos eventos el mismo dia (los cancelados no cuentan)
            int idActual = 0;
            if (eventoEditar != null)
            {
                idActual = eventoEditar.Id;
            }
            if (cboEstado.SelectedItem.ToString() != "Cancelado")
            {
                if (Evento.SalonOcupado(idSalonSeleccionado, dtpFecha.Value.Date, idActual))
                {
                    MostrarAviso("Ese salón ya tiene otro evento el " + dtpFecha.Value.ToString("dd/MM/yyyy") + ".", dtpFecha);
                    return false;
                }
            }

            return true;
        }

        private void MostrarAviso(string mensaje, Control control)
        {
            errorProvider.SetError(control, mensaje);
            MessageBox.Show(this, mensaje, "Datos incompletos",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
