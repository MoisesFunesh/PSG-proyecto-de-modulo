﻿namespace vista.Eventos
{
    partial class frmEventoEditar
    {
        // <summary>
        // Variable del diseñador necesaria.
        // </summary>
        private System.ComponentModel.IContainer components = null;

        // <summary>
        // Limpiar los recursos que se estén usando.
        // </summary>
        // <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        // <summary>
        // Método necesario para admitir el Diseñador. No se puede modificar
        // el contenido de este método con el editor de código.
        // </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblEtNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lblEtTipo = new System.Windows.Forms.Label();
            this.cboTipo = new System.Windows.Forms.ComboBox();
            this.lblEtFecha = new System.Windows.Forms.Label();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.lblEtSalon = new System.Windows.Forms.Label();
            this.cboSalon = new System.Windows.Forms.ComboBox();
            this.lblEtCliente = new System.Windows.Forms.Label();
            this.cboCliente = new System.Windows.Forms.ComboBox();
            this.lblEtEstado = new System.Windows.Forms.Label();
            this.cboEstado = new System.Windows.Forms.ComboBox();
            this.lblEtMonto = new System.Windows.Forms.Label();
            this.nudMonto = new System.Windows.Forms.NumericUpDown();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudMonto)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblTitulo.Location = new System.Drawing.Point(24, 16);
            this.lblTitulo.Text = "Nuevo evento";
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            // 
            // lblEtNombre
            // 
            this.lblEtNombre.AutoSize = false;
            this.lblEtNombre.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtNombre.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtNombre.Location = new System.Drawing.Point(24, 66);
            this.lblEtNombre.Size = new System.Drawing.Size(412, 18);
            this.lblEtNombre.Text = "NOMBRE DEL EVENTO";
            this.lblEtNombre.Name = "lblEtNombre";
            this.lblEtNombre.TabIndex = 1;
            // 
            // txtNombre
            // 
            this.txtNombre.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtNombre.Location = new System.Drawing.Point(24, 86);
            this.txtNombre.Size = new System.Drawing.Size(412, 27);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.TabIndex = 2;
            // 
            // lblEtTipo
            // 
            this.lblEtTipo.AutoSize = false;
            this.lblEtTipo.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtTipo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtTipo.Location = new System.Drawing.Point(24, 130);
            this.lblEtTipo.Size = new System.Drawing.Size(412, 18);
            this.lblEtTipo.Text = "TIPO";
            this.lblEtTipo.Name = "lblEtTipo";
            this.lblEtTipo.TabIndex = 3;
            // 
            // cboTipo
            // 
            this.cboTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTipo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboTipo.FormattingEnabled = true;
            this.cboTipo.Location = new System.Drawing.Point(24, 150);
            this.cboTipo.Size = new System.Drawing.Size(412, 25);
            this.cboTipo.Name = "cboTipo";
            this.cboTipo.TabIndex = 4;
            // 
            // lblEtFecha
            // 
            this.lblEtFecha.AutoSize = false;
            this.lblEtFecha.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtFecha.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtFecha.Location = new System.Drawing.Point(24, 194);
            this.lblEtFecha.Size = new System.Drawing.Size(412, 18);
            this.lblEtFecha.Text = "FECHA";
            this.lblEtFecha.Name = "lblEtFecha";
            this.lblEtFecha.TabIndex = 5;
            // 
            // dtpFecha
            // 
            this.dtpFecha.CustomFormat = "dd/MM/yyyy";
            this.dtpFecha.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFecha.Location = new System.Drawing.Point(24, 214);
            this.dtpFecha.Size = new System.Drawing.Size(412, 25);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.TabIndex = 6;
            // 
            // lblEtSalon
            // 
            this.lblEtSalon.AutoSize = false;
            this.lblEtSalon.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtSalon.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtSalon.Location = new System.Drawing.Point(24, 258);
            this.lblEtSalon.Size = new System.Drawing.Size(412, 18);
            this.lblEtSalon.Text = "SALÓN";
            this.lblEtSalon.Name = "lblEtSalon";
            this.lblEtSalon.TabIndex = 7;
            // 
            // cboSalon
            // 
            this.cboSalon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSalon.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboSalon.FormattingEnabled = true;
            this.cboSalon.Location = new System.Drawing.Point(24, 278);
            this.cboSalon.Size = new System.Drawing.Size(412, 25);
            this.cboSalon.Name = "cboSalon";
            this.cboSalon.TabIndex = 8;
            // 
            // lblEtCliente
            // 
            this.lblEtCliente.AutoSize = false;
            this.lblEtCliente.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtCliente.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtCliente.Location = new System.Drawing.Point(24, 322);
            this.lblEtCliente.Size = new System.Drawing.Size(412, 18);
            this.lblEtCliente.Text = "CLIENTE";
            this.lblEtCliente.Name = "lblEtCliente";
            this.lblEtCliente.TabIndex = 9;
            // 
            // cboCliente
            // 
            this.cboCliente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCliente.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboCliente.FormattingEnabled = true;
            this.cboCliente.Location = new System.Drawing.Point(24, 342);
            this.cboCliente.Size = new System.Drawing.Size(412, 25);
            this.cboCliente.Name = "cboCliente";
            this.cboCliente.TabIndex = 10;
            // 
            // lblEtEstado
            // 
            this.lblEtEstado.AutoSize = false;
            this.lblEtEstado.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtEstado.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtEstado.Location = new System.Drawing.Point(24, 386);
            this.lblEtEstado.Size = new System.Drawing.Size(412, 18);
            this.lblEtEstado.Text = "ESTADO";
            this.lblEtEstado.Name = "lblEtEstado";
            this.lblEtEstado.TabIndex = 11;
            // 
            // cboEstado
            // 
            this.cboEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEstado.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboEstado.FormattingEnabled = true;
            this.cboEstado.Location = new System.Drawing.Point(24, 406);
            this.cboEstado.Size = new System.Drawing.Size(412, 25);
            this.cboEstado.Name = "cboEstado";
            this.cboEstado.TabIndex = 12;
            // 
            // lblEtMonto
            // 
            this.lblEtMonto.AutoSize = false;
            this.lblEtMonto.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtMonto.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtMonto.Location = new System.Drawing.Point(24, 450);
            this.lblEtMonto.Size = new System.Drawing.Size(412, 18);
            this.lblEtMonto.Text = "MONTO ESTIMADO";
            this.lblEtMonto.Name = "lblEtMonto";
            this.lblEtMonto.TabIndex = 13;
            // 
            // nudMonto
            // 
            this.nudMonto.DecimalPlaces = 2;
            this.nudMonto.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.nudMonto.Location = new System.Drawing.Point(24, 470);
            this.nudMonto.Maximum = new decimal(new int[] {1000000000, 0, 0, 0});
            this.nudMonto.Size = new System.Drawing.Size(412, 25);
            this.nudMonto.ThousandsSeparator = true;
            this.nudMonto.Name = "nudMonto";
            this.nudMonto.TabIndex = 14;
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelar.FlatAppearance.BorderSize = 1;
            this.btnCancelar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(226, 232, 240);
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.btnCancelar.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.btnCancelar.Location = new System.Drawing.Point(326, 522);
            this.btnCancelar.Size = new System.Drawing.Size(110, 36);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.TabIndex = 15;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.btnGuardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.btnGuardar.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnGuardar.Location = new System.Drawing.Point(198, 522);
            this.btnGuardar.Size = new System.Drawing.Size(120, 36);
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.TabIndex = 16;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // frmEventoEditar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.ClientSize = new System.Drawing.Size(460, 582);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PSG · Evento";
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblEtNombre);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lblEtTipo);
            this.Controls.Add(this.cboTipo);
            this.Controls.Add(this.lblEtFecha);
            this.Controls.Add(this.dtpFecha);
            this.Controls.Add(this.lblEtSalon);
            this.Controls.Add(this.cboSalon);
            this.Controls.Add(this.lblEtCliente);
            this.Controls.Add(this.cboCliente);
            this.Controls.Add(this.lblEtEstado);
            this.Controls.Add(this.cboEstado);
            this.Controls.Add(this.lblEtMonto);
            this.Controls.Add(this.nudMonto);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnGuardar);
            this.Name = "frmEventoEditar";
            this.Load += new System.EventHandler(this.frmEventoEditar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudMonto)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblEtNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblEtTipo;
        private System.Windows.Forms.ComboBox cboTipo;
        private System.Windows.Forms.Label lblEtFecha;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.Label lblEtSalon;
        private System.Windows.Forms.ComboBox cboSalon;
        private System.Windows.Forms.Label lblEtCliente;
        private System.Windows.Forms.ComboBox cboCliente;
        private System.Windows.Forms.Label lblEtEstado;
        private System.Windows.Forms.ComboBox cboEstado;
        private System.Windows.Forms.Label lblEtMonto;
        private System.Windows.Forms.NumericUpDown nudMonto;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGuardar;
    }
}
