﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Eventos
{
    public partial class frmEventos : Form
    {
        // todos los registros que trajo la base y los que se ven en la tabla despues de buscar
        private Evento[] todos;
        private Evento[] mostrados;

        public frmEventos()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            Estilos.EstilizarTabla(dgvDatos);
            todos = new Evento[0];
            mostrados = new Evento[0];
        }

        private void frmEventos_Load(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Eventos", "consultar") == false)
            {
                Herramientas.MostrarAviso(this, "No tiene permiso para consultar eventos.");
                Close();
                return;
            }
            PermisosUI.AplicarBotones("Eventos", btnNuevo, btnEditar, btnEliminar);
            CargarDatos();
        }

        // vuelve a leer la base de datos y actualiza la tabla
        private void CargarDatos()
        {
            try
            {
                todos = Evento.ObtenerTodos();
                AplicarFiltro();
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Eventos", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void AplicarFiltro()
        {
            mostrados = Evento.Buscar(todos, txtBuscar.Text);

            dgvDatos.Rows.Clear();
            for (int i = 0; i < mostrados.Length; i++)
            {
                Evento evento = mostrados[i];

                int fila = dgvDatos.Rows.Add(
                    evento.Id.ToString("000"),
                    evento.Nombre,
                    evento.Tipo,
                    Herramientas.FormatoFecha(evento.Fecha),
                    evento.SalonNombre,
                    evento.ClienteNombre,
                    evento.Estado,
                    Herramientas.FormatoDinero(evento.Monto)
                );
                dgvDatos.Rows[fila].Tag = evento;
                Estilos.ColorearEstado(dgvDatos.Rows[fila].Cells["colEstado"]);
            }

            lblConteo.Text = mostrados.Length + " registros";
        }

        // devuelve el registro que esta seleccionado en la tabla (o null si no hay)
        private Evento ObtenerSeleccionado()
        {
            if (dgvDatos.CurrentRow == null) return null;
            return dgvDatos.CurrentRow.Tag as Evento;
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            AplicarFiltro();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Eventos", "crear") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para crear eventos."); return; }
            frmEventoEditar editor = new frmEventoEditar();
            if (editor.ShowDialog(this) == DialogResult.OK)
            {
                CargarDatos();
            }
            editor.Dispose();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            EditarSeleccionado();
        }

        private void dgvDatos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && btnEditar.Visible)
            {
                EditarSeleccionado();
            }
        }

        private void EditarSeleccionado()
        {
            if (PermisosUI.Tiene("Eventos", "editar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para editar eventos."); return; }
            Evento seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un registro de la tabla.");
                return;
            }

            frmEventoEditar editor = new frmEventoEditar(seleccionado);
            if (editor.ShowDialog(this) == DialogResult.OK)
            {
                CargarDatos();
            }
            editor.Dispose();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Eventos", "eliminar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para cancelar eventos."); return; }
            Evento seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un registro de la tabla.");
                return;
            }

            if (Herramientas.Confirmar(this, "¿Desea eliminar \"" + seleccionado.Nombre + "\"?\nEsta acción no se puede deshacer.") == false)
            {
                return;
            }

            try
            {
                if (Evento.Eliminar(seleccionado.Id))
                {
                    Herramientas.MostrarAviso(this, "El evento se eliminó o se canceló correctamente.");
                    CargarDatos();
                }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Eventos", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
