using Modelos;

namespace vista.Helpers
{
    public static class PermisosUI
    {
        public static bool Tiene(string modulo, string accion)
        {
            if (Sesion.UsuarioActual == null) return false;
            try
            {
                return Permiso.TienePermiso(Sesion.UsuarioActual.IdPerfil, modulo, accion);
            }
            catch
            {
                return false;
            }
        }

        public static void AplicarBotones(string modulo, System.Windows.Forms.Button nuevo,
            System.Windows.Forms.Button editar, System.Windows.Forms.Button eliminar)
        {
            if (nuevo != null) nuevo.Visible = Tiene(modulo, "crear");
            if (editar != null) editar.Visible = Tiene(modulo, "editar");
            if (eliminar != null) eliminar.Visible = Tiene(modulo, "eliminar");
        }
    }
}
