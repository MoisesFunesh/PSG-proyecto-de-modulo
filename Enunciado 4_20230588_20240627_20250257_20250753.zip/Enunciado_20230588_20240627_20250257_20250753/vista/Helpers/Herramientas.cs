﻿using System;
using System.Windows.Forms;

namespace vista.Helpers
{
    // funciones sueltas que usan varios formularios
    public static class Herramientas
    {
        // saca las iniciales de un nombre, por ejemplo "Carlos Mendoza" -> "CM"
        public static string Iniciales(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre)) return "?";

            string[] partes = nombre.Trim().Split(' ');
            string iniciales = "";
            for (int i = 0; i < partes.Length && iniciales.Length < 2; i++)
            {
                if (partes[i].Length > 0)
                {
                    iniciales = iniciales + partes[i].Substring(0, 1).ToUpper();
                }
            }
            return iniciales;
        }

        // escribe un monto como dinero, por ejemplo 8500 -> $8,500
        public static string FormatoDinero(decimal monto)
        {
            return "$" + monto.ToString("N0");
        }

        public static string FormatoFecha(DateTime fecha)
        {
            return fecha.ToString("dd/MM/yyyy");
        }

        public static void MostrarAviso(IWin32Window dueno, string mensaje)
        {
            MessageBox.Show(dueno, mensaje, "PSG", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static bool Confirmar(IWin32Window dueno, string mensaje)
        {
            DialogResult respuesta = MessageBox.Show(dueno, mensaje, "PSG",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            return respuesta == DialogResult.Yes;
        }
    }
}
