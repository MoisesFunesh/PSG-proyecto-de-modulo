﻿using System.Drawing;
using System.Windows.Forms;

namespace vista.Helpers
{
    // colores y estilos que se usan en todos los formularios, para que se vean parecidos
    public static class Estilos
    {
        public static readonly Color ColorMarino = Color.FromArgb(11, 19, 35);
        public static readonly Color ColorPrimario = Color.FromArgb(37, 99, 235);
        public static readonly Color ColorPrimarioClaro = Color.FromArgb(219, 234, 254);
        public static readonly Color ColorFondo = Color.FromArgb(243, 244, 246);
        public static readonly Color ColorTarjeta = Color.White;
        public static readonly Color ColorBorde = Color.FromArgb(226, 232, 240);
        public static readonly Color ColorTextoTitulo = Color.FromArgb(15, 23, 42);
        public static readonly Color ColorTextoNormal = Color.FromArgb(51, 65, 85);
        public static readonly Color ColorTextoGris = Color.FromArgb(100, 116, 139);
        public static readonly Color ColorFilaAlterna = Color.FromArgb(248, 250, 252);

        public static readonly Font FuenteTexto = new Font("Segoe UI", 9.5F);
        public static readonly Font FuenteTextoNegrita = new Font("Segoe UI Semibold", 9.5F);
        public static readonly Font FuenteEncabezado = new Font("Segoe UI Semibold", 8F);

        public static void EstilizarBotonPrimario(Button boton)
        {
            if (boton == null) return;
            boton.BackColor = ColorPrimario;
            boton.ForeColor = Color.White;
            boton.FlatStyle = FlatStyle.Flat;
            boton.FlatAppearance.BorderSize = 0;
            boton.Font = FuenteTextoNegrita;
            boton.Cursor = Cursors.Hand;
            boton.UseVisualStyleBackColor = false;
        }

        public static void EstilizarBotonSecundario(Button boton)
        {
            if (boton == null) return;
            boton.BackColor = Color.White;
            boton.ForeColor = ColorTextoNormal;
            boton.FlatStyle = FlatStyle.Flat;
            boton.FlatAppearance.BorderColor = ColorBorde;
            boton.FlatAppearance.BorderSize = 1;
            boton.Font = FuenteTextoNegrita;
            boton.Cursor = Cursors.Hand;
            boton.UseVisualStyleBackColor = false;
        }

        // le da estilo a una tabla (DataGridView) sin tocar sus columnas ni sus datos
        public static void EstilizarTabla(DataGridView dgv)
        {
            if (dgv == null) return;

            dgv.EnableHeadersVisualStyles = false;
            dgv.BorderStyle = BorderStyle.None;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.GridColor = Color.FromArgb(241, 245, 249);
            dgv.BackgroundColor = ColorTarjeta;

            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = ColorTextoGris;
            dgv.ColumnHeadersDefaultCellStyle.Font = FuenteEncabezado;
            dgv.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(248, 250, 252);
            dgv.ColumnHeadersDefaultCellStyle.SelectionForeColor = ColorTextoGris;
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv.ColumnHeadersDefaultCellStyle.Padding = new Padding(6, 0, 0, 0);
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = 40;

            dgv.DefaultCellStyle.Font = FuenteTexto;
            dgv.DefaultCellStyle.ForeColor = ColorTextoTitulo;
            dgv.DefaultCellStyle.BackColor = ColorTarjeta;
            dgv.DefaultCellStyle.SelectionBackColor = ColorPrimarioClaro;
            dgv.DefaultCellStyle.SelectionForeColor = ColorTextoTitulo;
            dgv.DefaultCellStyle.Padding = new Padding(6, 0, 0, 0);

            dgv.RowTemplate.Height = 38;
            dgv.RowHeadersVisible = false;
        }

        // pinta el texto de la celda segun su estado (Confirmado en verde, Cancelado en rojo, etc.)
        public static void ColorearEstado(DataGridViewCell celda)
        {
            if (celda == null || celda.Value == null) return;

            string estado = celda.Value.ToString();
            celda.Style.ForeColor = ObtenerColorEstado(estado);
            celda.Style.Font = FuenteTextoNegrita;
        }

        public static Color ObtenerColorEstado(string estado)
        {
            if (estado == "Confirmado" || estado == "Confirmada" || estado == "Disponible" ||
                estado == "Activo" || estado == "Aceptada" || estado == "Cliente")
            {
                return Color.FromArgb(4, 120, 87);
            }
            if (estado == "Pendiente") return Color.FromArgb(180, 83, 9);
            if (estado == "Cancelado" || estado == "Cancelada" || estado == "Rechazada")
            {
                return Color.FromArgb(220, 38, 38);
            }
            if (estado == "Ocupado" || estado == "Organizador") return Color.FromArgb(29, 78, 216);
            if (estado == "Mantenimiento") return Color.FromArgb(194, 65, 12);
            if (estado == "Administrador") return Color.FromArgb(109, 40, 217);
            if (estado == "Inactivo") return Color.FromArgb(100, 116, 139);
            return ColorTextoTitulo;
        }
    }
}
