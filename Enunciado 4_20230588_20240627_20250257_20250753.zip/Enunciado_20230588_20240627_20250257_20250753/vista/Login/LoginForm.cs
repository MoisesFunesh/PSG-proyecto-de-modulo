﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Dashboard;

namespace vista.Login
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.AcceptButton = btnIngresar;
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            IntentarLogin();
        }

        private void IntentarLogin()
        {
            OcultarError();

            if (string.IsNullOrWhiteSpace(txtUsuario.Text))
            {
                MostrarError("Ingrese su correo.");
                txtUsuario.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(txtContrasena.Text))
            {
                MostrarError("Ingrese su contraseña.");
                txtContrasena.Focus();
                return;
            }

            btnIngresar.Enabled = false;
            this.Cursor = Cursors.WaitCursor;

            LoginResult resultado = Usuario.Login(txtUsuario.Text, txtContrasena.Text);

            this.Cursor = Cursors.Default;
            btnIngresar.Enabled = true;

            if (resultado.Exitoso)
            {
                Sesion.UsuarioActual = resultado.Usuario;
                AbrirDashboard();
            }
            else
            {
                MostrarError(resultado.Mensaje);
            }
        }

        private void MostrarError(string mensaje)
        {
            lblError.Text = mensaje;
        }

        private void OcultarError()
        {
            lblError.Text = "";
        }

        private void AbrirDashboard()
        {
            frmDashboard dashboard = new frmDashboard();
            this.Hide();
            dashboard.FormClosed += dashboard_FormClosed;
            dashboard.Show();
        }

        // vuelve al login (si cerro sesion) o cierra la aplicacion (si cerro la ventana)
        private void dashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Sesion.UsuarioActual == null)
            {
                txtContrasena.Text = "";
                OcultarError();
                this.Show();
                txtContrasena.Focus();
            }
            else
            {
                this.Close();
            }
        }
    }
}
