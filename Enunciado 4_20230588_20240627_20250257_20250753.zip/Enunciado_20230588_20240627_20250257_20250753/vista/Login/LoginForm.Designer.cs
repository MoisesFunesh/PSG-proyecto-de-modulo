﻿namespace vista.Login
{
    partial class LoginForm
    {
        // <summary>
        // Variable del diseñador necesaria.
        // </summary>
        private System.ComponentModel.IContainer components = null;

        // <summary>
        // Limpiar los recursos que se estén usando.
        // </summary>
        // <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        // <summary>
        // Método necesario para admitir el Diseñador. No se puede modificar
        // el contenido de este método con el editor de código.
        // </summary>
        private void InitializeComponent()
        {
            this.pnlDerecha = new System.Windows.Forms.Panel();
            this.pnlTarjeta = new System.Windows.Forms.Panel();
            this.pnlBarra = new System.Windows.Forms.Panel();
            this.lblBienvenido = new System.Windows.Forms.Label();
            this.lblAyuda = new System.Windows.Forms.Label();
            this.lblEtUsuario = new System.Windows.Forms.Label();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.lblEtContrasena = new System.Windows.Forms.Label();
            this.txtContrasena = new System.Windows.Forms.TextBox();
            this.lblError = new System.Windows.Forms.Label();
            this.btnIngresar = new System.Windows.Forms.Button();
            this.pnlLinea = new System.Windows.Forms.Panel();
            this.lblPie = new System.Windows.Forms.Label();
            this.pnlIzquierda = new System.Windows.Forms.Panel();
            this.lblSistema = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.lblSubtituloMarca = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.lblTecnologia = new System.Windows.Forms.Label();
            this.lblFranja = new System.Windows.Forms.Label();
            this.pnlDerecha.SuspendLayout();
            this.pnlTarjeta.SuspendLayout();
            this.pnlBarra.SuspendLayout();
            this.pnlLinea.SuspendLayout();
            this.pnlIzquierda.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlDerecha
            // 
            this.pnlDerecha.Controls.Add(this.pnlTarjeta);
            this.pnlDerecha.BackColor = System.Drawing.Color.FromArgb(240, 244, 249);
            this.pnlDerecha.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDerecha.Size = new System.Drawing.Size(480, 620);
            this.pnlDerecha.Name = "pnlDerecha";
            this.pnlDerecha.TabIndex = 0;
            // 
            // pnlTarjeta
            // 
            this.pnlTarjeta.Controls.Add(this.pnlBarra);
            this.pnlTarjeta.Controls.Add(this.lblBienvenido);
            this.pnlTarjeta.Controls.Add(this.lblAyuda);
            this.pnlTarjeta.Controls.Add(this.lblEtUsuario);
            this.pnlTarjeta.Controls.Add(this.txtUsuario);
            this.pnlTarjeta.Controls.Add(this.lblEtContrasena);
            this.pnlTarjeta.Controls.Add(this.txtContrasena);
            this.pnlTarjeta.Controls.Add(this.lblError);
            this.pnlTarjeta.Controls.Add(this.btnIngresar);
            this.pnlTarjeta.Controls.Add(this.pnlLinea);
            this.pnlTarjeta.Controls.Add(this.lblPie);
            this.pnlTarjeta.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlTarjeta.Location = new System.Drawing.Point(50, 75);
            this.pnlTarjeta.Size = new System.Drawing.Size(380, 470);
            this.pnlTarjeta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTarjeta.Name = "pnlTarjeta";
            this.pnlTarjeta.TabIndex = 0;
            // 
            // pnlBarra
            // 
            this.pnlBarra.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.pnlBarra.Location = new System.Drawing.Point(0, 0);
            this.pnlBarra.Size = new System.Drawing.Size(380, 5);
            this.pnlBarra.Name = "pnlBarra";
            this.pnlBarra.TabIndex = 0;
            // 
            // lblBienvenido
            // 
            this.lblBienvenido.AutoSize = false;
            this.lblBienvenido.Font = new System.Drawing.Font("Segoe UI Semibold", 16F);
            this.lblBienvenido.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblBienvenido.Location = new System.Drawing.Point(0, 28);
            this.lblBienvenido.Size = new System.Drawing.Size(380, 34);
            this.lblBienvenido.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBienvenido.Text = "Bienvenido";
            this.lblBienvenido.Name = "lblBienvenido";
            this.lblBienvenido.TabIndex = 1;
            // 
            // lblAyuda
            // 
            this.lblAyuda.AutoSize = false;
            this.lblAyuda.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblAyuda.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblAyuda.Location = new System.Drawing.Point(0, 65);
            this.lblAyuda.Size = new System.Drawing.Size(380, 22);
            this.lblAyuda.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAyuda.Text = "Ingrese sus credenciales para acceder";
            this.lblAyuda.Name = "lblAyuda";
            this.lblAyuda.TabIndex = 2;
            // 
            // lblEtUsuario
            // 
            this.lblEtUsuario.AutoSize = false;
            this.lblEtUsuario.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtUsuario.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtUsuario.Location = new System.Drawing.Point(36, 110);
            this.lblEtUsuario.Size = new System.Drawing.Size(308, 18);
            this.lblEtUsuario.Text = "USUARIO (CORREO)";
            this.lblEtUsuario.Name = "lblEtUsuario";
            this.lblEtUsuario.TabIndex = 3;
            // 
            // txtUsuario
            // 
            this.txtUsuario.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtUsuario.Location = new System.Drawing.Point(36, 130);
            this.txtUsuario.Size = new System.Drawing.Size(308, 27);
            this.txtUsuario.Text = "";
            this.txtUsuario.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtUsuario.MaxLength = 160;
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.TabIndex = 4;
            // 
            // lblEtContrasena
            // 
            this.lblEtContrasena.AutoSize = false;
            this.lblEtContrasena.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtContrasena.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtContrasena.Location = new System.Drawing.Point(36, 176);
            this.lblEtContrasena.Size = new System.Drawing.Size(308, 18);
            this.lblEtContrasena.Text = "CONTRASEÑA";
            this.lblEtContrasena.Name = "lblEtContrasena";
            this.lblEtContrasena.TabIndex = 5;
            // 
            // txtContrasena
            // 
            this.txtContrasena.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtContrasena.Location = new System.Drawing.Point(36, 196);
            this.txtContrasena.Size = new System.Drawing.Size(308, 27);
            this.txtContrasena.Text = "";
            this.txtContrasena.UseSystemPasswordChar = true;
            this.txtContrasena.MaxLength = 100;
            this.txtContrasena.Name = "txtContrasena";
            this.txtContrasena.TabIndex = 6;
            // 
            // lblError
            // 
            this.lblError.AutoSize = false;
            this.lblError.Font = new System.Drawing.Font("Segoe UI Semibold", 9F);
            this.lblError.ForeColor = System.Drawing.Color.FromArgb(220, 38, 38);
            this.lblError.Location = new System.Drawing.Point(36, 234);
            this.lblError.Size = new System.Drawing.Size(308, 36);
            this.lblError.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblError.Text = "";
            this.lblError.Name = "lblError";
            this.lblError.TabIndex = 7;
            // 
            // btnIngresar
            // 
            this.btnIngresar.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.btnIngresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIngresar.FlatAppearance.BorderSize = 0;
            this.btnIngresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIngresar.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.btnIngresar.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnIngresar.Location = new System.Drawing.Point(36, 276);
            this.btnIngresar.Size = new System.Drawing.Size(308, 42);
            this.btnIngresar.Text = "Iniciar sesión";
            this.btnIngresar.UseVisualStyleBackColor = false;
            this.btnIngresar.Name = "btnIngresar";
            this.btnIngresar.TabIndex = 8;
            this.btnIngresar.Click += new System.EventHandler(this.btnIngresar_Click);
            // 
            // pnlLinea
            // 
            this.pnlLinea.BackColor = System.Drawing.Color.FromArgb(241, 245, 249);
            this.pnlLinea.Location = new System.Drawing.Point(36, 342);
            this.pnlLinea.Size = new System.Drawing.Size(308, 1);
            this.pnlLinea.Name = "pnlLinea";
            this.pnlLinea.TabIndex = 9;
            // 
            // lblPie
            // 
            this.lblPie.AutoSize = false;
            this.lblPie.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblPie.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblPie.Location = new System.Drawing.Point(0, 436);
            this.lblPie.Size = new System.Drawing.Size(380, 18);
            this.lblPie.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPie.Text = "PSG · C# · SQL Server";
            this.lblPie.Name = "lblPie";
            this.lblPie.TabIndex = 14;
            // 
            // pnlIzquierda
            // 
            this.pnlIzquierda.Controls.Add(this.lblSistema);
            this.pnlIzquierda.Controls.Add(this.lblMarca);
            this.pnlIzquierda.Controls.Add(this.lblSubtituloMarca);
            this.pnlIzquierda.Controls.Add(this.lblDescripcion);
            this.pnlIzquierda.Controls.Add(this.lblTecnologia);
            this.pnlIzquierda.Controls.Add(this.lblFranja);
            this.pnlIzquierda.BackColor = System.Drawing.Color.FromArgb(11, 19, 35);
            this.pnlIzquierda.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlIzquierda.Size = new System.Drawing.Size(520, 620);
            this.pnlIzquierda.Name = "pnlIzquierda";
            this.pnlIzquierda.TabIndex = 1;
            // 
            // lblSistema
            // 
            this.lblSistema.AutoSize = false;
            this.lblSistema.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.lblSistema.ForeColor = System.Drawing.Color.FromArgb(147, 197, 253);
            this.lblSistema.Location = new System.Drawing.Point(0, 220);
            this.lblSistema.Size = new System.Drawing.Size(520, 28);
            this.lblSistema.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSistema.Text = "SISTEMA DE GESTIÓN";
            this.lblSistema.Name = "lblSistema";
            this.lblSistema.TabIndex = 0;
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = false;
            this.lblMarca.Font = new System.Drawing.Font("Segoe UI", 54F, System.Drawing.FontStyle.Bold);
            this.lblMarca.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblMarca.Location = new System.Drawing.Point(0, 262);
            this.lblMarca.Size = new System.Drawing.Size(520, 84);
            this.lblMarca.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMarca.Text = "PSG";
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.TabIndex = 1;
            // 
            // lblSubtituloMarca
            // 
            this.lblSubtituloMarca.AutoSize = false;
            this.lblSubtituloMarca.Font = new System.Drawing.Font("Segoe UI Semibold", 15F);
            this.lblSubtituloMarca.ForeColor = System.Drawing.Color.FromArgb(191, 219, 254);
            this.lblSubtituloMarca.Location = new System.Drawing.Point(0, 350);
            this.lblSubtituloMarca.Size = new System.Drawing.Size(520, 32);
            this.lblSubtituloMarca.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSubtituloMarca.Text = "Planificador de Servicios y Galas";
            this.lblSubtituloMarca.Name = "lblSubtituloMarca";
            this.lblSubtituloMarca.TabIndex = 2;
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = false;
            this.lblDescripcion.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblDescripcion.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.lblDescripcion.Location = new System.Drawing.Point(36, 402);
            this.lblDescripcion.Size = new System.Drawing.Size(448, 50);
            this.lblDescripcion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDescripcion.Text = "Administra eventos, salones, servicios y reservaciones desde un solo lugar.";
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.TabIndex = 3;
            // 
            // lblTecnologia
            // 
            this.lblTecnologia.AutoSize = false;
            this.lblTecnologia.Font = new System.Drawing.Font("Segoe UI Semibold", 9F);
            this.lblTecnologia.ForeColor = System.Drawing.Color.FromArgb(147, 197, 253);
            this.lblTecnologia.Location = new System.Drawing.Point(0, 500);
            this.lblTecnologia.Size = new System.Drawing.Size(520, 24);
            this.lblTecnologia.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTecnologia.Text = "C#  ·  SQL Server  ·  BCrypt  ·  3 roles";
            this.lblTecnologia.Name = "lblTecnologia";
            this.lblTecnologia.TabIndex = 4;
            // 
            // lblFranja
            // 
            this.lblFranja.AutoSize = false;
            this.lblFranja.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.lblFranja.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold);
            this.lblFranja.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblFranja.Location = new System.Drawing.Point(0, 100);
            this.lblFranja.Size = new System.Drawing.Size(520, 58);
            this.lblFranja.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFranja.Text = "PSG";
            this.lblFranja.Name = "lblFranja";
            this.lblFranja.TabIndex = 5;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(240, 244, 249);
            this.ClientSize = new System.Drawing.Size(1000, 620);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PSG · Iniciar sesión";
            this.Controls.Add(this.pnlDerecha);
            this.Controls.Add(this.pnlIzquierda);
            this.Name = "LoginForm";
            this.pnlIzquierda.ResumeLayout(false);
            this.pnlIzquierda.PerformLayout();
            this.pnlLinea.ResumeLayout(false);
            this.pnlLinea.PerformLayout();
            this.pnlBarra.ResumeLayout(false);
            this.pnlBarra.PerformLayout();
            this.pnlTarjeta.ResumeLayout(false);
            this.pnlTarjeta.PerformLayout();
            this.pnlDerecha.ResumeLayout(false);
            this.pnlDerecha.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlDerecha;
        private System.Windows.Forms.Panel pnlTarjeta;
        private System.Windows.Forms.Panel pnlBarra;
        private System.Windows.Forms.Label lblBienvenido;
        private System.Windows.Forms.Label lblAyuda;
        private System.Windows.Forms.Label lblEtUsuario;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.Label lblEtContrasena;
        private System.Windows.Forms.TextBox txtContrasena;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.Button btnIngresar;
        private System.Windows.Forms.Panel pnlLinea;
        private System.Windows.Forms.Label lblPie;
        private System.Windows.Forms.Panel pnlIzquierda;
        private System.Windows.Forms.Label lblSistema;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Label lblSubtituloMarca;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.Label lblTecnologia;
        private System.Windows.Forms.Label lblFranja;
    }
}
