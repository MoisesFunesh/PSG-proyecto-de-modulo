using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Login
{
    public partial class frmConfiguracionInicial : Form
    {
        private ErrorProvider errorProvider = new ErrorProvider();

        public frmConfiguracionInicial()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.AcceptButton = btnGuardar;
            this.CancelButton = btnCancelar;
            Estilos.EstilizarBotonPrimario(btnGuardar);
            Estilos.EstilizarBotonSecundario(btnCancelar);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            errorProvider.Clear();
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MostrarAviso("Escriba el nombre del administrador.", txtNombre);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtEmail.Text) || txtEmail.Text.Contains("@") == false)
            {
                MostrarAviso("Escriba un correo válido.", txtEmail);
                return;
            }
            if (txtContrasena.Text.Length < 8)
            {
                MostrarAviso("La contraseña debe tener al menos 8 caracteres.", txtContrasena);
                return;
            }
            if (txtContrasena.Text != txtConfirmar.Text)
            {
                MostrarAviso("Las contraseñas no coinciden.", txtConfirmar);
                return;
            }

            try
            {
                if (Usuario.ExisteEmail(txtEmail.Text, 0))
                {
                    MostrarAviso("Ya existe un usuario con ese correo.", txtEmail);
                    return;
                }
                Usuario administrador = new Usuario();
                administrador.Nombre = txtNombre.Text.Trim();
                administrador.Email = txtEmail.Text.Trim();
                administrador.Rol = UsuarioRol.Administrador;
                administrador.Activo = true;
                Usuario.Agregar(administrador, txtContrasena.Text);
                MessageBox.Show(this, "Administrador creado. Ya puede iniciar sesión.", "Configuración lista",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Configuración inicial",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MostrarAviso(string mensaje, Control control)
        {
            errorProvider.SetError(control, mensaje);
            MessageBox.Show(this, mensaje, "Datos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
