namespace vista.Login
{
    partial class frmConfiguracionInicial
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblContrasena = new System.Windows.Forms.Label();
            this.txtContrasena = new System.Windows.Forms.TextBox();
            this.lblConfirmar = new System.Windows.Forms.Label();
            this.txtConfirmar = new System.Windows.Forms.TextBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.lblTitulo.AutoSize = false;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 16F);
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblTitulo.Location = new System.Drawing.Point(30, 24);
            this.lblTitulo.Size = new System.Drawing.Size(390, 34);
            this.lblTitulo.Text = "Configuración inicial";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitulo.Name = "lblTitulo";
            this.lblTexto.AutoSize = false;
            this.lblTexto.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblTexto.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblTexto.Location = new System.Drawing.Point(30, 64);
            this.lblTexto.Size = new System.Drawing.Size(390, 42);
            this.lblTexto.Text = "No hay usuarios registrados. Cree el administrador que utilizará el sistema.";
            this.lblTexto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTexto.Name = "lblTexto";
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(34, 128);
            this.lblNombre.Text = "Nombre completo";
            this.txtNombre.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.txtNombre.Location = new System.Drawing.Point(34, 150);
            this.txtNombre.Size = new System.Drawing.Size(382, 26);
            this.txtNombre.MaxLength = 120;
            this.txtNombre.Name = "txtNombre";
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(34, 190);
            this.lblEmail.Text = "Correo electrónico";
            this.txtEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtEmail.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.txtEmail.Location = new System.Drawing.Point(34, 212);
            this.txtEmail.Size = new System.Drawing.Size(382, 26);
            this.txtEmail.MaxLength = 160;
            this.txtEmail.Name = "txtEmail";
            this.lblContrasena.AutoSize = true;
            this.lblContrasena.Location = new System.Drawing.Point(34, 252);
            this.lblContrasena.Text = "Contraseña";
            this.txtContrasena.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.txtContrasena.Location = new System.Drawing.Point(34, 274);
            this.txtContrasena.Size = new System.Drawing.Size(382, 26);
            this.txtContrasena.MaxLength = 100;
            this.txtContrasena.UseSystemPasswordChar = true;
            this.txtContrasena.Name = "txtContrasena";
            this.lblConfirmar.AutoSize = true;
            this.lblConfirmar.Location = new System.Drawing.Point(34, 314);
            this.lblConfirmar.Text = "Confirmar contraseña";
            this.txtConfirmar.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.txtConfirmar.Location = new System.Drawing.Point(34, 336);
            this.txtConfirmar.Size = new System.Drawing.Size(382, 26);
            this.txtConfirmar.MaxLength = 100;
            this.txtConfirmar.UseSystemPasswordChar = true;
            this.txtConfirmar.Name = "txtConfirmar";
            this.btnCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancelar.Location = new System.Drawing.Point(34, 394);
            this.btnCancelar.Size = new System.Drawing.Size(150, 38);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.Name = "btnCancelar";
            this.btnGuardar.Location = new System.Drawing.Point(266, 394);
            this.btnGuardar.Size = new System.Drawing.Size(150, 38);
            this.btnGuardar.Text = "Crear administrador";
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            this.AcceptButton = this.btnGuardar;
            this.CancelButton = this.btnCancelar;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(243, 244, 246);
            this.ClientSize = new System.Drawing.Size(450, 468);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblContrasena);
            this.Controls.Add(this.txtContrasena);
            this.Controls.Add(this.lblConfirmar);
            this.Controls.Add(this.txtConfirmar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnGuardar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PSG · Configuración inicial";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblContrasena;
        private System.Windows.Forms.TextBox txtContrasena;
        private System.Windows.Forms.Label lblConfirmar;
        private System.Windows.Forms.TextBox txtConfirmar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGuardar;
    }
}
