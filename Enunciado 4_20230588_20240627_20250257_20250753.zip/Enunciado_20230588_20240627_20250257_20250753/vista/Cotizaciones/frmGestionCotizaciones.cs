using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Cotizaciones
{
    public partial class frmGestionCotizaciones : Form
    {
        private Cotizacion[] cotizaciones;

        public frmGestionCotizaciones()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            Estilos.EstilizarTabla(dgvDatos);
            Estilos.EstilizarBotonPrimario(btnNuevo);
            Estilos.EstilizarBotonSecundario(btnEditar);
            Estilos.EstilizarBotonSecundario(btnEliminar);
            cotizaciones = new Cotizacion[0];
        }

        private void frmGestionCotizaciones_Load(object sender, EventArgs e)
        {
            if (Sesion.UsuarioActual == null || PermisosUI.Tiene("Cotizaciones", "consultar") == false)
            {
                MessageBox.Show(this, "No tiene permiso para consultar cotizaciones.", "Acceso restringido",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }
            btnNuevo.Visible = PermisosUI.Tiene("Cotizaciones", "crear");
            btnEditar.Visible = PermisosUI.Tiene("Cotizaciones", "editar");
            btnEliminar.Visible = PermisosUI.Tiene("Cotizaciones", "eliminar");
            CargarDatos();
        }

        private void CargarDatos()
        {
            try
            {
                cotizaciones = Cotizacion.ObtenerTodas();
                dgvDatos.Rows.Clear();
                for (int i = 0; i < cotizaciones.Length; i++)
                {
                    Cotizacion cotizacion = cotizaciones[i];
                    int fila = dgvDatos.Rows.Add(cotizacion.Id.ToString("000"), cotizacion.ClienteNombre, cotizacion.Descripcion,
                        Herramientas.FormatoFecha(cotizacion.FechaVence), Herramientas.FormatoDinero(cotizacion.Total), cotizacion.Estado);
                    dgvDatos.Rows[fila].Tag = cotizacion;
                    Estilos.ColorearEstado(dgvDatos.Rows[fila].Cells["colEstado"]);
                }
                lblConteo.Text = cotizaciones.Length + " cotización(es)";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Cotizaciones", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Cotizacion ObtenerSeleccionada()
        {
            if (dgvDatos.CurrentRow == null) return null;
            return dgvDatos.CurrentRow.Tag as Cotizacion;
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            string texto = txtBuscar.Text.Trim().ToLower();
            for (int i = 0; i < dgvDatos.Rows.Count; i++)
            {
                string contenido = dgvDatos.Rows[i].Cells[1].Value.ToString().ToLower() + " " + dgvDatos.Rows[i].Cells[2].Value.ToString().ToLower();
                dgvDatos.Rows[i].Visible = string.IsNullOrWhiteSpace(texto) || contenido.Contains(texto);
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Cotizaciones", "crear") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para crear cotizaciones."); return; }
            AbrirEditor(new Cotizacion());
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Cotizaciones", "editar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para editar cotizaciones."); return; }
            Cotizacion seleccionada = ObtenerSeleccionada();
            if (seleccionada == null) { Herramientas.MostrarAviso(this, "Seleccione una cotización."); return; }
            AbrirEditor(seleccionada);
        }

        private void dgvDatos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) btnEditar_Click(sender, EventArgs.Empty);
        }

        private void AbrirEditor(Cotizacion cotizacion)
        {
            frmCotizacionEditar formulario = new frmCotizacionEditar(cotizacion);
            if (formulario.ShowDialog(this) == DialogResult.OK) CargarDatos();
            formulario.Dispose();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Cotizaciones", "eliminar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para eliminar cotizaciones."); return; }
            Cotizacion seleccionada = ObtenerSeleccionada();
            if (seleccionada == null) { Herramientas.MostrarAviso(this, "Seleccione una cotización."); return; }
            if (Herramientas.Confirmar(this, "¿Desea eliminar la cotización seleccionada?" ) == false) return;
            try
            {
                if (Cotizacion.Eliminar(seleccionada.Id)) { Herramientas.MostrarAviso(this, "La cotización se eliminó correctamente."); CargarDatos(); }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Cotizaciones", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
