using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Cotizaciones
{
    public partial class frmCotizacionEditar : Form
    {
        private Cotizacion cotizacionEditar;
        private ErrorProvider errorProvider = new ErrorProvider();

        public frmCotizacionEditar(Cotizacion cotizacion)
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.Font = Estilos.FuenteTexto;
            this.BackColor = Estilos.ColorFondo;
            Estilos.EstilizarTabla(dgvItems);
            Estilos.EstilizarBotonPrimario(btnGuardar);
            Estilos.EstilizarBotonSecundario(btnCancelar);
            Estilos.EstilizarBotonSecundario(btnAgregarItem);
            Estilos.EstilizarBotonSecundario(btnQuitarItem);
            cotizacionEditar = cotizacion;
        }

        private void frmCotizacionEditar_Load(object sender, EventArgs e)
        {
            try
            {
                Usuario[] clientes = Usuario.ObtenerClientes();
                cboCliente.DataSource = clientes;
                cboCliente.DisplayMember = "Nombre";
                cboCliente.ValueMember = "Id";
                cboEstado.Items.AddRange(Catalogos.EstadosCotizacion);
                if (cotizacionEditar.Id == 0)
                {
                    dtpEmision.Value = DateTime.Today;
                    dtpVence.Value = DateTime.Today.AddDays(15);
                    cboEstado.SelectedItem = "Pendiente";
                }
                else
                {
                    cboCliente.SelectedValue = cotizacionEditar.ClienteId;
                    txtDescripcion.Text = cotizacionEditar.Descripcion;
                    nudDescuento.Value = cotizacionEditar.Descuento;
                    dtpEmision.Value = cotizacionEditar.FechaEmision;
                    dtpVence.Value = cotizacionEditar.FechaVence;
                    cboEstado.SelectedItem = cotizacionEditar.Estado;
                    for (int i = 0; i < cotizacionEditar.Items.Length; i++) AgregarFila(cotizacionEditar.Items[i]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Cotizaciones", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult = DialogResult.Cancel;
                this.Close();
            }
        }

        private void btnAgregarItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtConcepto.Text)) { MostrarAviso("Escriba el concepto del renglón.", txtConcepto); return; }
            CotizacionItem item = new CotizacionItem();
            item.Concepto = txtConcepto.Text.Trim();
            item.Precio = nudPrecio.Value;
            AgregarFila(item);
            txtConcepto.Clear();
            nudPrecio.Value = 0;
        }

        private void AgregarFila(CotizacionItem item)
        {
            int fila = dgvItems.Rows.Add(item.Concepto, item.Precio);
            dgvItems.Rows[fila].Tag = item;
        }

        private void btnQuitarItem_Click(object sender, EventArgs e)
        {
            if (dgvItems.CurrentRow != null) dgvItems.Rows.Remove(dgvItems.CurrentRow);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            errorProvider.Clear();
            if (cboCliente.SelectedValue == null) { MostrarAviso("Seleccione el cliente.", cboCliente); return; }
            if (string.IsNullOrWhiteSpace(txtDescripcion.Text)) { MostrarAviso("Escriba la descripción.", txtDescripcion); return; }
            if (dtpVence.Value.Date < dtpEmision.Value.Date) { MostrarAviso("La fecha de vencimiento no puede ser anterior a la emisión.", dtpVence); return; }
            if (dgvItems.Rows.Count == 0) { MostrarAviso("Agregue al menos un renglón.", dgvItems); return; }

            Cotizacion cotizacion = cotizacionEditar;
            cotizacion.ClienteId = Convert.ToInt32(cboCliente.SelectedValue);
            cotizacion.Descripcion = txtDescripcion.Text.Trim();
            cotizacion.Descuento = nudDescuento.Value;
            cotizacion.FechaEmision = dtpEmision.Value.Date;
            cotizacion.FechaVence = dtpVence.Value.Date;
            cotizacion.Estado = cboEstado.SelectedItem.ToString();
            CotizacionItem[] items = new CotizacionItem[dgvItems.Rows.Count];
            for (int i = 0; i < dgvItems.Rows.Count; i++)
            {
                CotizacionItem item = dgvItems.Rows[i].Tag as CotizacionItem;
                if (item == null) item = new CotizacionItem();
                item.Concepto = dgvItems.Rows[i].Cells[0].Value.ToString();
                item.Precio = Convert.ToDecimal(dgvItems.Rows[i].Cells[1].Value);
                items[i] = item;
            }
            cotizacion.Items = items;
            try
            {
                if (Cotizacion.Guardar(cotizacion))
                {
                    MessageBox.Show(this, "La cotización se guardó correctamente.", "Listo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Cotizaciones", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void MostrarAviso(string mensaje, Control control)
        {
            errorProvider.SetError(control, mensaje);
            MessageBox.Show(this, mensaje, "Datos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
