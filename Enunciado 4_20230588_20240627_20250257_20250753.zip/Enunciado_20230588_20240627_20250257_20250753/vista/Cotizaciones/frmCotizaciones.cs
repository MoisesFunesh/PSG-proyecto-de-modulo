﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Cotizaciones
{
    public partial class frmCotizaciones : Form
    {
        private Cotizacion[] cotizaciones;

        // mientras se llena la tabla no hay que reaccionar a los cambios de seleccion
        private bool cargando;

        public frmCotizaciones()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            Estilos.EstilizarTabla(dgvCotizaciones);
            Estilos.EstilizarTabla(dgvDetalle);
            cotizaciones = new Cotizacion[0];
            cargando = false;
        }

        private void frmCotizaciones_Load(object sender, EventArgs e)
        {
            Recargar(0);
        }

        // lee las cotizaciones del cliente y deja seleccionada la que tenga ese id (0 = la primera)
        private void Recargar(int idASeleccionar)
        {
            try
            {
                cargando = true;
                cotizaciones = Cotizacion.ObtenerPorCliente(Sesion.UsuarioActual.Id);

            dgvCotizaciones.Rows.Clear();
            for (int i = 0; i < cotizaciones.Length; i++)
            {
                Cotizacion cotizacion = cotizaciones[i];

                int fila = dgvCotizaciones.Rows.Add(
                    cotizacion.Descripcion,
                    Herramientas.FormatoFecha(cotizacion.FechaEmision),
                    Herramientas.FormatoFecha(cotizacion.FechaVence),
                    Herramientas.FormatoDinero(cotizacion.Total),
                    cotizacion.Estado
                );
                dgvCotizaciones.Rows[fila].Tag = cotizacion;
                Estilos.ColorearEstado(dgvCotizaciones.Rows[fila].Cells["colCotEstado"]);

                if (cotizacion.Id == idASeleccionar)
                {
                    dgvCotizaciones.CurrentCell = dgvCotizaciones.Rows[fila].Cells[0];
                }
            }

            cargando = false;
                MostrarDetalle();
            }
            catch (Exception ex)
            {
                cargando = false;
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Cotizaciones", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Cotizacion ObtenerSeleccionada()
        {
            if (dgvCotizaciones.CurrentRow == null) return null;
            return dgvCotizaciones.CurrentRow.Tag as Cotizacion;
        }

        private void dgvCotizaciones_SelectionChanged(object sender, EventArgs e)
        {
            if (cargando) return;
            MostrarDetalle();
        }

        // muestra los renglones y los totales de la cotizacion seleccionada
        private void MostrarDetalle()
        {
            dgvDetalle.Rows.Clear();

            Cotizacion cotizacion = ObtenerSeleccionada();
            if (cotizacion == null)
            {
                lblTotales.Text = "No tiene cotizaciones por el momento.";
                btnAceptar.Enabled = false;
                btnRechazar.Enabled = false;
                return;
            }

            for (int i = 0; i < cotizacion.Items.Length; i++)
            {
                dgvDetalle.Rows.Add(cotizacion.Items[i].Concepto, Herramientas.FormatoDinero(cotizacion.Items[i].Precio));
            }

            lblTotales.Text = "Subtotal: " + Herramientas.FormatoDinero(cotizacion.Subtotal) +
                "     Descuento: -" + Herramientas.FormatoDinero(cotizacion.Descuento) +
                "     TOTAL: " + Herramientas.FormatoDinero(cotizacion.Total);

            // solo se puede aceptar si sigue pendiente
            btnAceptar.Enabled = cotizacion.Estado == "Pendiente";
            btnRechazar.Enabled = cotizacion.Estado == "Pendiente";
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Cotizacion cotizacion = ObtenerSeleccionada();
            if (cotizacion == null) return;

            if (Herramientas.Confirmar(this, "¿Desea aceptar esta cotización por " + Herramientas.FormatoDinero(cotizacion.Total) + "?") == false)
            {
                return;
            }

            try
            {
                if (Cotizacion.Aceptar(cotizacion.Id, Sesion.UsuarioActual.Id))
                {
                    Recargar(cotizacion.Id);
                    Herramientas.MostrarAviso(this, "Cotización aceptada. El organizador se pondrá en contacto con usted.");
                }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Cotizaciones", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void btnRechazar_Click(object sender, EventArgs e)
        {
            Cotizacion cotizacion = ObtenerSeleccionada();
            if (cotizacion == null || cotizacion.Estado != "Pendiente") return;
            if (Herramientas.Confirmar(this, "¿Desea rechazar esta cotización?") == false) return;
            try
            {
                if (Cotizacion.Rechazar(cotizacion.Id, Sesion.UsuarioActual.Id))
                {
                    Recargar(cotizacion.Id);
                    Herramientas.MostrarAviso(this, "La cotización fue rechazada.");
                }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Cotizaciones", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
