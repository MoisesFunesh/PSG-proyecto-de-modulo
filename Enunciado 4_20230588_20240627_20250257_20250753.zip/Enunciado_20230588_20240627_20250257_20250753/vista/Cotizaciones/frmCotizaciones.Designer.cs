﻿namespace vista.Cotizaciones
{
    partial class frmCotizaciones
    {
        // <summary>
        // Variable del diseñador necesaria.
        // </summary>
        private System.ComponentModel.IContainer components = null;

        // <summary>
        // Limpiar los recursos que se estén usando.
        // </summary>
        // <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        // <summary>
        // Método necesario para admitir el Diseñador. No se puede modificar
        // el contenido de este método con el editor de código.
        // </summary>
        private void InitializeComponent()
        {
            this.pnlContenido = new System.Windows.Forms.Panel();
            this.pnlDetalle = new System.Windows.Forms.Panel();
            this.dgvDetalle = new System.Windows.Forms.DataGridView();
            this.colDetConcepto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDetPrecio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlPie = new System.Windows.Forms.Panel();
            this.lblTotales = new System.Windows.Forms.Label();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnRechazar = new System.Windows.Forms.Button();
            this.lblDetalleTitulo = new System.Windows.Forms.Label();
            this.pnlSeparador = new System.Windows.Forms.Panel();
            this.pnlLista = new System.Windows.Forms.Panel();
            this.dgvCotizaciones = new System.Windows.Forms.DataGridView();
            this.colCotDescripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCotEmision = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCotVence = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCotTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCotEstado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblListaTitulo = new System.Windows.Forms.Label();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCotizaciones)).BeginInit();
            this.pnlContenido.SuspendLayout();
            this.pnlDetalle.SuspendLayout();
            this.pnlPie.SuspendLayout();
            this.pnlSeparador.SuspendLayout();
            this.pnlLista.SuspendLayout();
            this.pnlHeader.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlContenido
            // 
            this.pnlContenido.Controls.Add(this.pnlDetalle);
            this.pnlContenido.Controls.Add(this.pnlSeparador);
            this.pnlContenido.Controls.Add(this.pnlLista);
            this.pnlContenido.BackColor = System.Drawing.Color.FromArgb(243, 244, 246);
            this.pnlContenido.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContenido.Padding = new System.Windows.Forms.Padding(24, 24, 24, 24);
            this.pnlContenido.Size = new System.Drawing.Size(1080, 568);
            this.pnlContenido.Name = "pnlContenido";
            this.pnlContenido.TabIndex = 0;
            // 
            // pnlDetalle
            // 
            this.pnlDetalle.Controls.Add(this.dgvDetalle);
            this.pnlDetalle.Controls.Add(this.pnlPie);
            this.pnlDetalle.Controls.Add(this.lblDetalleTitulo);
            this.pnlDetalle.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlDetalle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDetalle.Size = new System.Drawing.Size(1032, 300);
            this.pnlDetalle.Name = "pnlDetalle";
            this.pnlDetalle.TabIndex = 0;
            // 
            // dgvDetalle
            // 
            this.dgvDetalle.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDetConcepto,
            this.colDetPrecio});
            this.dgvDetalle.AllowUserToAddRows = false;
            this.dgvDetalle.AllowUserToDeleteRows = false;
            this.dgvDetalle.AllowUserToResizeRows = false;
            this.dgvDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDetalle.BackgroundColor = System.Drawing.Color.White;
            this.dgvDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvDetalle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDetalle.MultiSelect = false;
            this.dgvDetalle.ReadOnly = true;
            this.dgvDetalle.RowHeadersVisible = false;
            this.dgvDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetalle.Size = new System.Drawing.Size(300, 200);
            this.dgvDetalle.Name = "dgvDetalle";
            this.dgvDetalle.TabIndex = 0;
            // 
            // colDetConcepto
            // 
            this.colDetConcepto.FillWeight = 300F;
            this.colDetConcepto.HeaderText = "Concepto";
            this.colDetConcepto.MinimumWidth = 6;
            this.colDetConcepto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colDetConcepto.Name = "colDetConcepto";
            // 
            // colDetPrecio
            // 
            this.colDetPrecio.FillWeight = 80F;
            this.colDetPrecio.HeaderText = "Precio";
            this.colDetPrecio.MinimumWidth = 6;
            this.colDetPrecio.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colDetPrecio.Name = "colDetPrecio";
            // 
            // pnlPie
            // 
            this.pnlPie.Controls.Add(this.lblTotales);
            this.pnlPie.Controls.Add(this.btnRechazar);
            this.pnlPie.Controls.Add(this.btnAceptar);
            this.pnlPie.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlPie.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlPie.Size = new System.Drawing.Size(1032, 64);
            this.pnlPie.Name = "pnlPie";
            this.pnlPie.TabIndex = 1;
            // 
            // lblTotales
            // 
            this.lblTotales.AutoSize = true;
            this.lblTotales.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblTotales.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblTotales.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblTotales.Location = new System.Drawing.Point(16, 22);
            this.lblTotales.Text = "";
            this.lblTotales.Name = "lblTotales";
            this.lblTotales.TabIndex = 0;
            // 
            // btnAceptar
            // 
            this.btnAceptar.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.btnAceptar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.btnAceptar.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnAceptar.Location = new System.Drawing.Point(806, 14);
            this.btnAceptar.Size = new System.Drawing.Size(210, 36);
            this.btnAceptar.Text = "✔  Aceptar cotización";
            this.btnAceptar.UseVisualStyleBackColor = false;
            this.btnAceptar.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.TabIndex = 1;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnRechazar
            // 
            this.btnRechazar.BackColor = System.Drawing.Color.FromArgb(254, 242, 242);
            this.btnRechazar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRechazar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(252, 165, 165);
            this.btnRechazar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRechazar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.btnRechazar.ForeColor = System.Drawing.Color.FromArgb(185, 28, 28);
            this.btnRechazar.Location = new System.Drawing.Point(590, 14);
            this.btnRechazar.Size = new System.Drawing.Size(200, 36);
            this.btnRechazar.Text = "Rechazar cotización";
            this.btnRechazar.UseVisualStyleBackColor = false;
            this.btnRechazar.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.btnRechazar.Name = "btnRechazar";
            this.btnRechazar.TabIndex = 2;
            this.btnRechazar.Click += new System.EventHandler(this.btnRechazar_Click);
            // 
            // lblDetalleTitulo
            // 
            this.lblDetalleTitulo.AutoSize = false;
            this.lblDetalleTitulo.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblDetalleTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblDetalleTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblDetalleTitulo.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblDetalleTitulo.Size = new System.Drawing.Size(10, 42);
            this.lblDetalleTitulo.Padding = new System.Windows.Forms.Padding(16, 0, 0, 0);
            this.lblDetalleTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDetalleTitulo.Text = "Detalle de la cotización";
            this.lblDetalleTitulo.Name = "lblDetalleTitulo";
            this.lblDetalleTitulo.TabIndex = 2;
            // 
            // pnlSeparador
            // 
            this.pnlSeparador.BackColor = System.Drawing.Color.FromArgb(243, 244, 246);
            this.pnlSeparador.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSeparador.Size = new System.Drawing.Size(1032, 12);
            this.pnlSeparador.Name = "pnlSeparador";
            this.pnlSeparador.TabIndex = 1;
            // 
            // pnlLista
            // 
            this.pnlLista.Controls.Add(this.dgvCotizaciones);
            this.pnlLista.Controls.Add(this.lblListaTitulo);
            this.pnlLista.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlLista.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLista.Size = new System.Drawing.Size(1032, 200);
            this.pnlLista.Name = "pnlLista";
            this.pnlLista.TabIndex = 2;
            // 
            // dgvCotizaciones
            // 
            this.dgvCotizaciones.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCotDescripcion,
            this.colCotEmision,
            this.colCotVence,
            this.colCotTotal,
            this.colCotEstado});
            this.dgvCotizaciones.AllowUserToAddRows = false;
            this.dgvCotizaciones.AllowUserToDeleteRows = false;
            this.dgvCotizaciones.AllowUserToResizeRows = false;
            this.dgvCotizaciones.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCotizaciones.BackgroundColor = System.Drawing.Color.White;
            this.dgvCotizaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvCotizaciones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCotizaciones.MultiSelect = false;
            this.dgvCotizaciones.ReadOnly = true;
            this.dgvCotizaciones.RowHeadersVisible = false;
            this.dgvCotizaciones.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCotizaciones.Size = new System.Drawing.Size(300, 200);
            this.dgvCotizaciones.Name = "dgvCotizaciones";
            this.dgvCotizaciones.TabIndex = 0;
            this.dgvCotizaciones.SelectionChanged += new System.EventHandler(this.dgvCotizaciones_SelectionChanged);
            // 
            // colCotDescripcion
            // 
            this.colCotDescripcion.FillWeight = 260F;
            this.colCotDescripcion.HeaderText = "Descripción";
            this.colCotDescripcion.MinimumWidth = 6;
            this.colCotDescripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCotDescripcion.Name = "colCotDescripcion";
            // 
            // colCotEmision
            // 
            this.colCotEmision.FillWeight = 70F;
            this.colCotEmision.HeaderText = "Emitida";
            this.colCotEmision.MinimumWidth = 6;
            this.colCotEmision.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCotEmision.Name = "colCotEmision";
            // 
            // colCotVence
            // 
            this.colCotVence.FillWeight = 70F;
            this.colCotVence.HeaderText = "Válida hasta";
            this.colCotVence.MinimumWidth = 6;
            this.colCotVence.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCotVence.Name = "colCotVence";
            // 
            // colCotTotal
            // 
            this.colCotTotal.FillWeight = 70F;
            this.colCotTotal.HeaderText = "Total";
            this.colCotTotal.MinimumWidth = 6;
            this.colCotTotal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCotTotal.Name = "colCotTotal";
            // 
            // colCotEstado
            // 
            this.colCotEstado.FillWeight = 70F;
            this.colCotEstado.HeaderText = "Estado";
            this.colCotEstado.MinimumWidth = 6;
            this.colCotEstado.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCotEstado.Name = "colCotEstado";
            // 
            // lblListaTitulo
            // 
            this.lblListaTitulo.AutoSize = false;
            this.lblListaTitulo.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblListaTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblListaTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.lblListaTitulo.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblListaTitulo.Size = new System.Drawing.Size(10, 42);
            this.lblListaTitulo.Padding = new System.Windows.Forms.Padding(16, 0, 0, 0);
            this.lblListaTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblListaTitulo.Text = "Cotizaciones recibidas";
            this.lblListaTitulo.Name = "lblListaTitulo";
            this.lblListaTitulo.TabIndex = 1;
            // 
            // pnlHeader
            // 
            this.pnlHeader.Controls.Add(this.lblTitulo);
            this.pnlHeader.Controls.Add(this.lblSubtitulo);
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Size = new System.Drawing.Size(1080, 92);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.TabIndex = 1;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblTitulo.Location = new System.Drawing.Point(28, 16);
            this.lblTitulo.Text = "Mis cotizaciones";
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblSubtitulo.Location = new System.Drawing.Point(31, 57);
            this.lblSubtitulo.Text = "Revise y acepte las propuestas económicas de su evento";
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            // 
            // frmCotizaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(243, 244, 246);
            this.ClientSize = new System.Drawing.Size(1080, 660);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MinimumSize = new System.Drawing.Size(900, 560);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PSG · Cotizaciones";
            this.Controls.Add(this.pnlContenido);
            this.Controls.Add(this.pnlHeader);
            this.Name = "frmCotizaciones";
            this.Load += new System.EventHandler(this.frmCotizaciones_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCotizaciones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalle)).EndInit();
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.pnlLista.ResumeLayout(false);
            this.pnlLista.PerformLayout();
            this.pnlSeparador.ResumeLayout(false);
            this.pnlSeparador.PerformLayout();
            this.pnlPie.ResumeLayout(false);
            this.pnlPie.PerformLayout();
            this.pnlDetalle.ResumeLayout(false);
            this.pnlDetalle.PerformLayout();
            this.pnlContenido.ResumeLayout(false);
            this.pnlContenido.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlContenido;
        private System.Windows.Forms.Panel pnlDetalle;
        private System.Windows.Forms.DataGridView dgvDetalle;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDetConcepto;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDetPrecio;
        private System.Windows.Forms.Panel pnlPie;
        private System.Windows.Forms.Label lblTotales;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnRechazar;
        private System.Windows.Forms.Label lblDetalleTitulo;
        private System.Windows.Forms.Panel pnlSeparador;
        private System.Windows.Forms.Panel pnlLista;
        private System.Windows.Forms.DataGridView dgvCotizaciones;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCotDescripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCotEmision;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCotVence;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCotTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCotEstado;
        private System.Windows.Forms.Label lblListaTitulo;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblSubtitulo;
    }
}
