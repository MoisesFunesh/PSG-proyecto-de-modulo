using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Usuarios
{
    public partial class frmPerfiles : Form
    {
        private Perfil[] perfiles;
        private Perfil seleccionado;

        public frmPerfiles()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.AcceptButton = btnGuardar;
            this.CancelButton = btnCerrar;
            Estilos.EstilizarTabla(dgvDatos);
            Estilos.EstilizarBotonPrimario(btnGuardar);
            Estilos.EstilizarBotonSecundario(btnNuevo);
            Estilos.EstilizarBotonSecundario(btnDesactivar);
            Estilos.EstilizarBotonSecundario(btnCerrar);
            perfiles = new Perfil[0];
        }

        private void frmPerfiles_Load(object sender, EventArgs e)
        {
            if (Sesion.UsuarioActual == null || Sesion.UsuarioActual.Rol != UsuarioRol.Administrador)
            {
                MessageBox.Show(this, "Solo el Administrador puede gestionar perfiles.", "Acceso restringido",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }
            CargarDatos();
            NuevoPerfil();
        }

        private void CargarDatos()
        {
            try
            {
                perfiles = Perfil.ObtenerTodos();
                dgvDatos.Rows.Clear();
                for (int i = 0; i < perfiles.Length; i++)
                {
                    int fila = dgvDatos.Rows.Add(perfiles[i].IdPerfil, perfiles[i].Nombre, perfiles[i].Descripcion, perfiles[i].EstadoTexto);
                    dgvDatos.Rows[fila].Tag = perfiles[i];
                    Estilos.ColorearEstado(dgvDatos.Rows[fila].Cells["colEstado"]);
                }
                lblConteo.Text = perfiles.Length + " perfil(es)";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Perfiles", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvDatos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvDatos.CurrentRow == null) return;
            seleccionado = dgvDatos.CurrentRow.Tag as Perfil;
            if (seleccionado == null) return;
            txtNombre.Text = seleccionado.Nombre;
            txtDescripcion.Text = seleccionado.Descripcion;
            chkActivo.Checked = seleccionado.Activo;
        }

        private void btnNuevo_Click(object sender, EventArgs e) { NuevoPerfil(); }

        private void NuevoPerfil()
        {
            seleccionado = null;
            txtNombre.Clear();
            txtDescripcion.Clear();
            chkActivo.Checked = true;
            txtNombre.Focus();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                Herramientas.MostrarAviso(this, "Escriba el nombre del perfil.");
                txtNombre.Focus();
                return;
            }
            if (seleccionado != null && seleccionado.IdPerfil <= 3 &&
                string.Equals(seleccionado.Nombre, txtNombre.Text.Trim(), StringComparison.OrdinalIgnoreCase) == false)
            {
                Herramientas.MostrarAviso(this, "No se puede cambiar el nombre de los tres perfiles base.");
                txtNombre.Focus();
                return;
            }
            if (seleccionado != null && seleccionado.IdPerfil <= 3 && chkActivo.Checked == false)
            {
                Herramientas.MostrarAviso(this, "Los tres perfiles base deben permanecer activos.");
                chkActivo.Checked = true;
                return;
            }
            try
            {
                Perfil perfil = new Perfil();
                if (seleccionado != null) perfil.IdPerfil = seleccionado.IdPerfil;
                perfil.Nombre = txtNombre.Text.Trim();
                perfil.Descripcion = txtDescripcion.Text.Trim();
                perfil.Activo = chkActivo.Checked;
                Perfil.Guardar(perfil);
                Herramientas.MostrarAviso(this, "El perfil se guardó correctamente.");
                CargarDatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Perfiles", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDesactivar_Click(object sender, EventArgs e)
        {
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un perfil.");
                return;
            }
            if (seleccionado.IdPerfil == Sesion.UsuarioActual.IdPerfil)
            {
                Herramientas.MostrarAviso(this, "No puede desactivar el perfil con el que está trabajando.");
                return;
            }
            if (Herramientas.Confirmar(this, "¿Desea desactivar el perfil \"" + seleccionado.Nombre + "\"?") == false) return;
            try
            {
                Perfil.Desactivar(seleccionado.IdPerfil);
                Herramientas.MostrarAviso(this, "El perfil se desactivó correctamente.");
                CargarDatos();
                NuevoPerfil();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Perfiles", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
