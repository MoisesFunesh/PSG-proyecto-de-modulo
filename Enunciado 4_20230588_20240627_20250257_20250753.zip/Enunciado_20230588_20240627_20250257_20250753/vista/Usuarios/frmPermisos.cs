using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Usuarios
{
    public partial class frmPermisos : Form
    {
        public frmPermisos()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.Font = Estilos.FuenteTexto;
            this.BackColor = Estilos.ColorFondo;
            this.AcceptButton = btnGuardar;
            this.CancelButton = btnCancelar;
            Estilos.EstilizarBotonPrimario(btnGuardar);
            Estilos.EstilizarBotonSecundario(btnPerfiles);
            Estilos.EstilizarBotonSecundario(btnCancelar);
        }

        private void frmPermisos_Load(object sender, EventArgs e)
        {
            if (Sesion.UsuarioActual == null || Sesion.UsuarioActual.Rol != UsuarioRol.Administrador)
            {
                MessageBox.Show(this, "Solo el Administrador puede modificar permisos.", "Acceso restringido",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }
            try
            {
                cboPerfil.DisplayMember = "Nombre";
                cboPerfil.ValueMember = "Id";
                cboPerfil.DataSource = Permiso.ObtenerPerfiles();
                cboOpcion.DisplayMember = "Nombre";
                cboOpcion.ValueMember = "Id";
                cboOpcion.DataSource = Permiso.ObtenerOpciones();
                if (cboPerfil.Items.Count > 0) cboPerfil.SelectedIndex = 0;
                if (cboOpcion.Items.Count > 0) cboOpcion.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Permisos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cboPerfil_SelectedIndexChanged(object sender, EventArgs e) { CargarPermiso(); }
        private void cboOpcion_SelectedIndexChanged(object sender, EventArgs e) { CargarPermiso(); }

        private void CargarPermiso()
        {
            if (cboPerfil.SelectedIndex < 0 || cboOpcion.SelectedIndex < 0) return;
            OpcionPermiso perfil = cboPerfil.SelectedItem as OpcionPermiso;
            OpcionPermiso opcion = cboOpcion.SelectedItem as OpcionPermiso;
            if (perfil == null || opcion == null) return;
            int idPerfil = perfil.Id;
            string modulo = opcion.Nombre;
            try
            {
                Permiso[] permisos = Permiso.ObtenerPorPerfil(idPerfil);
                chkConsultar.Checked = false;
                chkCrear.Checked = false;
                chkEditar.Checked = false;
                chkEliminar.Checked = false;
                for (int i = 0; i < permisos.Length; i++)
                {
                    if (permisos[i].Modulo == modulo)
                    {
                        chkConsultar.Checked = permisos[i].PuedeConsultar;
                        chkCrear.Checked = permisos[i].PuedeCrear;
                        chkEditar.Checked = permisos[i].PuedeEditar;
                        chkEliminar.Checked = permisos[i].PuedeEliminar;
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Permisos", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                OpcionPermiso perfil = cboPerfil.SelectedItem as OpcionPermiso;
                OpcionPermiso opcion = cboOpcion.SelectedItem as OpcionPermiso;
                if (perfil == null || opcion == null) return;
                if (perfil.Id == Sesion.UsuarioActual.IdPerfil && opcion.Nombre == "Usuarios" && chkConsultar.Checked == false)
                {
                    MessageBox.Show(this, "El administrador actual debe conservar el acceso de consulta a Usuarios.", "Permisos",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (Permiso.Guardar(perfil.Id, opcion.Id, chkConsultar.Checked, chkCrear.Checked, chkEditar.Checked, chkEliminar.Checked))
                {
                    MessageBox.Show(this, "Los permisos se guardaron correctamente.", "Listo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Permisos", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void btnPerfiles_Click(object sender, EventArgs e)
        {
            frmPerfiles formulario = new frmPerfiles();
            formulario.ShowDialog(this);
            formulario.Dispose();
            try
            {
                cboPerfil.DataSource = Permiso.ObtenerPerfiles();
                if (cboPerfil.Items.Count > 0) cboPerfil.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Permisos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
