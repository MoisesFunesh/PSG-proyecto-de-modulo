﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Usuarios
{
    public partial class frmGestionUsuarios : Form
    {
        // todos los registros que trajo la base y los que se ven en la tabla despues de buscar
        private Usuario[] todos;
        private Usuario[] mostrados;

        public frmGestionUsuarios()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            Estilos.EstilizarTabla(dgvDatos);
            todos = new Usuario[0];
            mostrados = new Usuario[0];
        }

        private void frmGestionUsuarios_Load(object sender, EventArgs e)
        {
            if (Sesion.UsuarioActual == null || PermisosUI.Tiene("Usuarios", "consultar") == false)
            {
                MessageBox.Show("No tiene permiso para consultar usuarios.", "Acceso restringido",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }
            btnNuevo.Visible = PermisosUI.Tiene("Usuarios", "crear");
            btnEditar.Visible = PermisosUI.Tiene("Usuarios", "editar");
            btnEliminar.Visible = PermisosUI.Tiene("Usuarios", "eliminar");
            btnRestablecer.Visible = PermisosUI.Tiene("Usuarios", "editar");
            btnPermisos.Visible = Sesion.UsuarioActual.Rol == UsuarioRol.Administrador;
            try { CargarDatos(); }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // vuelve a leer la base de datos y actualiza la tabla
        private void CargarDatos()
        {
            try
            {
                todos = Usuario.ObtenerTodos();
                AplicarFiltro();
            }
            catch (Exception ex) { MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void AplicarFiltro()
        {
            mostrados = Usuario.Buscar(todos, txtBuscar.Text);

            dgvDatos.Rows.Clear();
            for (int i = 0; i < mostrados.Length; i++)
            {
                Usuario usuario = mostrados[i];

                int fila = dgvDatos.Rows.Add(
                    usuario.Id.ToString("000"),
                    usuario.Nombre,
                    usuario.Email,
                    usuario.RolTexto,
                    usuario.EstadoTexto
                );
                dgvDatos.Rows[fila].Tag = usuario;
                Estilos.ColorearEstado(dgvDatos.Rows[fila].Cells["colRol"]);
                Estilos.ColorearEstado(dgvDatos.Rows[fila].Cells["colEstado"]);
            }

            lblConteo.Text = mostrados.Length + " registros";
        }

        // devuelve el registro que esta seleccionado en la tabla (o null si no hay)
        private Usuario ObtenerSeleccionado()
        {
            if (dgvDatos.CurrentRow == null) return null;
            return dgvDatos.CurrentRow.Tag as Usuario;
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            AplicarFiltro();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Usuarios", "crear") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para crear usuarios."); return; }
            frmUsuarioEditar editor = new frmUsuarioEditar();
            if (editor.ShowDialog(this) == DialogResult.OK) CargarDatos();
            editor.Dispose();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            EditarSeleccionado();
        }

        private void dgvDatos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && btnEditar.Visible)
            {
                EditarSeleccionado();
            }
        }

        private void EditarSeleccionado()
        {
            if (PermisosUI.Tiene("Usuarios", "editar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para editar usuarios."); return; }
            Usuario seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un registro de la tabla.");
                return;
            }

            frmUsuarioEditar editor = new frmUsuarioEditar(seleccionado);
            if (editor.ShowDialog(this) == DialogResult.OK) CargarDatos();
            editor.Dispose();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (PermisosUI.Tiene("Usuarios", "eliminar") == false) { Herramientas.MostrarAviso(this, "No tiene permiso para desactivar usuarios."); return; }
            try
            {
            Usuario seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un registro de la tabla.");
                return;
            }

            if (Sesion.UsuarioActual != null && Sesion.UsuarioActual.Id == seleccionado.Id)
            {
                Herramientas.MostrarAviso(this, "No puede eliminar su propio usuario.");
                return;
            }

            if (Herramientas.Confirmar(this, "¿Desea quitar a \"" + seleccionado.Nombre + "\"?\nSi tiene información relacionada, su cuenta quedará inactiva para conservar el historial.") == false)
            {
                return;
            }

                if (Usuario.Eliminar(seleccionado.Id)) CargarDatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRestablecer_Click(object sender, EventArgs e)
        {
            Usuario seleccionado = ObtenerSeleccionado();
            if (seleccionado == null)
            {
                Herramientas.MostrarAviso(this, "Seleccione un usuario de la tabla.");
                return;
            }
            frmRestablecerContrasena formulario = new frmRestablecerContrasena(seleccionado);
            formulario.ShowDialog(this);
            formulario.Dispose();
        }

        private void btnPermisos_Click(object sender, EventArgs e)
        {
            frmPermisos formulario = new frmPermisos();
            formulario.ShowDialog(this);
            formulario.Dispose();
        }
    }
}
