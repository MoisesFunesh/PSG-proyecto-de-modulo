namespace vista.Usuarios
{
    partial class frmRestablecerContrasena
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.lblContrasena = new System.Windows.Forms.Label();
            this.txtContrasena = new System.Windows.Forms.TextBox();
            this.lblConfirmar = new System.Windows.Forms.Label();
            this.txtConfirmar = new System.Windows.Forms.TextBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 14F);
            this.lblTitulo.Location = new System.Drawing.Point(28, 24);
            this.lblTitulo.Text = "Restablecer contraseña";
            this.lblTitulo.Name = "lblTitulo";
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.ForeColor = System.Drawing.Color.DimGray;
            this.lblUsuario.Location = new System.Drawing.Point(30, 61);
            this.lblUsuario.Text = "Usuario";
            this.lblUsuario.Name = "lblUsuario";
            this.lblContrasena.AutoSize = true;
            this.lblContrasena.Location = new System.Drawing.Point(30, 102);
            this.lblContrasena.Text = "Nueva contraseña";
            this.lblContrasena.Name = "lblContrasena";
            this.txtContrasena.Location = new System.Drawing.Point(30, 123);
            this.txtContrasena.Size = new System.Drawing.Size(330, 23);
            this.txtContrasena.UseSystemPasswordChar = true;
            this.txtContrasena.Name = "txtContrasena";
            this.lblConfirmar.AutoSize = true;
            this.lblConfirmar.Location = new System.Drawing.Point(30, 163);
            this.lblConfirmar.Text = "Confirmar contraseña";
            this.lblConfirmar.Name = "lblConfirmar";
            this.txtConfirmar.Location = new System.Drawing.Point(30, 184);
            this.txtConfirmar.Size = new System.Drawing.Size(330, 23);
            this.txtConfirmar.UseSystemPasswordChar = true;
            this.txtConfirmar.Name = "txtConfirmar";
            this.btnGuardar.Location = new System.Drawing.Point(184, 235);
            this.btnGuardar.Size = new System.Drawing.Size(176, 34);
            this.btnGuardar.Text = "Guardar contraseña";
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            this.btnCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancelar.Location = new System.Drawing.Point(30, 235);
            this.btnCancelar.Size = new System.Drawing.Size(140, 34);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.Name = "btnCancelar";
            this.AcceptButton = this.btnGuardar;
            this.CancelButton = this.btnCancelar;
            this.ClientSize = new System.Drawing.Size(390, 300);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblUsuario);
            this.Controls.Add(this.lblContrasena);
            this.Controls.Add(this.txtContrasena);
            this.Controls.Add(this.lblConfirmar);
            this.Controls.Add(this.txtConfirmar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnCancelar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PSG · Restablecer contraseña";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.Label lblContrasena;
        private System.Windows.Forms.TextBox txtContrasena;
        private System.Windows.Forms.Label lblConfirmar;
        private System.Windows.Forms.TextBox txtConfirmar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnCancelar;
    }
}
