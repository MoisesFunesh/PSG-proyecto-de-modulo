namespace vista.Usuarios
{
    partial class frmPermisos
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblPerfil = new System.Windows.Forms.Label();
            this.cboPerfil = new System.Windows.Forms.ComboBox();
            this.lblOpcion = new System.Windows.Forms.Label();
            this.cboOpcion = new System.Windows.Forms.ComboBox();
            this.chkConsultar = new System.Windows.Forms.CheckBox();
            this.chkCrear = new System.Windows.Forms.CheckBox();
            this.chkEditar = new System.Windows.Forms.CheckBox();
            this.chkEliminar = new System.Windows.Forms.CheckBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnPerfiles = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 15F);
            this.lblTitulo.Location = new System.Drawing.Point(30, 26);
            this.lblTitulo.Text = "Permisos por perfil";
            this.lblTitulo.Name = "lblTitulo";
            this.lblPerfil.AutoSize = true;
            this.lblPerfil.Location = new System.Drawing.Point(32, 84);
            this.lblPerfil.Text = "Perfil";
            this.lblPerfil.Name = "lblPerfil";
            this.cboPerfil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPerfil.Location = new System.Drawing.Point(32, 106);
            this.cboPerfil.Size = new System.Drawing.Size(300, 23);
            this.cboPerfil.Name = "cboPerfil";
            this.cboPerfil.SelectedIndexChanged += new System.EventHandler(this.cboPerfil_SelectedIndexChanged);
            this.lblOpcion.AutoSize = true;
            this.lblOpcion.Location = new System.Drawing.Point(32, 153);
            this.lblOpcion.Text = "Módulo";
            this.lblOpcion.Name = "lblOpcion";
            this.cboOpcion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOpcion.Location = new System.Drawing.Point(32, 175);
            this.cboOpcion.Size = new System.Drawing.Size(300, 23);
            this.cboOpcion.Name = "cboOpcion";
            this.cboOpcion.SelectedIndexChanged += new System.EventHandler(this.cboOpcion_SelectedIndexChanged);
            this.chkConsultar.AutoSize = true;
            this.chkConsultar.Location = new System.Drawing.Point(32, 222);
            this.chkConsultar.Text = "Consultar";
            this.chkConsultar.Name = "chkConsultar";
            this.chkCrear.AutoSize = true;
            this.chkCrear.Location = new System.Drawing.Point(140, 222);
            this.chkCrear.Text = "Crear";
            this.chkCrear.Name = "chkCrear";
            this.chkEditar.AutoSize = true;
            this.chkEditar.Location = new System.Drawing.Point(225, 222);
            this.chkEditar.Text = "Editar";
            this.chkEditar.Name = "chkEditar";
            this.chkEliminar.AutoSize = true;
            this.chkEliminar.Location = new System.Drawing.Point(32, 254);
            this.chkEliminar.Text = "Eliminar";
            this.chkEliminar.Name = "chkEliminar";
            this.btnGuardar.Location = new System.Drawing.Point(190, 300);
            this.btnGuardar.Size = new System.Drawing.Size(142, 36);
            this.btnGuardar.Text = "Guardar permisos";
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            this.btnPerfiles.Location = new System.Drawing.Point(32, 345);
            this.btnPerfiles.Size = new System.Drawing.Size(300, 36);
            this.btnPerfiles.Text = "Administrar perfiles";
            this.btnPerfiles.Name = "btnPerfiles";
            this.btnPerfiles.Click += new System.EventHandler(this.btnPerfiles_Click);
            this.btnCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancelar.Location = new System.Drawing.Point(32, 300);
            this.btnCancelar.Size = new System.Drawing.Size(142, 36);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.Name = "btnCancelar";
            this.ClientSize = new System.Drawing.Size(370, 410);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblPerfil);
            this.Controls.Add(this.cboPerfil);
            this.Controls.Add(this.lblOpcion);
            this.Controls.Add(this.cboOpcion);
            this.Controls.Add(this.chkConsultar);
            this.Controls.Add(this.chkCrear);
            this.Controls.Add(this.chkEditar);
            this.Controls.Add(this.chkEliminar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnPerfiles);
            this.Controls.Add(this.btnCancelar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PSG · Permisos";
            this.Load += new System.EventHandler(this.frmPermisos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblPerfil;
        private System.Windows.Forms.ComboBox cboPerfil;
        private System.Windows.Forms.Label lblOpcion;
        private System.Windows.Forms.ComboBox cboOpcion;
        private System.Windows.Forms.CheckBox chkConsultar;
        private System.Windows.Forms.CheckBox chkCrear;
        private System.Windows.Forms.CheckBox chkEditar;
        private System.Windows.Forms.CheckBox chkEliminar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnPerfiles;
        private System.Windows.Forms.Button btnCancelar;
    }
}
