using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Usuarios
{
    public partial class frmRestablecerContrasena : Form
    {
        private Usuario usuario;
        private ErrorProvider errorProvider = new ErrorProvider();

        public frmRestablecerContrasena(Usuario usuarioSeleccionado)
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.Font = Estilos.FuenteTexto;
            this.BackColor = Estilos.ColorFondo;
            Estilos.EstilizarBotonPrimario(btnGuardar);
            Estilos.EstilizarBotonSecundario(btnCancelar);
            usuario = usuarioSeleccionado;
            lblUsuario.Text = usuario.Nombre + " · " + usuario.Email;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            errorProvider.Clear();
            if (txtContrasena.Text.Length < 8)
            {
                MostrarAviso("La contraseña debe tener al menos 8 caracteres.", txtContrasena);
                return;
            }
            if (txtContrasena.Text != txtConfirmar.Text)
            {
                MostrarAviso("Las contraseñas no coinciden.", txtConfirmar);
                return;
            }
            try
            {
                if (Usuario.CambiarContrasena(usuario.Id, txtContrasena.Text))
                {
                    MessageBox.Show(this, "La contraseña se restableció correctamente.", "Listo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "No se pudo guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MostrarAviso(string mensaje, Control control)
        {
            errorProvider.SetError(control, mensaje);
            MessageBox.Show(this, mensaje, "Datos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
