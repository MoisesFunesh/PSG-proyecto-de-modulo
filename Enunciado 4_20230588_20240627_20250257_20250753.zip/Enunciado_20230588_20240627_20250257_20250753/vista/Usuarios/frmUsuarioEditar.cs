﻿using System;
using System.Windows.Forms;
using Modelos;
using vista.Helpers;

namespace vista.Usuarios
{
    public partial class frmUsuarioEditar : Form
    {
        // Muestra el error junto al campo.
        private ErrorProvider errorProvider = new ErrorProvider();

        // si es null estamos agregando un usuario nuevo, si no, estamos editando ese usuario
        private Usuario usuarioEditar = null;

        public frmUsuarioEditar()
        {
            InitializeComponent();
            this.Icon = vista.Properties.Resources.PSG;
            this.AcceptButton = btnGuardar;
            this.CancelButton = btnCancelar;
        }

        public frmUsuarioEditar(Usuario usuario) : this()
        {
            usuarioEditar = usuario;
            lblTitulo.Text = "Editar usuario";
            this.Text = "PSG · Editar usuario";
            // al editar, la contrasena solo se cambia si se escribe una nueva
            lblEtContrasena.Text = "NUEVA CONTRASEÑA (VACÍO = NO CAMBIAR)";
        }

        private void frmUsuarioEditar_Load(object sender, EventArgs e)
        {
            try
            {
                OpcionPermiso[] perfiles = Permiso.ObtenerPerfiles();
                cboRol.DisplayMember = "Nombre";
                cboRol.ValueMember = "Id";
                cboRol.DataSource = perfiles;

                if (usuarioEditar == null)
                {
                    cboRol.SelectedValue = 3;
                    chkActivo.Checked = true;
                }
                else
                {
                    txtNombre.Text = usuarioEditar.Nombre;
                    txtEmail.Text = usuarioEditar.Email;
                    cboRol.SelectedValue = usuarioEditar.IdPerfil;
                    chkActivo.Checked = usuarioEditar.Activo;
                }
                if (cboRol.SelectedIndex == -1) cboRol.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Usuarios",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidarCampos() == false) return;

                int idPerfil = Convert.ToInt32(cboRol.SelectedValue);

                Usuario usuario = new Usuario();
                usuario.Nombre = txtNombre.Text.Trim();
                usuario.Email = txtEmail.Text.Trim();
                usuario.IdPerfil = idPerfil;
                usuario.NombrePerfil = cboRol.Text;
                usuario.Activo = chkActivo.Checked;

                bool guardado;
                if (usuarioEditar == null) guardado = Usuario.Agregar(usuario, txtContrasena.Text);
                else
                {
                    usuario.Id = usuarioEditar.Id;
                    guardado = Usuario.Actualizar(usuario, txtContrasena.Text);
                }

                if (guardado == false) return;
                MessageBox.Show(this, "El usuario se guardó correctamente.", "Listo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, Ayuda.ObtenerMensajeAmigable(ex), "Usuarios",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidarCampos()
        {
            errorProvider.Clear();

            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MostrarAviso("El nombre es obligatorio.", txtNombre);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtEmail.Text) || txtEmail.Text.Contains("@") == false)
            {
                MostrarAviso("Escriba un correo válido.", txtEmail);
                return false;
            }

            int idAExcluir = 0;
            if (usuarioEditar != null)
            {
                idAExcluir = usuarioEditar.Id;
            }
            if (Usuario.ExisteEmail(txtEmail.Text, idAExcluir))
            {
                MostrarAviso("Ya existe un usuario con ese correo.", txtEmail);
                return false;
            }

            if (usuarioEditar == null)
            {
                if (txtContrasena.Text.Length < 8)
                {
                    MostrarAviso("La contraseña debe tener al menos 8 caracteres.", txtContrasena);
                    return false;
                }
            }
            else if (txtContrasena.Text.Length > 0 && txtContrasena.Text.Length < 8)
            {
                MostrarAviso("La contraseña debe tener al menos 8 caracteres.", txtContrasena);
                return false;
            }

            // para no quedarse sin acceso, el administrador no puede desactivar ni cambiar el rol de su propia cuenta
            if (usuarioEditar != null && Sesion.UsuarioActual != null && Sesion.UsuarioActual.Id == usuarioEditar.Id)
            {
                int idPerfil = Convert.ToInt32(cboRol.SelectedValue);
                if (chkActivo.Checked == false || idPerfil != Sesion.UsuarioActual.IdPerfil)
                {
                    MostrarAviso("No puede desactivar su cuenta ni cambiar su propio rol.", cboRol);
                    return false;
                }
            }

            return true;
        }

        private void MostrarAviso(string mensaje, Control control)
        {
            errorProvider.SetError(control, mensaje);
            MessageBox.Show(this, mensaje, "Datos incompletos",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
