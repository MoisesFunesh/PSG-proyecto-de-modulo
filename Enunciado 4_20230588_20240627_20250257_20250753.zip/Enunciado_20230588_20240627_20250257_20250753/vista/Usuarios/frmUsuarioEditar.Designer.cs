﻿namespace vista.Usuarios
{
    partial class frmUsuarioEditar
    {
        // <summary>
        // Variable del diseñador necesaria.
        // </summary>
        private System.ComponentModel.IContainer components = null;

        // <summary>
        // Limpiar los recursos que se estén usando.
        // </summary>
        // <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        // <summary>
        // Método necesario para admitir el Diseñador. No se puede modificar
        // el contenido de este método con el editor de código.
        // </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblEtNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lblEtEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEtContrasena = new System.Windows.Forms.Label();
            this.txtContrasena = new System.Windows.Forms.TextBox();
            this.lblEtRol = new System.Windows.Forms.Label();
            this.cboRol = new System.Windows.Forms.ComboBox();
            this.lblEtActivo = new System.Windows.Forms.Label();
            this.chkActivo = new System.Windows.Forms.CheckBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblTitulo.Location = new System.Drawing.Point(24, 16);
            this.lblTitulo.Text = "Nuevo usuario";
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            // 
            // lblEtNombre
            // 
            this.lblEtNombre.AutoSize = false;
            this.lblEtNombre.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtNombre.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtNombre.Location = new System.Drawing.Point(24, 66);
            this.lblEtNombre.Size = new System.Drawing.Size(412, 18);
            this.lblEtNombre.Text = "NOMBRE COMPLETO";
            this.lblEtNombre.Name = "lblEtNombre";
            this.lblEtNombre.TabIndex = 1;
            // 
            // txtNombre
            // 
            this.txtNombre.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtNombre.Location = new System.Drawing.Point(24, 86);
            this.txtNombre.Size = new System.Drawing.Size(412, 27);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.TabIndex = 2;
            // 
            // lblEtEmail
            // 
            this.lblEtEmail.AutoSize = false;
            this.lblEtEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtEmail.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtEmail.Location = new System.Drawing.Point(24, 130);
            this.lblEtEmail.Size = new System.Drawing.Size(412, 18);
            this.lblEtEmail.Text = "CORREO ELECTRÓNICO";
            this.lblEtEmail.Name = "lblEtEmail";
            this.lblEtEmail.TabIndex = 3;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtEmail.Location = new System.Drawing.Point(24, 150);
            this.txtEmail.Size = new System.Drawing.Size(412, 27);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.TabIndex = 4;
            // 
            // lblEtContrasena
            // 
            this.lblEtContrasena.AutoSize = false;
            this.lblEtContrasena.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtContrasena.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtContrasena.Location = new System.Drawing.Point(24, 194);
            this.lblEtContrasena.Size = new System.Drawing.Size(412, 18);
            this.lblEtContrasena.Text = "CONTRASEÑA";
            this.lblEtContrasena.Name = "lblEtContrasena";
            this.lblEtContrasena.TabIndex = 5;
            // 
            // txtContrasena
            // 
            this.txtContrasena.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtContrasena.Location = new System.Drawing.Point(24, 214);
            this.txtContrasena.Size = new System.Drawing.Size(412, 27);
            this.txtContrasena.UseSystemPasswordChar = true;
            this.txtContrasena.Name = "txtContrasena";
            this.txtContrasena.TabIndex = 6;
            // 
            // lblEtRol
            // 
            this.lblEtRol.AutoSize = false;
            this.lblEtRol.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtRol.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtRol.Location = new System.Drawing.Point(24, 258);
            this.lblEtRol.Size = new System.Drawing.Size(412, 18);
            this.lblEtRol.Text = "ROL DEL SISTEMA";
            this.lblEtRol.Name = "lblEtRol";
            this.lblEtRol.TabIndex = 7;
            // 
            // cboRol
            // 
            this.cboRol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRol.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboRol.FormattingEnabled = true;
            this.cboRol.Location = new System.Drawing.Point(24, 278);
            this.cboRol.Size = new System.Drawing.Size(412, 25);
            this.cboRol.Name = "cboRol";
            this.cboRol.TabIndex = 8;
            // 
            // lblEtActivo
            // 
            this.lblEtActivo.AutoSize = false;
            this.lblEtActivo.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.lblEtActivo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEtActivo.Location = new System.Drawing.Point(24, 322);
            this.lblEtActivo.Size = new System.Drawing.Size(412, 18);
            this.lblEtActivo.Text = "ESTADO DE LA CUENTA";
            this.lblEtActivo.Name = "lblEtActivo";
            this.lblEtActivo.TabIndex = 9;
            // 
            // chkActivo
            // 
            this.chkActivo.AutoSize = true;
            this.chkActivo.Checked = true;
            this.chkActivo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkActivo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.chkActivo.Location = new System.Drawing.Point(24, 344);
            this.chkActivo.Text = "Cuenta activa";
            this.chkActivo.Name = "chkActivo";
            this.chkActivo.TabIndex = 10;
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelar.FlatAppearance.BorderSize = 1;
            this.btnCancelar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(226, 232, 240);
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.btnCancelar.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.btnCancelar.Location = new System.Drawing.Point(326, 394);
            this.btnCancelar.Size = new System.Drawing.Size(110, 36);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.TabIndex = 11;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.btnGuardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
            this.btnGuardar.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnGuardar.Location = new System.Drawing.Point(198, 394);
            this.btnGuardar.Size = new System.Drawing.Size(120, 36);
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.TabIndex = 12;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // frmUsuarioEditar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.ClientSize = new System.Drawing.Size(460, 454);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PSG · Usuario";
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblEtNombre);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lblEtEmail);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblEtContrasena);
            this.Controls.Add(this.txtContrasena);
            this.Controls.Add(this.lblEtRol);
            this.Controls.Add(this.cboRol);
            this.Controls.Add(this.lblEtActivo);
            this.Controls.Add(this.chkActivo);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnGuardar);
            this.Name = "frmUsuarioEditar";
            this.Load += new System.EventHandler(this.frmUsuarioEditar_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblEtNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblEtEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEtContrasena;
        private System.Windows.Forms.TextBox txtContrasena;
        private System.Windows.Forms.Label lblEtRol;
        private System.Windows.Forms.ComboBox cboRol;
        private System.Windows.Forms.Label lblEtActivo;
        private System.Windows.Forms.CheckBox chkActivo;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGuardar;
    }
}
