﻿using System;
using System.Data.SqlClient;

namespace Modelos
{
    // catalogo pequeno de errores para que los mensajes sean faciles de identificar
    public static class DiccionarioErrores
    {
        public const string SqlConexion = "ERR-SQL-001";
        public const string SqlDuplicado = "ERR-SQL-002";
        public const string SqlClaveForanea = "ERR-SQL-003";
        public const string SqlEstructura = "ERR-SQL-004";
        public const string Validacion = "ERR-VAL-003";
        public const string General = "ERR-SYS-999";

        public static string ObtenerCodigo(Exception ex)
        {
            Exception actual = ex;
            while (!(actual is SqlException) && actual.InnerException != null)
                actual = actual.InnerException;
            SqlException errorSql = actual as SqlException;
            if (errorSql != null)
            {
                if (errorSql.Number == 2 || errorSql.Number == 53 || errorSql.Number == 4060 ||
                    errorSql.Number == 18456 || errorSql.Number == 40 || errorSql.Number == 10060)
                {
                    return SqlConexion;
                }
                if (errorSql.Number == 2601 || errorSql.Number == 2627)
                {
                    return SqlDuplicado;
                }
                if (errorSql.Number == 547)
                {
                    return SqlClaveForanea;
                }
                // 207 = Invalid column name, 208 = Invalid object name (tabla/vista no existe).
                // casi siempre significa que a la base de datos le falta correr el script SQL
                if (errorSql.Number == 207 || errorSql.Number == 208)
                {
                    return SqlEstructura;
                }
                // los triggers de la base lanzan sus propios errores (THROW 50001, 50002...)
                if (errorSql.Number >= 50000)
                {
                    return Validacion;
                }
                // cualquier otro error de SQL Server (sintaxis, permisos, etc.) se reporta como
                // "General" en vez de decir "sin conexion", que seria enganoso
                return General;
            }

            return General;
        }

        public static string ObtenerDescripcion(string codigo)
        {
            if (codigo == SqlConexion) return "No se pudo conectar con la base de datos. Revise que SQL Server esté encendido y la cadena de conexión de App.config.";
            if (codigo == SqlDuplicado) return "El registro ya existe.";
            if (codigo == SqlClaveForanea) return "No se puede completar: el registro está relacionado con otros datos.";
            if (codigo == SqlEstructura) return "La base de datos no tiene una tabla, vista o regla que el sistema necesita. Ejecute el script de la carpeta Base_Datos.";
            if (codigo == Validacion) return "Revise los datos ingresados.";
            return "Ocurrió un problema inesperado en el sistema.";
        }
    }
}
