﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Text.RegularExpressions;

namespace Modelos.Conexion_DB
{
    // aqui se decide a que SQL Server se conecta el sistema
    public class Conexion
    {
        // la conexion se toma desde App.config (ConexionPSG).
        // estos dos datos solo se usan para armar el mensaje cuando falla la conexion
        private static string servidor = @".\SQLEXPRESS";
        private static string baseDeDatos = "PSG";

        public static SqlConnection Conectar()
        {
            ConnectionStringSettings configuracion = ConfigurationManager.ConnectionStrings["ConexionPSG"];
            if (configuracion == null || string.IsNullOrWhiteSpace(configuracion.ConnectionString))
            {
                throw new Exception(DiccionarioErrores.SqlConexion + ": No se encontró la cadena de conexión ConexionPSG en App.config.");
            }

            SqlConnection conexion = new SqlConnection(configuracion.ConnectionString);

            try
            {
                conexion.Open();
                return conexion;
            }
            catch (SqlException ex)
            {
                conexion.Dispose();
                throw new Exception(ConstruirMensajeConexion(ex), ex);
            }
            catch (Exception ex)
            {
                conexion.Dispose();
                throw new Exception(ConstruirMensajeConexion(ex), ex);
            }
        }

        private static string ConstruirMensajeConexion(Exception ex)
        {
            string codigo = DiccionarioErrores.ObtenerCodigo(ex);
            string mensaje = DiccionarioErrores.ObtenerDescripcion(codigo);
            SqlException errorSql = ex as SqlException;
            if (errorSql != null && (errorSql.Number == 2 || errorSql.Number == 53))
                mensaje += " Servidor: " + servidor + ".";
            if (errorSql != null && errorSql.Number == 4060)
                mensaje += " Base de datos: " + baseDeDatos + ".";

            return codigo + ": " + mensaje;
        }

        // se llama una sola vez al abrir el programa.
        // crea la base PSG si no existe y corre el script SQL con las tablas principales.
        // si todo ya estaba creado no toca nada. devuelve false si no se pudo dejar lista la base
        public static bool PrepararBaseDatos()
        {
            ConnectionStringSettings configuracion = ConfigurationManager.ConnectionStrings["ConexionPSG"];
            if (configuracion == null || string.IsNullOrWhiteSpace(configuracion.ConnectionString))
            {
                throw new Exception(DiccionarioErrores.SqlConexion + ": No se encontró la cadena de conexión ConexionPSG en App.config.");
            }

            try
            {
                // primero nos conectamos a master, que siempre existe, para saber si ya esta la base PSG
                SqlConnectionStringBuilder constructor = new SqlConnectionStringBuilder(configuracion.ConnectionString);
                constructor.InitialCatalog = "master";

                bool baseNueva = false;
                SqlConnection master = new SqlConnection(constructor.ConnectionString);
                try
                {
                    master.Open();
                    SqlCommand buscar = new SqlCommand("SELECT COUNT(*) FROM sys.databases WHERE name = @nombre", master);
                    buscar.Parameters.AddWithValue("@nombre", baseDeDatos);
                    int existentes = (int)buscar.ExecuteScalar();

                    if (existentes == 0)
                    {
                        SqlCommand crear = new SqlCommand("CREATE DATABASE [" + baseDeDatos + "]", master);
                        crear.ExecuteNonQuery();
                        baseNueva = true;
                    }
                }
                finally
                {
                    master.Close();
                }

                // ahora ya con la base PSG, se revisa si las tablas principales estan creadas
                SqlConnection conexion = new SqlConnection(configuracion.ConnectionString);
                try
                {
                    conexion.Open();
                    if (baseNueva || FaltaEstructura(conexion))
                    {
                        EjecutarScript(conexion);
                    }
                }
                finally
                {
                    conexion.Close();
                }

                return true;
            }
            catch (Exception ex)
            {
                // aqui se agrega el detalle tecnico para saber que fallo (conexion, permisos o el script)
                throw new Exception("No se pudo preparar la base de datos: " + Ayuda.ObtenerMensajeAmigable(ex), ex);
            }
        }

        // si falta una tabla principal, hay que correr el script de estructura
        private static bool FaltaEstructura(SqlConnection conexion)
        {
            string comandoSQL = "SELECT COUNT(*) FROM sys.objects WHERE name IN " +
                "('S_Usuarios', 'Cotizaciones', 'Reservaciones', 'D_OpcionesPerfiles', 'S_BitacorasSistema', 'vw_AlertasPendientes', 'trg_Reservaciones_Validar')";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            int encontrados = (int)comando.ExecuteScalar();
            return encontrados < 7;
        }

        // el script trae varios lotes separados por GO (como en SQL Server Management Studio).
        // GO no es SQL de verdad, asi que se parte el texto y se manda cada lote por separado
        private static void EjecutarScript(SqlConnection conexion)
        {
            string ruta = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Base_Datos", "PSG_BaseDatos.sql");
            if (File.Exists(ruta) == false)
            {
                throw new FileNotFoundException("No se encontró el script de la base de datos: " + ruta);
            }

            string script = File.ReadAllText(ruta);
            string[] lotes = Regex.Split(script, @"^\s*GO\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);

            for (int i = 0; i < lotes.Length; i++)
            {
                if (string.IsNullOrWhiteSpace(lotes[i])) continue;

                SqlCommand comando = new SqlCommand(lotes[i], conexion);
                comando.CommandTimeout = 120;
                comando.ExecuteNonQuery();
            }
        }
    }
}
