﻿using System;
using System.Data.SqlClient;

namespace Modelos
{
    // Clase de apoyo para no mostrarle al usuario mensajes tecnicos crudos de SQL Server
    // (violaciones de FK, timeouts, etc.) cuando algo falla al guardar o consultar datos.
    public static class Ayuda
    {
        public static string ObtenerMensajeAmigable(Exception ex)
        {
            // Las validaciones de SQL Server pueden devolver un mensaje sencillo para el usuario.
            Exception actual = ex;
            while (!(actual is SqlException) && actual.InnerException != null)
                actual = actual.InnerException;
            SqlException errorSql = actual as SqlException;
            if (errorSql != null && errorSql.Number >= 50000)
            {
                return errorSql.Message;
            }

            string codigo = DiccionarioErrores.ObtenerCodigo(ex);
            string descripcion = DiccionarioErrores.ObtenerDescripcion(codigo);
            return codigo + ": " + descripcion;
        }
    }
}
