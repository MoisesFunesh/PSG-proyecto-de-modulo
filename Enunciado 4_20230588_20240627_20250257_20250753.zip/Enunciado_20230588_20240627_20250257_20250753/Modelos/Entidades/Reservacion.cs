﻿using System;
using System.Data.SqlClient;
using Modelos.Conexion_DB;

namespace Modelos
{
    // la reservacion de un salon para un evento en una fecha
    // regla principal: no puede haber dos reservaciones activas del mismo salon en la misma fecha
    public class Reservacion
    {
        private int id;
        private int clienteId;
        private string clienteNombre;
        private int eventoId;
        private string eventoNombre;
        private int salonId;
        private string salonNombre;
        private DateTime fecha;
        private DateTime fechaCreacion;
        private string estado;
        private decimal total;

        public int Id { get => id; set => id = value; }
        public int ClienteId { get => clienteId; set => clienteId = value; }
        public string ClienteNombre { get => clienteNombre; set => clienteNombre = value; }
        public int EventoId { get => eventoId; set => eventoId = value; }
        public string EventoNombre { get => eventoNombre; set => eventoNombre = value; }
        public int SalonId { get => salonId; set => salonId = value; }
        public string SalonNombre { get => salonNombre; set => salonNombre = value; }
        // fecha del evento
        public DateTime Fecha { get => fecha; set => fecha = value; }
        // dia en que se hizo la reserva
        public DateTime FechaCreacion { get => fechaCreacion; set => fechaCreacion = value; }
        // Confirmada, Pendiente o Cancelada
        public string Estado { get => estado; set => estado = value; }
        public decimal Total { get => total; set => total = value; }

        public Reservacion()
        {
            clienteNombre = "";
            eventoNombre = "";
            salonNombre = "";
            fecha = DateTime.Today;
            fechaCreacion = DateTime.Today;
            estado = "Pendiente";
            total = 0;
        }

        // conecta con Reservaciones, Usuarios, Eventos y Salones
        private const string SELECT_BASE =
            "SELECT r.Id, r.ClienteId, u.Nombre AS ClienteNombre, r.EventoId, e.Nombre AS EventoNombre, " +
            "r.SalonId, s.Nombre AS SalonNombre, r.Fecha, r.FechaCreacion, r.Estado, r.Total " +
            "FROM Reservaciones r " +
            "INNER JOIN S_Usuarios u ON u.Id = r.ClienteId " +
            "INNER JOIN Eventos e ON e.Id = r.EventoId " +
            "INNER JOIN Salones s ON s.Id = r.SalonId ";

        private static Reservacion LeerReservacion(SqlDataReader lector)
        {
            Reservacion reservacion = new Reservacion();
            reservacion.Id = (int)lector["Id"];
            reservacion.ClienteId = (int)lector["ClienteId"];
            reservacion.ClienteNombre = lector["ClienteNombre"].ToString();
            reservacion.EventoId = (int)lector["EventoId"];
            reservacion.EventoNombre = lector["EventoNombre"].ToString();
            reservacion.SalonId = (int)lector["SalonId"];
            reservacion.SalonNombre = lector["SalonNombre"].ToString();
            reservacion.Fecha = (DateTime)lector["Fecha"];
            reservacion.FechaCreacion = (DateTime)lector["FechaCreacion"];
            reservacion.Estado = lector["Estado"].ToString();
            reservacion.Total = (decimal)lector["Total"];
            return reservacion;
        }

        // trae todas las reservaciones (para administrador y organizador)
        public static Reservacion[] ObtenerTodas()
        {
            return ObtenerLista(SELECT_BASE + "ORDER BY r.Fecha ASC", 0);
        }

        // el cliente solo ve las suyas
        public static Reservacion[] ObtenerPorCliente(int idCliente)
        {
            return ObtenerLista(SELECT_BASE + "WHERE r.ClienteId = @cliente ORDER BY r.Fecha ASC", idCliente);
        }

        // idCliente = 0 significa que la consulta no filtra por cliente
        private static Reservacion[] ObtenerLista(string comandoSQL, int idCliente)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return new Reservacion[0];

            try
            {
                Reservacion[] reservaciones = new Reservacion[100];
                int total = 0;

                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                if (idCliente > 0)
                {
                    comando.Parameters.AddWithValue("@cliente", idCliente);
                }

                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == reservaciones.Length) Array.Resize(ref reservaciones, reservaciones.Length * 2);
                    reservaciones[total] = LeerReservacion(lector);
                    total = total + 1;
                }
                lector.Close();

                Array.Resize(ref reservaciones, total);
                return reservaciones;
            }
            catch (Exception ex) { throw new Exception("No se pudieron listar las reservaciones.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        // busca en memoria por cliente, evento, salon o estado
        public static Reservacion[] Buscar(Reservacion[] lista, string texto)
        {
            if (string.IsNullOrWhiteSpace(texto)) return lista;

            Reservacion[] resultado = new Reservacion[lista.Length];
            int total = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (Coincide(lista[i], texto))
                {
                    resultado[total] = lista[i];
                    total = total + 1;
                }
            }
            Array.Resize(ref resultado, total);
            return resultado;
        }

        private static bool Coincide(Reservacion reservacion, string texto)
        {
            string textoBusqueda = texto.Trim().ToLower();
            if (reservacion.ClienteNombre.ToLower().Contains(textoBusqueda)) return true;
            if (reservacion.EventoNombre.ToLower().Contains(textoBusqueda)) return true;
            if (reservacion.SalonNombre.ToLower().Contains(textoBusqueda)) return true;
            if (reservacion.Estado.ToLower().Contains(textoBusqueda)) return true;
            return false;
        }

        public static int ContarPorEstado(Reservacion[] lista, string estado)
        {
            int contador = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (lista[i].Estado == estado) contador = contador + 1;
            }
            return contador;
        }

        // las reservaciones activas son todas las que no estan canceladas
        public static int ContarActivas(Reservacion[] lista)
        {
            int contador = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (lista[i].Estado != "Cancelada") contador = contador + 1;
            }
            return contador;
        }

        // revisa si el salon ya esta reservado ese dia (idAExcluir = 0 si la reservacion es nueva)
        public static bool FechaOcupada(int idSalon, DateTime fecha, int idAExcluir)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "SELECT COUNT(*) FROM Reservaciones " +
                    "WHERE SalonId = @salon AND Fecha = @fecha AND Estado <> 'Cancelada' AND Id <> @id";
                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@salon", idSalon);
                comando.Parameters.AddWithValue("@fecha", fecha.Date);
                comando.Parameters.AddWithValue("@id", idAExcluir);

                int cantidad = (int)comando.ExecuteScalar();
                return cantidad > 0;
            }
            catch (Exception ex) { throw new Exception("No se pudo revisar la fecha de la reservación.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Agregar(Reservacion reservacion)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "INSERT INTO Reservaciones (ClienteId, EventoId, SalonId, Fecha, FechaCreacion, Estado, Total) " +
                    "VALUES (@cliente, @evento, @salon, @fecha, @fechaCreacion, @estado, @total)";

                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@cliente", reservacion.ClienteId);
                comando.Parameters.AddWithValue("@evento", reservacion.EventoId);
                comando.Parameters.AddWithValue("@salon", reservacion.SalonId);
                comando.Parameters.AddWithValue("@fecha", reservacion.Fecha.Date);
                comando.Parameters.AddWithValue("@fechaCreacion", DateTime.Today);
                comando.Parameters.AddWithValue("@estado", reservacion.Estado);
                comando.Parameters.AddWithValue("@total", reservacion.Total);

                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo agregar la reservación.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Actualizar(Reservacion reservacion)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "UPDATE Reservaciones SET ClienteId = @cliente, EventoId = @evento, SalonId = @salon, " +
                    "Fecha = @fecha, Estado = @estado, Total = @total WHERE Id = @id";

                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@cliente", reservacion.ClienteId);
                comando.Parameters.AddWithValue("@evento", reservacion.EventoId);
                comando.Parameters.AddWithValue("@salon", reservacion.SalonId);
                comando.Parameters.AddWithValue("@fecha", reservacion.Fecha.Date);
                comando.Parameters.AddWithValue("@estado", reservacion.Estado);
                comando.Parameters.AddWithValue("@total", reservacion.Total);
                comando.Parameters.AddWithValue("@id", reservacion.Id);

                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo actualizar la reservación.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Eliminar(int idReservacion)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                SqlCommand comando = new SqlCommand("UPDATE Reservaciones SET Estado = 'Cancelada' WHERE Id = @id", conexion);
                comando.Parameters.AddWithValue("@id", idReservacion);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo cancelar la reservación.", ex); }
            finally
            {
                conexion.Close();
            }
        }
    }
}
