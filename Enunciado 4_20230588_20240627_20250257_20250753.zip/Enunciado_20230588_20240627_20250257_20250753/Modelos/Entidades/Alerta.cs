﻿using System;
using System.Data.SqlClient;
using Modelos.Conexion_DB;

namespace Modelos
{
    // una alerta pendiente: un evento que se acerca o una reservacion sin confirmar
    public class Alerta
    {
        private string tipo;
        private string detalle;
        private DateTime fecha;

        public string Tipo { get => tipo; set => tipo = value; }
        public string Detalle { get => detalle; set => detalle = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }

        public Alerta()
        {
            tipo = "";
            detalle = "";
            fecha = DateTime.Today;
        }

        // consulta directamente los eventos cercanos y las reservaciones pendientes
        public static Alerta[] ObtenerPendientes()
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return new Alerta[0];

            try
            {
                Alerta[] alertas = new Alerta[50];
                int total = 0;

                string comandoSQL =
                    "SELECT N'Evento próximo' AS Tipo, e.Nombre AS Detalle, e.Fecha " +
                    "FROM Eventos e WHERE e.Estado <> 'Cancelado' " +
                    "AND e.Fecha >= CONVERT(date, GETDATE()) " +
                    "AND e.Fecha <= DATEADD(DAY, 30, CONVERT(date, GETDATE())) " +
                    "UNION ALL " +
                    "SELECT N'Reservación pendiente', N'Reservación #' + CONVERT(nvarchar(20), r.Id), r.Fecha " +
                    "FROM Reservaciones r WHERE r.Estado = 'Pendiente' AND r.Fecha >= CONVERT(date, GETDATE()) " +
                    "ORDER BY Fecha ASC";
                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == alertas.Length) Array.Resize(ref alertas, alertas.Length * 2);

                    Alerta alerta = new Alerta();
                    alerta.Tipo = lector["Tipo"].ToString();
                    alerta.Detalle = lector["Detalle"].ToString();
                    alerta.Fecha = (DateTime)lector["Fecha"];
                    alertas[total] = alerta;
                    total = total + 1;
                }
                lector.Close();

                Array.Resize(ref alertas, total);
                return alertas;
            }
            catch (Exception ex) { throw new Exception("No se pudieron cargar las alertas.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static Alerta[] ObtenerTodas()
        {
            return ObtenerPendientes();
        }
    }
}
