using System;
using System.Data.SqlClient;
using Modelos.Conexion_DB;

namespace Modelos
{
    public class Perfil
    {
        public int IdPerfil { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public bool Activo { get; set; }

        public Perfil()
        {
            Nombre = "";
            Descripcion = "";
            Activo = true;
        }

        public string EstadoTexto
        {
            get
            {
                if (Activo) return "Activo";
                return "Inactivo";
            }
        }

        public static Perfil[] ObtenerTodos()
        {
            SqlConnection conexion = Conexion.Conectar();
            try
            {
                Perfil[] perfiles = new Perfil[20];
                int total = 0;
                SqlCommand comando = new SqlCommand("SELECT IdPerfil, Nombre, Descripcion, Activo FROM S_PerfilesUsuarios ORDER BY IdPerfil", conexion);
                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == perfiles.Length) Array.Resize(ref perfiles, perfiles.Length * 2);
                    Perfil perfil = new Perfil();
                    perfil.IdPerfil = Convert.ToInt32(lector["IdPerfil"]);
                    perfil.Nombre = lector["Nombre"].ToString();
                    perfil.Descripcion = lector["Descripcion"].ToString();
                    perfil.Activo = Convert.ToBoolean(lector["Activo"]);
                    perfiles[total] = perfil;
                    total = total + 1;
                }
                lector.Close();
                Array.Resize(ref perfiles, total);
                return perfiles;
            }
            catch (Exception ex) { throw new Exception("No se pudieron listar los perfiles.", ex); }
            finally { conexion.Close(); }
        }

        public static bool Guardar(Perfil perfil)
        {
            SqlConnection conexion = Conexion.Conectar();
            try
            {
                SqlCommand comando;
                if (perfil.IdPerfil == 0)
                {
                    comando = new SqlCommand("INSERT INTO S_PerfilesUsuarios (Nombre, Descripcion, Activo) VALUES (@nombre, @descripcion, @activo)", conexion);
                }
                else
                {
                    comando = new SqlCommand("UPDATE S_PerfilesUsuarios SET Nombre = @nombre, Descripcion = @descripcion, Activo = @activo WHERE IdPerfil = @id", conexion);
                    comando.Parameters.AddWithValue("@id", perfil.IdPerfil);
                }
                comando.Parameters.AddWithValue("@nombre", perfil.Nombre.Trim());
                comando.Parameters.AddWithValue("@descripcion", perfil.Descripcion.Trim());
                comando.Parameters.AddWithValue("@activo", perfil.Activo);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo guardar el perfil.", ex); }
            finally { conexion.Close(); }
        }

        public static bool Desactivar(int idPerfil)
        {
            SqlConnection conexion = Conexion.Conectar();
            try
            {
                SqlCommand comando = new SqlCommand("UPDATE S_PerfilesUsuarios SET Activo = 0 WHERE IdPerfil = @id", conexion);
                comando.Parameters.AddWithValue("@id", idPerfil);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo desactivar el perfil.", ex); }
            finally { conexion.Close(); }
        }
    }
}
