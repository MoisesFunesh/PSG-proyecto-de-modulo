using System;
using System.Data.SqlClient;
using Modelos.Conexion_DB;

namespace Modelos
{
    public class OpcionPermiso
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

        public OpcionPermiso()
        {
            Nombre = "";
        }
    }

    public class Permiso
    {
        private string modulo;
        private bool puedeConsultar;
        private bool puedeCrear;
        private bool puedeEditar;
        private bool puedeEliminar;

        public string Modulo { get => modulo; set => modulo = value; }
        public bool PuedeConsultar { get => puedeConsultar; set => puedeConsultar = value; }
        public bool PuedeCrear { get => puedeCrear; set => puedeCrear = value; }
        public bool PuedeEditar { get => puedeEditar; set => puedeEditar = value; }
        public bool PuedeEliminar { get => puedeEliminar; set => puedeEliminar = value; }

        public Permiso()
        {
            modulo = "";
            puedeConsultar = false;
            puedeCrear = false;
            puedeEditar = false;
            puedeEliminar = false;
        }

        public static Permiso[] ObtenerPorPerfil(int idPerfil)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return new Permiso[0];
            try
            {
                Permiso[] permisos = new Permiso[20];
                int total = 0;
                string consulta = "SELECT m.Modulo, d.PuedeConsultar, d.PuedeCrear, d.PuedeEditar, d.PuedeEliminar " +
                    "FROM D_OpcionesPerfiles d INNER JOIN C_OpcionesMenu m ON m.IdOpcionMenu = d.IdOpcionMenu " +
                    "WHERE d.IdPerfil = @perfil AND m.Activo = 1 ORDER BY m.IdOpcionMenu";
                SqlCommand comando = new SqlCommand(consulta, conexion);
                comando.Parameters.AddWithValue("@perfil", idPerfil);
                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == permisos.Length) Array.Resize(ref permisos, permisos.Length * 2);
                    Permiso permiso = new Permiso();
                    permiso.Modulo = lector["Modulo"].ToString();
                    permiso.PuedeConsultar = Convert.ToBoolean(lector["PuedeConsultar"]);
                    permiso.PuedeCrear = Convert.ToBoolean(lector["PuedeCrear"]);
                    permiso.PuedeEditar = Convert.ToBoolean(lector["PuedeEditar"]);
                    permiso.PuedeEliminar = Convert.ToBoolean(lector["PuedeEliminar"]);
                    permisos[total] = permiso;
                    total = total + 1;
                }
                lector.Close();
                Array.Resize(ref permisos, total);
                return permisos;
            }
            catch (Exception ex) { throw new Exception("No se pudieron obtener los permisos.", ex); }
            finally { conexion.Close(); }
        }

        public static bool TienePermiso(int idPerfil, string modulo, string accion)
        {
            Permiso[] permisos = ObtenerPorPerfil(idPerfil);
            for (int i = 0; i < permisos.Length; i++)
            {
                if (string.Equals(permisos[i].Modulo, modulo, StringComparison.OrdinalIgnoreCase))
                {
                    if (accion == "consultar") return permisos[i].PuedeConsultar;
                    if (accion == "crear") return permisos[i].PuedeCrear;
                    if (accion == "editar") return permisos[i].PuedeEditar;
                    if (accion == "eliminar") return permisos[i].PuedeEliminar;
                }
            }
            return false;
        }

        public static OpcionPermiso[] ObtenerPerfiles()
        {
            return ObtenerCatalogo("SELECT IdPerfil AS Id, Nombre FROM S_PerfilesUsuarios WHERE Activo = 1 ORDER BY IdPerfil");
        }

        public static OpcionPermiso[] ObtenerOpciones()
        {
            return ObtenerCatalogo("SELECT IdOpcionMenu AS Id, Modulo AS Nombre FROM C_OpcionesMenu WHERE Activo = 1 ORDER BY IdOpcionMenu");
        }

        private static OpcionPermiso[] ObtenerCatalogo(string consulta)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return new OpcionPermiso[0];
            try
            {
                OpcionPermiso[] lista = new OpcionPermiso[20];
                int total = 0;
                SqlCommand comando = new SqlCommand(consulta, conexion);
                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == lista.Length) Array.Resize(ref lista, lista.Length * 2);
                    OpcionPermiso opcion = new OpcionPermiso();
                    opcion.Id = Convert.ToInt32(lector["Id"]);
                    opcion.Nombre = lector["Nombre"].ToString();
                    lista[total] = opcion;
                    total = total + 1;
                }
                lector.Close();
                Array.Resize(ref lista, total);
                return lista;
            }
            catch (Exception ex) { throw new Exception("No se pudieron cargar los catálogos de permisos.", ex); }
            finally { conexion.Close(); }
        }

        public static bool Guardar(int idPerfil, int idOpcionMenu, bool consultar, bool crear, bool editar, bool eliminar)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;
            try
            {
                string actualizar =
                    "UPDATE D_OpcionesPerfiles SET PuedeConsultar = @consultar, PuedeCrear = @crear, " +
                    "PuedeEditar = @editar, PuedeEliminar = @eliminar " +
                    "WHERE IdPerfil = @perfil AND IdOpcionMenu = @opcion";
                SqlCommand comandoActualizar = new SqlCommand(actualizar, conexion);
                AgregarParametros(comandoActualizar, idPerfil, idOpcionMenu, consultar, crear, editar, eliminar);
                int filas = comandoActualizar.ExecuteNonQuery();

                if (filas == 0)
                {
                    string insertar =
                        "INSERT INTO D_OpcionesPerfiles (IdPerfil, IdOpcionMenu, PuedeConsultar, PuedeCrear, PuedeEditar, PuedeEliminar) " +
                        "VALUES (@perfil, @opcion, @consultar, @crear, @editar, @eliminar)";
                    SqlCommand comandoInsertar = new SqlCommand(insertar, conexion);
                    AgregarParametros(comandoInsertar, idPerfil, idOpcionMenu, consultar, crear, editar, eliminar);
                    comandoInsertar.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo guardar el permiso.", ex); }
            finally { conexion.Close(); }
        }

        private static void AgregarParametros(SqlCommand comando, int idPerfil, int idOpcionMenu,
            bool consultar, bool crear, bool editar, bool eliminar)
        {
            comando.Parameters.AddWithValue("@perfil", idPerfil);
            comando.Parameters.AddWithValue("@opcion", idOpcionMenu);
            comando.Parameters.AddWithValue("@consultar", consultar);
            comando.Parameters.AddWithValue("@crear", crear);
            comando.Parameters.AddWithValue("@editar", editar);
            comando.Parameters.AddWithValue("@eliminar", eliminar);
        }
    }
}
