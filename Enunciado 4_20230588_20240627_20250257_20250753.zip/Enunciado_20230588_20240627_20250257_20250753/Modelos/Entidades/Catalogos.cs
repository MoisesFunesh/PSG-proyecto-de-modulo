﻿namespace Modelos
{
    // listas fijas que usan los combos y filtros de los formularios.
    // deben coincidir con los CHECK de las tablas en el script SQL
    public static class Catalogos
    {
        public static readonly string[] TiposEvento = { "Boda", "Corporativo", "Quinceañera", "Graduación", "Gala", "Social" };
        public static readonly string[] EstadosEvento = { "Confirmado", "Pendiente", "Cancelado" };
        public static readonly string[] EstadosSalon = { "Disponible", "Ocupado", "Mantenimiento" };
        public static readonly string[] CategoriasServicio = { "Alimentación", "Audio/Video", "Decoración", "Multimedia", "Entretenimiento" };
        public static readonly string[] EstadosServicio = { "Activo", "Inactivo" };
        public static readonly string[] EstadosReserva = { "Confirmada", "Pendiente", "Cancelada" };
        public static readonly string[] EstadosCotizacion = { "Pendiente", "Aceptada", "Rechazada" };
    }
}
