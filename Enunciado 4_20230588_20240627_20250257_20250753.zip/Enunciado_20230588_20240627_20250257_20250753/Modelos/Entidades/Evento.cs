﻿using System;
using System.Data.SqlClient;
using Modelos.Conexion_DB;

namespace Modelos
{
    // un evento que organiza la agencia (boda, congreso, graduacion...)
    // regla principal: un salon no puede tener dos eventos activos el mismo dia
    public class Evento
    {
        private int id;
        private string nombre;
        private string tipo;
        private DateTime fecha;
        private int salonId;
        private string salonNombre;
        private int clienteId;
        private string clienteNombre;
        private string estado;
        private decimal monto;

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Tipo { get => tipo; set => tipo = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }
        public int SalonId { get => salonId; set => salonId = value; }
        public string SalonNombre { get => salonNombre; set => salonNombre = value; }
        public int ClienteId { get => clienteId; set => clienteId = value; }
        public string ClienteNombre { get => clienteNombre; set => clienteNombre = value; }
        // Confirmado, Pendiente o Cancelado
        public string Estado { get => estado; set => estado = value; }
        public decimal Monto { get => monto; set => monto = value; }

        public Evento()
        {
            nombre = "";
            tipo = "";
            fecha = DateTime.Today;
            salonNombre = "";
            clienteNombre = "";
            estado = "Pendiente";
            monto = 0;
        }

        // conecta con Eventos, Salones y Usuarios (el cliente es un usuario)
        private const string SELECT_BASE =
            "SELECT e.Id, e.Nombre, e.Tipo, e.Fecha, e.SalonId, s.Nombre AS SalonNombre, " +
            "e.ClienteId, u.Nombre AS ClienteNombre, e.Estado, e.Monto " +
            "FROM Eventos e " +
            "INNER JOIN Salones s ON s.Id = e.SalonId " +
            "INNER JOIN S_Usuarios u ON u.Id = e.ClienteId ";

        private static Evento LeerEvento(SqlDataReader lector)
        {
            Evento evento = new Evento();
            evento.Id = (int)lector["Id"];
            evento.Nombre = lector["Nombre"].ToString();
            evento.Tipo = lector["Tipo"].ToString();
            evento.Fecha = (DateTime)lector["Fecha"];
            evento.SalonId = (int)lector["SalonId"];
            evento.SalonNombre = lector["SalonNombre"].ToString();
            evento.ClienteId = (int)lector["ClienteId"];
            evento.ClienteNombre = lector["ClienteNombre"].ToString();
            evento.Estado = lector["Estado"].ToString();
            evento.Monto = (decimal)lector["Monto"];
            return evento;
        }

        public static Evento[] ObtenerTodos()
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return new Evento[0];

            try
            {
                Evento[] eventos = new Evento[100];
                int total = 0;

                SqlCommand comando = new SqlCommand(SELECT_BASE + "ORDER BY e.Fecha ASC", conexion);
                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == eventos.Length) Array.Resize(ref eventos, eventos.Length * 2);
                    eventos[total] = LeerEvento(lector);
                    total = total + 1;
                }
                lector.Close();

                Array.Resize(ref eventos, total);
                return eventos;
            }
            catch (Exception ex) { throw new Exception("No se pudieron listar los eventos.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static Evento ObtenerPorId(int idEvento)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return null;
            try
            {
                SqlCommand comando = new SqlCommand(SELECT_BASE + "WHERE e.Id = @id", conexion);
                comando.Parameters.AddWithValue("@id", idEvento);
                SqlDataReader lector = comando.ExecuteReader();
                Evento evento = null;
                if (lector.Read()) evento = LeerEvento(lector);
                lector.Close();
                return evento;
            }
            catch (Exception ex) { throw new Exception("No se pudo consultar el evento.", ex); }
            finally { conexion.Close(); }
        }

        // busca en memoria por nombre, tipo, salon, cliente o estado
        public static Evento[] Buscar(Evento[] lista, string texto)
        {
            if (string.IsNullOrWhiteSpace(texto)) return lista;

            Evento[] resultado = new Evento[lista.Length];
            int total = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (Coincide(lista[i], texto))
                {
                    resultado[total] = lista[i];
                    total = total + 1;
                }
            }
            Array.Resize(ref resultado, total);
            return resultado;
        }

        private static bool Coincide(Evento evento, string texto)
        {
            string textoBusqueda = texto.Trim().ToLower();
            if (evento.Nombre.ToLower().Contains(textoBusqueda)) return true;
            if (evento.Tipo.ToLower().Contains(textoBusqueda)) return true;
            if (evento.SalonNombre.ToLower().Contains(textoBusqueda)) return true;
            if (evento.ClienteNombre.ToLower().Contains(textoBusqueda)) return true;
            if (evento.Estado.ToLower().Contains(textoBusqueda)) return true;
            return false;
        }

        public static int ContarPorEstado(Evento[] lista, string estado)
        {
            int contador = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (lista[i].Estado == estado) contador = contador + 1;
            }
            return contador;
        }

        // los eventos activos son todos los que no estan cancelados
        public static int ContarActivos(Evento[] lista)
        {
            int contador = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (lista[i].Estado != "Cancelado") contador = contador + 1;
            }
            return contador;
        }

        // suma el monto de los eventos confirmados (los ingresos del dashboard)
        public static decimal SumarMontoConfirmado(Evento[] lista)
        {
            decimal suma = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (lista[i].Estado == "Confirmado") suma = suma + lista[i].Monto;
            }
            return suma;
        }

        // revisa si ya hay otro evento (no cancelado) en ese salon y esa fecha.
        // idAExcluir se usa al editar, para no chocar contra si mismo (0 si es nuevo)
        public static bool SalonOcupado(int idSalon, DateTime fecha, int idAExcluir)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "SELECT COUNT(*) FROM Eventos " +
                    "WHERE SalonId = @salon AND Fecha = @fecha AND Estado <> 'Cancelado' AND Id <> @id";
                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@salon", idSalon);
                comando.Parameters.AddWithValue("@fecha", fecha.Date);
                comando.Parameters.AddWithValue("@id", idAExcluir);

                int cantidad = (int)comando.ExecuteScalar();
                return cantidad > 0;
            }
            catch (Exception ex) { throw new Exception("No se pudo revisar la disponibilidad del salón.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Agregar(Evento evento)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "INSERT INTO Eventos (Nombre, Tipo, Fecha, SalonId, ClienteId, Estado, Monto) " +
                    "VALUES (@nombre, @tipo, @fecha, @salon, @cliente, @estado, @monto)";

                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@nombre", evento.Nombre.Trim());
                comando.Parameters.AddWithValue("@tipo", evento.Tipo);
                comando.Parameters.AddWithValue("@fecha", evento.Fecha.Date);
                comando.Parameters.AddWithValue("@salon", evento.SalonId);
                comando.Parameters.AddWithValue("@cliente", evento.ClienteId);
                comando.Parameters.AddWithValue("@estado", evento.Estado);
                comando.Parameters.AddWithValue("@monto", evento.Monto);

                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo agregar el evento.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Actualizar(Evento evento)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "UPDATE Eventos SET Nombre = @nombre, Tipo = @tipo, Fecha = @fecha, SalonId = @salon, " +
                    "ClienteId = @cliente, Estado = @estado, Monto = @monto WHERE Id = @id";

                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@nombre", evento.Nombre.Trim());
                comando.Parameters.AddWithValue("@tipo", evento.Tipo);
                comando.Parameters.AddWithValue("@fecha", evento.Fecha.Date);
                comando.Parameters.AddWithValue("@salon", evento.SalonId);
                comando.Parameters.AddWithValue("@cliente", evento.ClienteId);
                comando.Parameters.AddWithValue("@estado", evento.Estado);
                comando.Parameters.AddWithValue("@monto", evento.Monto);
                comando.Parameters.AddWithValue("@id", evento.Id);

                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo actualizar el evento.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Eliminar(int idEvento)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                SqlCommand comando = new SqlCommand("UPDATE Eventos SET Estado = 'Cancelado' WHERE Id = @id", conexion);
                comando.Parameters.AddWithValue("@id", idEvento);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo cancelar el evento.", ex); }
            finally
            {
                conexion.Close();
            }
        }
    }
}
