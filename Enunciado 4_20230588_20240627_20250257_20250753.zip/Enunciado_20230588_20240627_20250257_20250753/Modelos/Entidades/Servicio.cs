﻿using System;
using System.Data.SqlClient;
using Modelos.Conexion_DB;

namespace Modelos
{
    // un servicio del catalogo de la agencia (banquete, sonido, decoracion...)
    public class Servicio
    {
        private int id;
        private string nombre;
        private string categoria;
        private string descripcion;
        private decimal precio;
        private bool activo;

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Categoria { get => categoria; set => categoria = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public decimal Precio { get => precio; set => precio = value; }
        public bool Activo { get => activo; set => activo = value; }

        // texto que se muestra en la tabla
        public string Estado
        {
            get
            {
                if (activo) return "Activo";
                return "Inactivo";
            }
        }

        public Servicio()
        {
            nombre = "";
            categoria = "";
            descripcion = "";
            precio = 0;
            activo = true;
        }

        // conecta con la tabla Servicios
        private const string SELECT_BASE =
            "SELECT Id, Nombre, Categoria, Descripcion, Precio, Activo FROM Servicios ";

        private static Servicio LeerServicio(SqlDataReader lector)
        {
            Servicio servicio = new Servicio();
            servicio.Id = (int)lector["Id"];
            servicio.Nombre = lector["Nombre"].ToString();
            servicio.Categoria = lector["Categoria"].ToString();
            servicio.Descripcion = lector["Descripcion"].ToString();
            servicio.Precio = (decimal)lector["Precio"];
            servicio.Activo = (bool)lector["Activo"];
            return servicio;
        }

        public static Servicio[] ObtenerTodos()
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return new Servicio[0];

            try
            {
                Servicio[] servicios = new Servicio[50];
                int total = 0;

                SqlCommand comando = new SqlCommand(SELECT_BASE + "ORDER BY Id ASC", conexion);
                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == servicios.Length) Array.Resize(ref servicios, servicios.Length * 2);
                    servicios[total] = LeerServicio(lector);
                    total = total + 1;
                }
                lector.Close();

                Array.Resize(ref servicios, total);
                return servicios;
            }
            catch (Exception ex) { throw new Exception("No se pudieron listar los servicios.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        // busca en memoria por nombre, categoria o descripcion
        public static Servicio[] Buscar(Servicio[] lista, string texto)
        {
            if (string.IsNullOrWhiteSpace(texto)) return lista;

            Servicio[] resultado = new Servicio[lista.Length];
            int total = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (Coincide(lista[i], texto))
                {
                    resultado[total] = lista[i];
                    total = total + 1;
                }
            }
            Array.Resize(ref resultado, total);
            return resultado;
        }

        private static bool Coincide(Servicio servicio, string texto)
        {
            string textoBusqueda = texto.Trim().ToLower();
            if (servicio.Nombre.ToLower().Contains(textoBusqueda)) return true;
            if (servicio.Categoria.ToLower().Contains(textoBusqueda)) return true;
            if (servicio.Descripcion.ToLower().Contains(textoBusqueda)) return true;
            if (servicio.Estado.ToLower().Contains(textoBusqueda)) return true;
            return false;
        }

        public static int ContarActivos(Servicio[] lista)
        {
            int contador = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (lista[i].Activo) contador = contador + 1;
            }
            return contador;
        }

        public static bool Agregar(Servicio servicio)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "INSERT INTO Servicios (Nombre, Categoria, Precio, Descripcion, Activo) " +
                    "VALUES (@nombre, @categoria, @precio, @descripcion, @activo)";

                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@nombre", servicio.Nombre.Trim());
                comando.Parameters.AddWithValue("@categoria", servicio.Categoria);
                comando.Parameters.AddWithValue("@precio", servicio.Precio);
                comando.Parameters.AddWithValue("@descripcion", servicio.Descripcion.Trim());
                comando.Parameters.AddWithValue("@activo", servicio.Activo);

                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo agregar el servicio.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Actualizar(Servicio servicio)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "UPDATE Servicios SET Nombre = @nombre, Categoria = @categoria, Precio = @precio, " +
                    "Descripcion = @descripcion, Activo = @activo WHERE Id = @id";

                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@nombre", servicio.Nombre.Trim());
                comando.Parameters.AddWithValue("@categoria", servicio.Categoria);
                comando.Parameters.AddWithValue("@precio", servicio.Precio);
                comando.Parameters.AddWithValue("@descripcion", servicio.Descripcion.Trim());
                comando.Parameters.AddWithValue("@activo", servicio.Activo);
                comando.Parameters.AddWithValue("@id", servicio.Id);

                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo actualizar el servicio.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Eliminar(int idServicio)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                SqlCommand comando = new SqlCommand("UPDATE Servicios SET Activo = 0 WHERE Id = @id", conexion);
                comando.Parameters.AddWithValue("@id", idServicio);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo desactivar el servicio.", ex); }
            finally
            {
                conexion.Close();
            }
        }
    }
}
