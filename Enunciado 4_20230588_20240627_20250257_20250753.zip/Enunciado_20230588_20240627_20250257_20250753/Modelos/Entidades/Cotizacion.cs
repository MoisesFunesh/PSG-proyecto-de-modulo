﻿using System;
using System.Data.SqlClient;
using Modelos.Conexion_DB;

namespace Modelos
{
    // un renglon de una cotizacion (concepto + precio)
    public class CotizacionItem
    {
        private int id;
        private string concepto;
        private decimal precio;

        public int Id { get => id; set => id = value; }
        public string Concepto { get => concepto; set => concepto = value; }
        public decimal Precio { get => precio; set => precio = value; }

        public CotizacionItem()
        {
            id = 0;
            concepto = "";
            precio = 0;
        }
    }

    // la propuesta economica que recibe un cliente para su evento
    public class Cotizacion
    {
        private int id;
        private int clienteId;
        private string clienteNombre;
        private string descripcion;
        private decimal descuento;
        private DateTime fechaEmision;
        private DateTime fechaVence;
        private string estado;
        private CotizacionItem[] items;

        public int Id { get => id; set => id = value; }
        public int ClienteId { get => clienteId; set => clienteId = value; }
        public string ClienteNombre { get => clienteNombre; set => clienteNombre = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public decimal Descuento { get => descuento; set => descuento = value; }
        public DateTime FechaEmision { get => fechaEmision; set => fechaEmision = value; }
        public DateTime FechaVence { get => fechaVence; set => fechaVence = value; }
        // Pendiente, Aceptada o Rechazada
        public string Estado { get => estado; set => estado = value; }
        public CotizacionItem[] Items { get => items; set => items = value; }

        // suma de todos los renglones, antes del descuento
        public decimal Subtotal
        {
            get
            {
                decimal suma = 0;
                for (int i = 0; i < items.Length; i++)
                {
                    suma = suma + items[i].Precio;
                }
                return suma;
            }
        }

        public decimal Total
        {
            get { return Subtotal - descuento; }
        }

        public Cotizacion()
        {
            descripcion = "";
            clienteNombre = "";
            descuento = 0;
            fechaEmision = DateTime.Today;
            fechaVence = DateTime.Today;
            estado = "Pendiente";
            items = new CotizacionItem[0];
        }

        // trae las cotizaciones de un cliente, cada una con sus renglones
        public static Cotizacion[] ObtenerPorCliente(int idCliente)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return new Cotizacion[0];

            try
            {
                Cotizacion[] cotizaciones = new Cotizacion[20];
                int total = 0;

                string comandoSQL =
                    "SELECT Id, ClienteId, Descripcion, Descuento, FechaEmision, FechaVence, Estado " +
                    "FROM Cotizaciones WHERE ClienteId = @cliente ORDER BY Id ASC";
                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@cliente", idCliente);

                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == cotizaciones.Length) Array.Resize(ref cotizaciones, cotizaciones.Length * 2);

                    Cotizacion cotizacion = new Cotizacion();
                    cotizacion.Id = (int)lector["Id"];
                    cotizacion.ClienteId = (int)lector["ClienteId"];
                    cotizacion.Descripcion = lector["Descripcion"].ToString();
                    cotizacion.Descuento = (decimal)lector["Descuento"];
                    cotizacion.FechaEmision = (DateTime)lector["FechaEmision"];
                    cotizacion.FechaVence = (DateTime)lector["FechaVence"];
                    cotizacion.Estado = lector["Estado"].ToString();
                    cotizaciones[total] = cotizacion;
                    total = total + 1;
                }
                lector.Close();
                Array.Resize(ref cotizaciones, total);

                // el lector anterior ya se cerro, ahora se trae el detalle de cada cotizacion
                for (int i = 0; i < cotizaciones.Length; i++)
                {
                    cotizaciones[i].Items = ObtenerRenglones(conexion, cotizaciones[i].Id);
                }

                return cotizaciones;
            }
            catch (Exception ex) { throw new Exception("No se pudieron listar las cotizaciones.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        private static CotizacionItem[] ObtenerRenglones(SqlConnection conexion, int idCotizacion)
        {
            CotizacionItem[] renglones = new CotizacionItem[10];
            int total = 0;

            string comandoSQL = "SELECT Id, Concepto, Precio FROM CotizacionItems WHERE CotizacionId = @id ORDER BY Id ASC";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.Parameters.AddWithValue("@id", idCotizacion);

            SqlDataReader lector = comando.ExecuteReader();
            while (lector.Read())
            {
                if (total == renglones.Length) Array.Resize(ref renglones, renglones.Length * 2);

                CotizacionItem renglon = new CotizacionItem();
                renglon.Id = Convert.ToInt32(lector["Id"]);
                renglon.Concepto = lector["Concepto"].ToString();
                renglon.Precio = (decimal)lector["Precio"];
                renglones[total] = renglon;
                total = total + 1;
            }
            lector.Close();

            Array.Resize(ref renglones, total);
            return renglones;
        }

        public static int ContarPendientes(Cotizacion[] lista)
        {
            int contador = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (lista[i].Estado == "Pendiente") contador = contador + 1;
            }
            return contador;
        }

        // el cliente acepta una cotizacion. solo se puede si es suya y sigue pendiente
        public static bool Aceptar(int idCotizacion, int idCliente)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "UPDATE Cotizaciones SET Estado = 'Aceptada' " +
                    "WHERE Id = @id AND ClienteId = @cliente AND Estado = 'Pendiente'";
                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@id", idCotizacion);
                comando.Parameters.AddWithValue("@cliente", idCliente);

                int filas = comando.ExecuteNonQuery();
                if (filas == 0)
                {
                    throw new InvalidOperationException("La cotización ya no está pendiente o no pertenece al cliente.");
                }
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo aceptar la cotización.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Rechazar(int idCotizacion, int idCliente)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;
            try
            {
                SqlCommand comando = new SqlCommand(
                    "UPDATE Cotizaciones SET Estado = 'Rechazada' WHERE Id = @id AND ClienteId = @cliente AND Estado = 'Pendiente'", conexion);
                comando.Parameters.AddWithValue("@id", idCotizacion);
                comando.Parameters.AddWithValue("@cliente", idCliente);
                if (comando.ExecuteNonQuery() == 0)
                {
                    throw new InvalidOperationException("La cotización ya no está pendiente o no pertenece al cliente.");
                }
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo rechazar la cotización.", ex); }
            finally { conexion.Close(); }
        }

        public static Cotizacion[] ObtenerTodas()
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return new Cotizacion[0];
            try
            {
                Cotizacion[] cotizaciones = new Cotizacion[50];
                int total = 0;
                SqlCommand comando = new SqlCommand("SELECT c.Id, c.ClienteId, u.Nombre AS ClienteNombre, c.Descripcion, c.Descuento, c.FechaEmision, c.FechaVence, c.Estado FROM Cotizaciones c INNER JOIN S_Usuarios u ON u.Id = c.ClienteId ORDER BY c.FechaEmision DESC", conexion);
                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == cotizaciones.Length) Array.Resize(ref cotizaciones, cotizaciones.Length * 2);
                    Cotizacion cotizacion = new Cotizacion();
                    cotizacion.Id = Convert.ToInt32(lector["Id"]);
                    cotizacion.ClienteId = Convert.ToInt32(lector["ClienteId"]);
                    cotizacion.ClienteNombre = lector["ClienteNombre"].ToString();
                    cotizacion.Descripcion = lector["Descripcion"].ToString();
                    cotizacion.Descuento = Convert.ToDecimal(lector["Descuento"]);
                    cotizacion.FechaEmision = Convert.ToDateTime(lector["FechaEmision"]);
                    cotizacion.FechaVence = Convert.ToDateTime(lector["FechaVence"]);
                    cotizacion.Estado = lector["Estado"].ToString();
                    cotizaciones[total] = cotizacion;
                    total = total + 1;
                }
                lector.Close();
                Array.Resize(ref cotizaciones, total);
                for (int i = 0; i < cotizaciones.Length; i++) cotizaciones[i].Items = ObtenerRenglones(conexion, cotizaciones[i].Id);
                return cotizaciones;
            }
            catch (Exception ex) { throw new Exception("No se pudieron listar las cotizaciones.", ex); }
            finally { conexion.Close(); }
        }

        public static bool Guardar(Cotizacion cotizacion)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;
            SqlTransaction transaccion = null;
            try
            {
                transaccion = conexion.BeginTransaction();
                SqlCommand comando;
                if (cotizacion.Id == 0)
                {
                    comando = new SqlCommand("INSERT INTO Cotizaciones (ClienteId, Descripcion, Descuento, FechaEmision, FechaVence, Estado) OUTPUT INSERTED.Id VALUES (@cliente, @descripcion, @descuento, @emision, @vence, @estado)", conexion, transaccion);
                    AgregarParametros(comando, cotizacion);
                    cotizacion.Id = Convert.ToInt32(comando.ExecuteScalar());
                }
                else
                {
                    comando = new SqlCommand("UPDATE Cotizaciones SET ClienteId = @cliente, Descripcion = @descripcion, Descuento = @descuento, FechaEmision = @emision, FechaVence = @vence, Estado = @estado WHERE Id = @id", conexion, transaccion);
                    AgregarParametros(comando, cotizacion);
                    comando.Parameters.AddWithValue("@id", cotizacion.Id);
                    comando.ExecuteNonQuery();
                    comando = new SqlCommand("DELETE FROM CotizacionItems WHERE CotizacionId = @id", conexion, transaccion);
                    comando.Parameters.AddWithValue("@id", cotizacion.Id);
                    comando.ExecuteNonQuery();
                }
                for (int i = 0; i < cotizacion.Items.Length; i++)
                {
                    comando = new SqlCommand("INSERT INTO CotizacionItems (CotizacionId, Concepto, Precio) VALUES (@cotizacion, @concepto, @precio)", conexion, transaccion);
                    comando.Parameters.AddWithValue("@cotizacion", cotizacion.Id);
                    comando.Parameters.AddWithValue("@concepto", cotizacion.Items[i].Concepto.Trim());
                    comando.Parameters.AddWithValue("@precio", cotizacion.Items[i].Precio);
                    comando.ExecuteNonQuery();
                }
                transaccion.Commit();
                return true;
            }
            catch (Exception ex)
            {
                if (transaccion != null) transaccion.Rollback();
                throw new Exception("No se pudo guardar la cotización.", ex);
            }
            finally { conexion.Close(); }
        }

        private static void AgregarParametros(SqlCommand comando, Cotizacion cotizacion)
        {
            comando.Parameters.AddWithValue("@cliente", cotizacion.ClienteId);
            comando.Parameters.AddWithValue("@descripcion", cotizacion.Descripcion.Trim());
            comando.Parameters.AddWithValue("@descuento", cotizacion.Descuento);
            comando.Parameters.AddWithValue("@emision", cotizacion.FechaEmision.Date);
            comando.Parameters.AddWithValue("@vence", cotizacion.FechaVence.Date);
            comando.Parameters.AddWithValue("@estado", cotizacion.Estado);
        }

        public static bool CambiarEstado(int idCotizacion, string estadoNuevo)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;
            try
            {
                SqlCommand comando = new SqlCommand("UPDATE Cotizaciones SET Estado = @estado WHERE Id = @id", conexion);
                comando.Parameters.AddWithValue("@estado", estadoNuevo);
                comando.Parameters.AddWithValue("@id", idCotizacion);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo cambiar el estado de la cotización.", ex); }
            finally { conexion.Close(); }
        }

        public static bool Eliminar(int idCotizacion)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;
            try
            {
                SqlCommand comando = new SqlCommand("DELETE FROM Cotizaciones WHERE Id = @id", conexion);
                comando.Parameters.AddWithValue("@id", idCotizacion);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo eliminar la cotización.", ex); }
            finally { conexion.Close(); }
        }
    }
}
