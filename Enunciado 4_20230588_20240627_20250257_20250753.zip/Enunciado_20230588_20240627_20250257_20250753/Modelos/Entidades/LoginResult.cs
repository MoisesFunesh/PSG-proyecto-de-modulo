﻿namespace Modelos
{
    // guarda el resultado de un intento de inicio de sesion
    public class LoginResult
    {
        private bool exitoso;
        private string mensaje;
        private Usuario usuario;

        public bool Exitoso { get => exitoso; set => exitoso = value; }
        public string Mensaje { get => mensaje; set => mensaje = value; }
        public Usuario Usuario { get => usuario; set => usuario = value; }

        public LoginResult()
        {
            mensaje = "";
        }

        // para cuando el login falla
        public static LoginResult Fallo(string mensaje)
        {
            LoginResult resultado = new LoginResult();
            resultado.Exitoso = false;
            resultado.Mensaje = mensaje;
            return resultado;
        }

        // para cuando el login funciona
        public static LoginResult Ok(Usuario usuario)
        {
            LoginResult resultado = new LoginResult();
            resultado.Exitoso = true;
            resultado.Mensaje = "Bienvenido";
            resultado.Usuario = usuario;
            return resultado;
        }
    }
}
