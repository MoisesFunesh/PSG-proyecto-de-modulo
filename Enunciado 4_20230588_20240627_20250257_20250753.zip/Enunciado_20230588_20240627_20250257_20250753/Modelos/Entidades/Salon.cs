﻿using System;
using System.Data.SqlClient;
using Modelos.Conexion_DB;

namespace Modelos
{
    // un salon que la agencia puede reservar para un evento
    public class Salon
    {
        private int id;
        private string nombre;
        private int capacidad;
        private string ubicacion;
        private decimal precio;
        private string estado;

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public int Capacidad { get => capacidad; set => capacidad = value; }
        public string Ubicacion { get => ubicacion; set => ubicacion = value; }
        // tarifa por evento
        public decimal Precio { get => precio; set => precio = value; }
        // Disponible, Ocupado o Mantenimiento
        public string Estado { get => estado; set => estado = value; }

        public Salon()
        {
            nombre = "";
            capacidad = 100;
            ubicacion = "";
            precio = 0;
            estado = "Disponible";
        }

        // conecta con la tabla Salones
        private const string SELECT_BASE =
            "SELECT Id, Nombre, Capacidad, Ubicacion, Precio, Estado FROM Salones ";

        private static Salon LeerSalon(SqlDataReader lector)
        {
            Salon salon = new Salon();
            salon.Id = (int)lector["Id"];
            salon.Nombre = lector["Nombre"].ToString();
            salon.Capacidad = (int)lector["Capacidad"];
            salon.Ubicacion = lector["Ubicacion"].ToString();
            salon.Precio = (decimal)lector["Precio"];
            salon.Estado = lector["Estado"].ToString();
            return salon;
        }

        public static Salon[] ObtenerTodos()
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return new Salon[0];

            try
            {
                Salon[] salones = new Salon[50];
                int total = 0;

                SqlCommand comando = new SqlCommand(SELECT_BASE + "ORDER BY Id ASC", conexion);
                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == salones.Length) Array.Resize(ref salones, salones.Length * 2);
                    salones[total] = LeerSalon(lector);
                    total = total + 1;
                }
                lector.Close();

                Array.Resize(ref salones, total);
                return salones;
            }
            catch (Exception ex) { throw new Exception("No se pudieron listar los salones.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static Salon ObtenerPorId(int idSalon)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return null;
            try
            {
                SqlCommand comando = new SqlCommand(SELECT_BASE + "WHERE Id = @id", conexion);
                comando.Parameters.AddWithValue("@id", idSalon);
                SqlDataReader lector = comando.ExecuteReader();
                Salon salon = null;
                if (lector.Read()) salon = LeerSalon(lector);
                lector.Close();
                return salon;
            }
            catch (Exception ex) { throw new Exception("No se pudo consultar el salón.", ex); }
            finally { conexion.Close(); }
        }

        public static bool PuedeUsarse(int idSalon)
        {
            Salon salon = ObtenerPorId(idSalon);
            return salon != null && salon.Estado != "Mantenimiento";
        }

        // busca en memoria por nombre, ubicacion o estado
        public static Salon[] Buscar(Salon[] lista, string texto)
        {
            if (string.IsNullOrWhiteSpace(texto)) return lista;

            Salon[] resultado = new Salon[lista.Length];
            int total = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (Coincide(lista[i], texto))
                {
                    resultado[total] = lista[i];
                    total = total + 1;
                }
            }
            Array.Resize(ref resultado, total);
            return resultado;
        }

        private static bool Coincide(Salon salon, string texto)
        {
            string textoBusqueda = texto.Trim().ToLower();
            if (salon.Nombre.ToLower().Contains(textoBusqueda)) return true;
            if (salon.Ubicacion.ToLower().Contains(textoBusqueda)) return true;
            if (salon.Estado.ToLower().Contains(textoBusqueda)) return true;
            return false;
        }

        public static int ContarPorEstado(Salon[] lista, string estado)
        {
            int contador = 0;
            for (int i = 0; i < lista.Length; i++)
            {
                if (lista[i].Estado == estado) contador = contador + 1;
            }
            return contador;
        }

        public static bool Agregar(Salon salon)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "INSERT INTO Salones (Nombre, Capacidad, Ubicacion, Precio, Estado) " +
                    "VALUES (@nombre, @capacidad, @ubicacion, @precio, @estado)";

                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@nombre", salon.Nombre.Trim());
                comando.Parameters.AddWithValue("@capacidad", salon.Capacidad);
                comando.Parameters.AddWithValue("@ubicacion", salon.Ubicacion.Trim());
                comando.Parameters.AddWithValue("@precio", salon.Precio);
                comando.Parameters.AddWithValue("@estado", salon.Estado);

                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo agregar el salón.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Actualizar(Salon salon)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                string comandoSQL =
                    "UPDATE Salones SET Nombre = @nombre, Capacidad = @capacidad, Ubicacion = @ubicacion, " +
                    "Precio = @precio, Estado = @estado WHERE Id = @id";

                SqlCommand comando = new SqlCommand(comandoSQL, conexion);
                comando.Parameters.AddWithValue("@nombre", salon.Nombre.Trim());
                comando.Parameters.AddWithValue("@capacidad", salon.Capacidad);
                comando.Parameters.AddWithValue("@ubicacion", salon.Ubicacion.Trim());
                comando.Parameters.AddWithValue("@precio", salon.Precio);
                comando.Parameters.AddWithValue("@estado", salon.Estado);
                comando.Parameters.AddWithValue("@id", salon.Id);

                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo actualizar el salón.", ex); }
            finally
            {
                conexion.Close();
            }
        }

        public static bool Eliminar(int idSalon)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;

            try
            {
                SqlCommand revisar = new SqlCommand(
                    "SELECT (SELECT COUNT(*) FROM Eventos WHERE SalonId = @id) + " +
                    "(SELECT COUNT(*) FROM Reservaciones WHERE SalonId = @id)", conexion);
                revisar.Parameters.AddWithValue("@id", idSalon);
                int usos = Convert.ToInt32(revisar.ExecuteScalar());
                SqlCommand comando;
                if (usos > 0) comando = new SqlCommand("UPDATE Salones SET Estado = 'Mantenimiento' WHERE Id = @id", conexion);
                else comando = new SqlCommand("DELETE FROM Salones WHERE Id = @id", conexion);
                comando.Parameters.AddWithValue("@id", idSalon);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo quitar el salón.", ex); }
            finally
            {
                conexion.Close();
            }
        }
    }
}
