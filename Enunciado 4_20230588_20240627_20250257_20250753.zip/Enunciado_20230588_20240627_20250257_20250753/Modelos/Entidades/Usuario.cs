using System;
using System.Data.SqlClient;
using Modelos.Conexion_DB;

namespace Modelos
{
    // los nombres deben coincidir con S_PerfilesUsuarios
    public enum UsuarioRol
    {
        Administrador,
        Organizador,
        Cliente
    }

    public class Usuario
    {
        private int id;
        private string nombre;
        private string email;
        private string contrasena;
        private int idPerfil;
        private UsuarioRol rol;
        private string nombrePerfil;
        private bool activo;

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Email { get => email; set => email = value; }
        public string Contrasena { get => contrasena; set => contrasena = value; }
        public int IdPerfil { get => idPerfil; set => idPerfil = value; }
        public UsuarioRol Rol { get => rol; set => rol = value; }
        public string NombrePerfil { get => nombrePerfil; set => nombrePerfil = value; }
        public bool Activo { get => activo; set => activo = value; }
        public string RolTexto
        {
            get
            {
                if (string.IsNullOrWhiteSpace(nombrePerfil)) return rol.ToString();
                return nombrePerfil;
            }
        }

        public string EstadoTexto
        {
            get
            {
                if (activo) return "Activo";
                return "Inactivo";
            }
        }

        public Usuario()
        {
            nombre = "";
            email = "";
            contrasena = "";
            idPerfil = 3;
            rol = UsuarioRol.Cliente;
            nombrePerfil = "Cliente";
            activo = true;
        }

        private const string SELECT_BASE =
            "SELECT u.Id, u.Nombre, u.Email, u.PasswordHash, u.IdPerfil, " +
            "p.Nombre AS NombrePerfil, u.IdEstado " +
            "FROM S_Usuarios u " +
            "INNER JOIN S_PerfilesUsuarios p ON p.IdPerfil = u.IdPerfil ";

        private static Usuario LeerUsuario(SqlDataReader lector)
        {
            Usuario usuario = new Usuario();
            usuario.Id = Convert.ToInt32(lector["Id"]);
            usuario.Nombre = lector["Nombre"].ToString();
            usuario.Email = lector["Email"].ToString();
            usuario.Contrasena = lector["PasswordHash"].ToString();
            usuario.IdPerfil = Convert.ToInt32(lector["IdPerfil"]);
            usuario.NombrePerfil = lector["NombrePerfil"].ToString();
            usuario.Activo = Convert.ToInt32(lector["IdEstado"]) == 1;

            UsuarioRol rolLeido;
            if (Enum.TryParse(lector["NombrePerfil"].ToString(), out rolLeido)) usuario.Rol = rolLeido;
            return usuario;
        }

        public static LoginResult Login(string email, string contrasena)
        {
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(contrasena))
                return LoginResult.Fallo("Ingrese su correo y su contraseña.");

            SqlConnection conexion = null;
            try
            {
                conexion = Conexion.Conectar();
                SqlCommand comando = new SqlCommand(SELECT_BASE + "WHERE LOWER(u.Email) = LOWER(@email)", conexion);
                comando.Parameters.AddWithValue("@email", email.Trim());
                Usuario encontrado = null;
                SqlDataReader lector = comando.ExecuteReader();
                if (lector.Read()) encontrado = LeerUsuario(lector);
                lector.Close();
                if (encontrado == null || VerificarContrasena(contrasena, encontrado.Contrasena) == false)
                    return LoginResult.Fallo("Usuario o contraseña incorrectos.");
                if (encontrado.Activo == false)
                    return LoginResult.Fallo("Esta cuenta está desactivada. Contacte al administrador.");
                return LoginResult.Ok(encontrado);
            }
            catch (Exception ex)
            {
                return LoginResult.Fallo("No se pudo iniciar sesión: " + Ayuda.ObtenerMensajeAmigable(ex));
            }
            finally { if (conexion != null) conexion.Close(); }
        }

        private static bool VerificarContrasena(string escrita, string guardada)
        {
            try { return BCrypt.Net.BCrypt.Verify(escrita, guardada); }
            catch { return false; }
        }

        public static Usuario ObtenerPorId(int idUsuario)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return null;
            try
            {
                SqlCommand comando = new SqlCommand(SELECT_BASE + "WHERE u.Id = @id", conexion);
                comando.Parameters.AddWithValue("@id", idUsuario);
                SqlDataReader lector = comando.ExecuteReader();
                Usuario usuario = null;
                if (lector.Read()) usuario = LeerUsuario(lector);
                lector.Close();
                return usuario;
            }
            catch (Exception ex) { throw new Exception("No se pudo obtener el usuario.", ex); }
            finally { conexion.Close(); }
        }

        public static Usuario[] ObtenerTodos() { return ObtenerLista(SELECT_BASE + "ORDER BY u.Nombre ASC", false); }

        public static bool ExisteAlguno()
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) throw new Exception("No se pudo conectar con la base de datos.");
            try
            {
                SqlCommand comando = new SqlCommand("SELECT COUNT(*) FROM S_Usuarios", conexion);
                return Convert.ToInt32(comando.ExecuteScalar()) > 0;
            }
            catch (Exception ex) { throw new Exception("No se pudo revisar la configuración inicial.", ex); }
            finally { conexion.Close(); }
        }

        public static Usuario[] ObtenerClientes()
        {
            return ObtenerLista(SELECT_BASE + "WHERE u.IdPerfil = @idPerfil ORDER BY u.Nombre ASC", true);
        }

        private static Usuario[] ObtenerLista(string consulta, bool soloClientes)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return new Usuario[0];
            try
            {
                Usuario[] usuarios = new Usuario[50];
                int total = 0;
                SqlCommand comando = new SqlCommand(consulta, conexion);
                if (soloClientes) comando.Parameters.AddWithValue("@idPerfil", 3);
                SqlDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    if (total == usuarios.Length) Array.Resize(ref usuarios, usuarios.Length * 2);
                    usuarios[total] = LeerUsuario(lector);
                    total = total + 1;
                }
                lector.Close();
                Array.Resize(ref usuarios, total);
                return usuarios;
            }
            catch (Exception ex) { throw new Exception("No se pudieron listar los usuarios.", ex); }
            finally { conexion.Close(); }
        }

        public static Usuario[] Buscar(Usuario[] lista, string texto)
        {
            if (lista == null || string.IsNullOrWhiteSpace(texto)) return lista;
            Usuario[] resultado = new Usuario[lista.Length];
            int total = 0;
            string buscado = texto.Trim().ToLower();
            for (int i = 0; i < lista.Length; i++)
            {
                if (lista[i].Nombre.ToLower().Contains(buscado) || lista[i].Email.ToLower().Contains(buscado) || lista[i].Rol.ToString().ToLower().Contains(buscado))
                {
                    resultado[total] = lista[i];
                    total = total + 1;
                }
            }
            Array.Resize(ref resultado, total);
            return resultado;
        }

        public static int ContarTotal(Usuario[] lista) { return lista.Length; }

        public static int ContarPorRol(Usuario[] lista, UsuarioRol rolBuscado)
        {
            int total = 0;
            for (int i = 0; i < lista.Length; i++) if (lista[i].Rol == rolBuscado) total = total + 1;
            return total;
        }

        public static bool ExisteNombre(string emailBuscado, int idAExcluir)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;
            try
            {
                SqlCommand comando = new SqlCommand("SELECT COUNT(*) FROM S_Usuarios WHERE LOWER(Email) = LOWER(@email) AND Id <> @id", conexion);
                comando.Parameters.AddWithValue("@email", emailBuscado.Trim());
                comando.Parameters.AddWithValue("@id", idAExcluir);
                return Convert.ToInt32(comando.ExecuteScalar()) > 0;
            }
            catch (Exception ex) { throw new Exception("No se pudo validar el correo.", ex); }
            finally { conexion.Close(); }
        }

        public static bool ExisteEmail(string emailBuscado, int idAExcluir) { return ExisteNombre(emailBuscado, idAExcluir); }

        private static int ObtenerIdEstado(bool estadoActivo) { if (estadoActivo) return 1; return 2; }

        public static bool Guardar(Usuario usuario, string contrasenaTextoPlano)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;
            try
            {
                if (usuario.IdPerfil <= 0) throw new Exception("El perfil seleccionado no existe.");
                int idPerfil = usuario.IdPerfil;
                int idEstado = ObtenerIdEstado(usuario.Activo);
                if (usuario.Id == 0)
                {
                    SqlCommand comando = new SqlCommand("INSERT INTO S_Usuarios (Nombre, Email, PasswordHash, IdPerfil, IdEstado) VALUES (@nombre, @email, @hash, @perfil, @estado)", conexion);
                    comando.Parameters.AddWithValue("@hash", BCrypt.Net.BCrypt.HashPassword(contrasenaTextoPlano, 10));
                    AgregarParametros(comando, usuario, idPerfil, idEstado);
                    comando.ExecuteNonQuery();
                }
                else
                {
                    string consulta = "UPDATE S_Usuarios SET Nombre = @nombre, Email = @email, IdPerfil = @perfil, IdEstado = @estado";
                    if (string.IsNullOrWhiteSpace(contrasenaTextoPlano) == false) consulta += ", PasswordHash = @hash";
                    consulta += " WHERE Id = @id";
                    SqlCommand comando = new SqlCommand(consulta, conexion);
                    AgregarParametros(comando, usuario, idPerfil, idEstado);
                    comando.Parameters.AddWithValue("@id", usuario.Id);
                    if (string.IsNullOrWhiteSpace(contrasenaTextoPlano) == false) comando.Parameters.AddWithValue("@hash", BCrypt.Net.BCrypt.HashPassword(contrasenaTextoPlano, 10));
                    comando.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo guardar el usuario.", ex); }
            finally { conexion.Close(); }
        }

        private static void AgregarParametros(SqlCommand comando, Usuario usuario, int idPerfil, int idEstado)
        {
            comando.Parameters.AddWithValue("@nombre", usuario.Nombre.Trim());
            comando.Parameters.AddWithValue("@email", usuario.Email.Trim());
            comando.Parameters.AddWithValue("@perfil", idPerfil);
            comando.Parameters.AddWithValue("@estado", idEstado);
        }

        public static bool Agregar(Usuario usuario, string contrasenaTextoPlano) { return Guardar(usuario, contrasenaTextoPlano); }
        public static bool Actualizar(Usuario usuario, string contrasenaNueva) { return Guardar(usuario, contrasenaNueva); }

        public static bool CambiarActivo(int idUsuario, bool activoNuevo)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;
            try
            {
                SqlCommand comando = new SqlCommand("UPDATE S_Usuarios SET IdEstado = @estado WHERE Id = @id", conexion);
                comando.Parameters.AddWithValue("@estado", activoNuevo ? 1 : 2);
                comando.Parameters.AddWithValue("@id", idUsuario);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo cambiar el estado del usuario.", ex); }
            finally { conexion.Close(); }
        }

        public static bool CambiarContrasena(int idUsuario, string contrasenaNueva)
        {
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;
            try
            {
                SqlCommand comando = new SqlCommand("UPDATE S_Usuarios SET PasswordHash = @hash WHERE Id = @id", conexion);
                comando.Parameters.AddWithValue("@hash", BCrypt.Net.BCrypt.HashPassword(contrasenaNueva, 10));
                comando.Parameters.AddWithValue("@id", idUsuario);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo restablecer la contraseña.", ex); }
            finally { conexion.Close(); }
        }

        public static bool Eliminar(int idUsuario)
        {
            if (Sesion.UsuarioActual != null && Sesion.UsuarioActual.Id == idUsuario) return false;
            SqlConnection conexion = Conexion.Conectar();
            if (conexion == null) return false;
            try
            {
                SqlCommand revisar = new SqlCommand(
                    "SELECT (SELECT COUNT(*) FROM Eventos WHERE ClienteId = @id) + " +
                    "(SELECT COUNT(*) FROM Reservaciones WHERE ClienteId = @id) + " +
                    "(SELECT COUNT(*) FROM Cotizaciones WHERE ClienteId = @id)", conexion);
                revisar.Parameters.AddWithValue("@id", idUsuario);
                int registrosRelacionados = Convert.ToInt32(revisar.ExecuteScalar());

                SqlCommand comando;
                if (registrosRelacionados > 0)
                {
                    comando = new SqlCommand("UPDATE S_Usuarios SET IdEstado = 2 WHERE Id = @id", conexion);
                }
                else
                {
                    comando = new SqlCommand("DELETE FROM S_Usuarios WHERE Id = @id", conexion);
                }
                comando.Parameters.AddWithValue("@id", idUsuario);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { throw new Exception("No se pudo eliminar el usuario.", ex); }
            finally { conexion.Close(); }
        }
    }
}
