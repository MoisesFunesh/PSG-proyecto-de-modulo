﻿namespace Modelos
{
    // guarda el usuario que inicio sesion, para no tener que pasarlo
    // de formulario en formulario cada vez que se necesita saber quien esta operando
    public class Sesion
    {
        public static Usuario UsuarioActual;
    }
}
